import { eq, desc, and, gte, lte, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, boards, orders, communityPosts, communityComments, resources, videos, buckets, videoBuckets, videoAnalytics, accessTokens, AccessToken, InsertAccessToken, Board, Order, CommunityPost, CommunityComment, InsertBoard, InsertOrder, InsertCommunityPost, InsertCommunityComment, Video, InsertVideo, Bucket, InsertBucket, VideoBucket, InsertVideoBucket, VideoAnalytics, InsertVideoAnalytics } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Boards queries
export async function getAllBoards() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(boards).where(eq(boards.isActive, 1));
}

export async function getBoardById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(boards).where(eq(boards.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createBoard(data: InsertBoard) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(boards).values(data);
  return result;
}

// Orders queries
export async function createOrder(data: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orders).values(data);
  return result;
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Community queries
export async function getAllCommunityPosts() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(communityPosts).orderBy(desc(communityPosts.createdAt));
}

export async function createCommunityPost(data: InsertCommunityPost) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(communityPosts).values(data);
}

export async function getPostComments(postId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(communityComments).where(eq(communityComments.postId, postId)).orderBy(desc(communityComments.createdAt));
}

export async function createCommunityComment(data: InsertCommunityComment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(communityComments).values(data);
}

// Resources queries
export async function getAllResources() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(resources);
}


// Videos queries
export async function getAllVideos() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos).orderBy(desc(videos.createdAt));
}

export async function getOfficialVideos() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos).where(eq(videos.isOfficial, 1)).orderBy(desc(videos.createdAt));
}

export async function getUGCVideos() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos).where(eq(videos.isOfficial, 0)).orderBy(desc(videos.createdAt));
}

export async function createVideo(data: InsertVideo) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Drizzle returns array with ResultSetHeader at [0]
  const result = await db.insert(videos).values(data) as any;
  const insertedId = result?.[0]?.insertId || result?.insertId;
  if (!insertedId) {
    console.error("Insert result:", result);
    throw new Error("Failed to get inserted video ID");
  }
  const video = await getVideoById(insertedId);
  if (!video) throw new Error("Failed to retrieve inserted video");
  return video;
}

export async function getVideoById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}


// CMS: Buckets queries
export async function getAllBuckets() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(buckets).orderBy(buckets.displayOrder);
}

export async function getPublishedBuckets() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(buckets).where(eq(buckets.isPublished, 1)).orderBy(buckets.displayOrder);
}

export async function getBucketById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(buckets).where(eq(buckets.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createBucket(data: InsertBucket) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(buckets).values(data) as any;
  // Drizzle returns array with ResultSetHeader at [0]
  const insertedId = result?.[0]?.insertId || result?.insertId;
  if (!insertedId) {
    console.error("Insert result:", result);
    throw new Error("Failed to get inserted bucket ID");
  }
  const bucket = await getBucketById(insertedId);
  if (!bucket) throw new Error("Failed to retrieve inserted bucket");
  return bucket;
}

export async function updateBucket(id: number, data: Partial<InsertBucket>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(buckets).set({ ...data, updatedAt: new Date() }).where(eq(buckets.id, id));
}

export async function deleteBucket(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(buckets).where(eq(buckets.id, id));
}

// CMS: Video-Bucket relationships
export async function getBucketVideos(bucketId: number) {
  const db = await getDb();
  if (!db) return [];
  const videoBucketRecords = await db
    .select()
    .from(videoBuckets)
    .where(eq(videoBuckets.bucketId, bucketId))
    .orderBy(videoBuckets.sortOrder);

  const videoIds = videoBucketRecords.map((vb) => vb.videoId);
  if (videoIds.length === 0) return [];

  // Use inArray operator for filtering by multiple IDs
  const videoList = await db.select().from(videos).where(inArray(videos.id, videoIds));
  return videoList;
}

export async function addVideoToBucket(videoId: number, bucketId: number, sortOrder: number = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const values = { videoId, bucketId, sortOrder };
  return await db.insert(videoBuckets).values(values);
}

export async function removeVideoFromBucket(videoId: number, bucketId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(videoBuckets).where(and(eq(videoBuckets.videoId, videoId), eq(videoBuckets.bucketId, bucketId)));
}

export async function updateVideoBucketOrder(videoId: number, bucketId: number, sortOrder: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db
    .update(videoBuckets)
    .set({ sortOrder })
    .where(and(eq(videoBuckets.videoId, videoId), eq(videoBuckets.bucketId, bucketId)));
}

// CMS: Video management with workflow states
export async function getVideosByStatus(status: string) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(videos).where(eq(videos.status, status as any)).orderBy(desc(videos.createdAt));
}

export async function getPublishedVideos() {
  const db = await getDb();
  if (!db) return [];
  // Get published videos, filtering in application layer for date-based conditions
  const allPublished = await db
    .select()
    .from(videos)
    .where(eq(videos.status, "published" as any))
    .orderBy(desc(videos.createdAt));

  const now = new Date();
  return allPublished.filter(
    (v) => (!v.goLiveAt || v.goLiveAt <= now) && (!v.expiresAt || v.expiresAt > now)
  );
}

export async function updateVideoStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(videos).set({ status: status as any, updatedAt: new Date() }).where(eq(videos.id, id));
  // Return the updated video
  const video = await getVideoById(id);
  if (!video) throw new Error("Failed to retrieve updated video");
  return video;
}

export async function updateVideo(id: number, data: Partial<InsertVideo>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(videos).set({ ...data, updatedAt: new Date() }).where(eq(videos.id, id));
}

export async function deleteVideo(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Also remove from all buckets
  await db.delete(videoBuckets).where(eq(videoBuckets.videoId, id));
  return await db.delete(videos).where(eq(videos.id, id));
}

// CMS: Analytics
export async function recordVideoAnalytics(data: InsertVideoAnalytics) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(videoAnalytics).values(data);
}

export async function getVideoAnalytics(videoId: number, startDate?: string, endDate?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(videoAnalytics.videoId, videoId)];
  if (startDate) conditions.push(gte(videoAnalytics.date, startDate));
  if (endDate) conditions.push(lte(videoAnalytics.date, endDate));
  return await db.select().from(videoAnalytics).where(and(...conditions)).orderBy(videoAnalytics.date);
}

export async function getBucketAnalytics(bucketId: number, startDate?: string, endDate?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(videoAnalytics.bucketId, bucketId)];
  if (startDate) conditions.push(gte(videoAnalytics.date, startDate));
  if (endDate) conditions.push(lte(videoAnalytics.date, endDate));
  return await db.select().from(videoAnalytics).where(and(...conditions)).orderBy(videoAnalytics.date);
}


// ============================================================================
// Access Tokens (Whitelist Gate)
// ============================================================================

export async function createAccessToken(data: InsertAccessToken): Promise<AccessToken> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(accessTokens).values(data);
  const insertId = (result as any)[0]?.insertId || (result as any).insertId;
  
  if (!insertId) throw new Error("Failed to get insert ID");
  
  const token = await db.select().from(accessTokens).where(eq(accessTokens.id, insertId));
  if (!token.length) throw new Error("Failed to retrieve created token");
  
  return token[0];
}

export async function getAccessTokenByHash(tokenHash: string): Promise<AccessToken | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(accessTokens).where(eq(accessTokens.tokenHash, tokenHash));
  return result[0];
}

export async function updateAccessTokenUses(id: number, usesRemaining: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(accessTokens).set({ usesRemaining }).where(eq(accessTokens.id, id));
}

export async function revokeAccessToken(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(accessTokens).set({ revokedAt: new Date() }).where(eq(accessTokens.id, id));
}

export async function listAccessTokens(purpose?: string): Promise<AccessToken[]> {
  const db = await getDb();
  if (!db) return [];
  
  if (purpose) {
    return await db.select().from(accessTokens).where(eq(accessTokens.purpose, purpose as any));
  }
  
  return await db.select().from(accessTokens);
}
