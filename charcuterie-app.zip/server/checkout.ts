import Stripe from "stripe";
import * as db from "./db";
import { ShippingAddress, OrderItem } from "../drizzle/schema";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

export interface CreatePaymentIntentRequest {
  items: OrderItem[];
  totalPrice: string;
  shippingAddress: ShippingAddress;
  email: string;
}

export async function createPaymentIntent(req: CreatePaymentIntentRequest) {
  const { items, totalPrice, shippingAddress, email } = req;

  // Validate input
  if (!items || items.length === 0) {
    throw new Error("Cart is empty");
  }

  if (!shippingAddress || !email) {
    throw new Error("Missing shipping or email information");
  }

  // Create Stripe PaymentIntent
  const paymentIntent = await stripe.paymentIntents.create({
    amount: parseInt(totalPrice), // Amount in cents
    currency: "usd",
    automatic_payment_methods: {
      enabled: true,
    },
    metadata: {
      email,
      fullName: shippingAddress.fullName,
      itemCount: items.length.toString(),
    },
  });

  // Create order record in database
  const order = await db.createOrder({
    email,
    totalPrice: (parseInt(totalPrice) / 100).toString(),
    items: items as any,
    shippingAddress: shippingAddress as any,
    stripePaymentIntentId: paymentIntent.id,
    status: "pending",
  } as any);

  return {
    clientSecret: paymentIntent.client_secret,
    orderId: (order as any).insertId || 0,
  };
}

export async function confirmPaymentIntent(paymentIntentId: string) {
  // Fetch PaymentIntent from Stripe
  const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

  if (paymentIntent.status !== "succeeded") {
    throw new Error("Payment not successful");
  }

  // For now, just return the payment intent
  // In a real app, you'd update the order status in the database
  return paymentIntent;
}
