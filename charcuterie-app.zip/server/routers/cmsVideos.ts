/**
 * CMS Videos Router
 * Admin-only procedures for managing official video content with workflow states,
 * scheduling, and embed validation.
 */

import { TRPCError } from "@trpc/server";
import { adminProcedure, router } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";
import {
  CMSVideoCreateSchema,
  CMSVideoUpdateSchema,
  CMSVideoStatusUpdateSchema,
  CMSEmbedValidationSchema,
  CMSVideoIntakeSchema,
} from "../_core/validation";
import { validateImageUrl } from "../_core/security";

/**
 * Embed URL allowlist and platform detection
 */
const EMBED_ALLOWLIST = {
  instagram: /^https:\/\/(www\.)?instagram\.com\/(p|reel)\/[a-zA-Z0-9_-]+/,
  tiktok: /^https:\/\/(www\.)?tiktok\.com\/@[a-zA-Z0-9_.-]+\/video\/\d+/,
  youtube: /^https:\/\/(www\.)?youtube\.com\/(watch\?v=|shorts\/)[a-zA-Z0-9_-]+/,
};

/**
 * Detect platform from URL
 */
function detectPlatform(url: string): "instagram" | "tiktok" | "youtube" | null {
  if (EMBED_ALLOWLIST.instagram.test(url)) return "instagram";
  if (EMBED_ALLOWLIST.tiktok.test(url)) return "tiktok";
  if (EMBED_ALLOWLIST.youtube.test(url)) return "youtube";
  return null;
}

/**
 * Validate embed URL against allowlist
 */
function validateEmbedUrl(platform: string, url: string): boolean {
  const regex = EMBED_ALLOWLIST[platform as keyof typeof EMBED_ALLOWLIST];
  return regex ? regex.test(url) : false;
}

/**
 * Enforce allowed status transitions
 */
function isValidStatusTransition(
  currentStatus: string,
  newStatus: string
): boolean {
  const transitions: Record<string, string[]> = {
    draft: ["review", "published", "archived"],
    review: ["draft", "scheduled", "published", "archived"],
    scheduled: ["published", "archived", "draft"],
    published: ["archived", "draft"],
    archived: ["draft"],
  };

  return transitions[currentStatus]?.includes(newStatus) ?? false;
}

export const cmsVideosRouter = router({
  /**
   * Create a new video with validation and embed normalization
   */
  create: adminProcedure
    .input(CMSVideoCreateSchema)
    .mutation(async ({ input }) => {
      // Validate embed URL
      if (!validateEmbedUrl(input.platform, input.platformUrl)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Invalid ${input.platform} URL. Must be a valid platform link.`,
        });
      }

      // Validate thumbnail URL if provided
      if (input.thumbnailUrl && !validateImageUrl(input.thumbnailUrl)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Invalid thumbnail URL",
        });
      }

      // Enforce scheduling rules
      if (input.status === "scheduled" && !input.goLiveAt) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Scheduled videos must have a goLiveAt date",
        });
      }

      try {
        const result = await db.createVideo({
          ...input,
          isOfficial: 1,
          status: input.status as any,
          contentType: input.contentType as any,
        });
        return result;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create video",
        });
      }
    }),

  /**
   * Update video metadata and workflow state
   */
  update: adminProcedure
    .input(
      z.object({
        id: z.number().positive(),
        data: CMSVideoUpdateSchema,
      })
    )
    .mutation(async ({ input }) => {
      const video = await db.getVideoById(input.id);
      if (!video) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Video not found",
        });
      }

      // Validate new embed URL if provided
      if (
        input.data.platformUrl &&
        !validateEmbedUrl(
          input.data.platform || video.platform,
          input.data.platformUrl
        )
      ) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Invalid platform URL",
        });
      }

      // Validate thumbnail if provided
      if (
        input.data.thumbnailUrl &&
        !validateImageUrl(input.data.thumbnailUrl)
      ) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Invalid thumbnail URL",
        });
      }

      try {
        await db.updateVideo(input.id, input.data as any);
        return await db.getVideoById(input.id);
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update video",
        });
      }
    }),

  /**
   * Update video status with workflow validation
   */
  setStatus: adminProcedure
    .input(CMSVideoStatusUpdateSchema)
    .mutation(async ({ input }) => {
      const video = await db.getVideoById(input.videoId);
      if (!video) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Video not found",
        });
      }

      // Validate transition
      if (!isValidStatusTransition(video.status, input.status)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Cannot transition from ${video.status} to ${input.status}`,
        });
      }

      // Enforce scheduling rules for scheduled status
      if (input.status === "scheduled" && !video.goLiveAt) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Scheduled videos must have a goLiveAt date",
        });
      }

      try {
        await db.updateVideoStatus(input.videoId, input.status);
        return await db.getVideoById(input.videoId);
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update video status",
        });
      }
    }),

  /**
   * Get video by ID (admin view includes all statuses)
   */
  getById: adminProcedure
    .input(z.object({ id: z.number().positive() }))
    .query(async ({ input }) => {
      const video = await db.getVideoById(input.id);
      if (!video) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Video not found",
        });
      }
      return video;
    }),

  /**
   * List videos with filtering and pagination
   */
  list: adminProcedure
    .input(
      z.object({
        status: z
          .enum(["draft", "review", "scheduled", "published", "archived"])
          .optional(),
        contentType: z
          .enum(["bts", "product", "testimonial", "event", "other"])
          .optional(),
        campaign: z.string().optional(),
        platform: z.enum(["instagram", "tiktok", "youtube", "uploaded"]).optional(),
        page: z.number().int().positive().default(1),
        limit: z.number().int().positive().max(100).default(20),
      })
    )
    .query(async ({ input }) => {
      let videos = await db.getAllVideos();

      // Apply filters
      if (input.status) {
        videos = videos.filter((v) => v.status === input.status);
      }
      if (input.contentType) {
        videos = videos.filter((v) => v.contentType === input.contentType);
      }
      if (input.campaign) {
        videos = videos.filter((v) => v.campaign === input.campaign);
      }
      if (input.platform) {
        videos = videos.filter((v) => v.platform === input.platform);
      }

      // Pagination
      const offset = (input.page - 1) * input.limit;
      const paginated = videos.slice(offset, offset + input.limit);

      return {
        items: paginated,
        total: videos.length,
        page: input.page,
        limit: input.limit,
        pages: Math.ceil(videos.length / input.limit),
      };
    }),

  /**
   * Delete video (soft delete via archived status)
   */
  delete: adminProcedure
    .input(z.object({ id: z.number().positive() }))
    .mutation(async ({ input }) => {
      const video = await db.getVideoById(input.id);
      if (!video) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Video not found",
        });
      }

      try {
        await db.deleteVideo(input.id);
        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to delete video",
        });
      }
    }),

  /**
   * Validate embed URL and return normalized platform
   */
  validateEmbed: adminProcedure
    .input(CMSEmbedValidationSchema)
    .query(({ input }) => {
      const detectedPlatform = detectPlatform(input.url);

      if (!detectedPlatform || detectedPlatform !== input.platform) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `URL does not match ${input.platform} format`,
        });
      }

      if (!validateEmbedUrl(input.platform, input.url)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Invalid ${input.platform} URL format`,
        });
      }

      return {
        platform: detectedPlatform,
        url: input.url,
        valid: true,
      };
    }),

  /**
   * Create video from URL intake (staff workflow)
   * Validates URL, detects platform, creates video, optionally attaches to bucket
   */
  createFromUrl: adminProcedure
    .input(CMSVideoIntakeSchema)
    .mutation(async ({ input }) => {
      // Detect platform from URL
      const detectedPlatform = detectPlatform(input.platformUrl);
      if (!detectedPlatform) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "URL does not match any supported platform (Instagram, TikTok, YouTube)",
        });
      }

      // Validate URL against platform regex
      if (!validateEmbedUrl(detectedPlatform, input.platformUrl)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Invalid ${detectedPlatform} URL format`,
        });
      }

      try {
        // Create video record
        const video = await db.createVideo({
          title: input.title || `${detectedPlatform} video`,
          description: undefined,
          platform: detectedPlatform,
          platformUrl: input.platformUrl,
          thumbnailUrl: undefined,
          creator: undefined,
          creatorHandle: undefined,
          tags: [],
          status: input.status || "draft",
          contentType: input.contentType || "other",
          campaign: undefined,
          goLiveAt: undefined,
          expiresAt: undefined,
        });

        // Attach to bucket if provided
        if (input.bucketId) {
          await db.addVideoToBucket(video.id, input.bucketId, 0);
        }

        return video;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create video from URL",
        });
      }
    }),
});
