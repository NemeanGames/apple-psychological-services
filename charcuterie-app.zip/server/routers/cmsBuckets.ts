/**
 * CMS Buckets Router
 * Admin-only procedures for managing curated video collections (buckets)
 * and their video membership with reordering support.
 */

import { TRPCError } from "@trpc/server";
import { adminProcedure, router } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";
import {
  CMSBucketCreateSchema,
  CMSBucketUpdateSchema,
  CMSBucketAddVideoSchema,
  CMSBucketReorderSchema,
} from "../_core/validation";

export const cmsBucketsRouter = router({
  /**
   * Create a new bucket
   */
  create: adminProcedure
    .input(CMSBucketCreateSchema)
    .mutation(async ({ input }) => {
      try {
        const result = await db.createBucket({
          ...input,
          isPublished: input.isPublished ?? 0,
          displayOrder: input.displayOrder ?? 0,
        });
        return result;
      } catch (error: any) {
        if (error.message?.includes("UNIQUE constraint")) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Bucket name must be unique",
          });
        }
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create bucket",
        });
      }
    }),

  /**
   * Update bucket metadata
   */
  update: adminProcedure
    .input(
      z.object({
        id: z.number().positive(),
        data: CMSBucketUpdateSchema,
      })
    )
    .mutation(async ({ input }) => {
      const bucket = await db.getBucketById(input.id);
      if (!bucket) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Bucket not found",
        });
      }

      try {
        await db.updateBucket(input.id, input.data);
        return await db.getBucketById(input.id);
      } catch (error: any) {
        if (error.message?.includes("UNIQUE constraint")) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Bucket name must be unique",
          });
        }
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update bucket",
        });
      }
    }),

  /**
   * Get bucket by ID with all videos
   */
  getById: adminProcedure
    .input(z.object({ id: z.number().positive() }))
    .query(async ({ input }) => {
      const bucket = await db.getBucketById(input.id);
      if (!bucket) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Bucket not found",
        });
      }

      const videos = await db.getBucketVideos(input.id);

      return {
        ...bucket,
        videos,
      };
    }),

  /**
   * List all buckets with pagination
   */
  list: adminProcedure
    .input(
      z.object({
        page: z.number().int().positive().default(1),
        limit: z.number().int().positive().max(100).default(20),
        includeVideos: z.boolean().default(false),
      })
    )
    .query(async ({ input }) => {
      let buckets = await db.getAllBuckets();

      // Pagination
      const offset = (input.page - 1) * input.limit;
      const paginated = buckets.slice(offset, offset + input.limit);

      // Optionally include videos for each bucket
      let result = paginated;
      if (input.includeVideos) {
        result = await Promise.all(
          paginated.map(async (bucket) => ({
            ...bucket,
            videos: await db.getBucketVideos(bucket.id),
          }))
        );
      }

      return {
        items: result,
        total: buckets.length,
        page: input.page,
        limit: input.limit,
        pages: Math.ceil(buckets.length / input.limit),
      };
    }),

  /**
   * Add video to bucket with sort order
   */
  addVideo: adminProcedure
    .input(CMSBucketAddVideoSchema)
    .mutation(async ({ input }) => {
      // Verify bucket exists
      const bucket = await db.getBucketById(input.bucketId);
      if (!bucket) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Bucket not found",
        });
      }

      // Verify video exists
      const video = await db.getVideoById(input.videoId);
      if (!video) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Video not found",
        });
      }

      // Check if video is already in bucket
      const existingVideos = await db.getBucketVideos(input.bucketId);
      if (existingVideos.some((v) => v.id === input.videoId)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Video is already in this bucket",
        });
      }

      try {
        await db.addVideoToBucket(
          input.videoId,
          input.bucketId,
          input.sortOrder
        );
        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to add video to bucket",
        });
      }
    }),

  /**
   * Remove video from bucket
   */
  removeVideo: adminProcedure
    .input(
      z.object({
        bucketId: z.number().positive(),
        videoId: z.number().positive(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await db.removeVideoFromBucket(input.videoId, input.bucketId);
        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to remove video from bucket",
        });
      }
    }),

  /**
   * Reorder videos within a bucket (transaction)
   * Input: array of {videoId, sortOrder} pairs
   */
  reorderVideos: adminProcedure
    .input(
      z.object({
        bucketId: z.number().positive(),
        videos: z.array(
          z.object({
            videoId: z.number().positive(),
            sortOrder: z.number().int().nonnegative(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      // Verify bucket exists
      const bucket = await db.getBucketById(input.bucketId);
      if (!bucket) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Bucket not found",
        });
      }

      try {
        // Update sort order for each video
        await Promise.all(
          input.videos.map((item) =>
            db.updateVideoBucketOrder(
              item.videoId,
              input.bucketId,
              item.sortOrder
            )
          )
        );

        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to reorder videos",
        });
      }
    }),

  /**
   * Set bucket publish state
   */
  setPublishState: adminProcedure
    .input(
      z.object({
        id: z.number().positive(),
        isPublished: z.number().int().min(0).max(1),
      })
    )
    .mutation(async ({ input }) => {
      const bucket = await db.getBucketById(input.id);
      if (!bucket) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Bucket not found",
        });
      }

      try {
        await db.updateBucket(input.id, { isPublished: input.isPublished });
        return await db.getBucketById(input.id);
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update bucket publish state",
        });
      }
    }),

  /**
   * Delete bucket (also removes all video associations)
   */
  delete: adminProcedure
    .input(z.object({ id: z.number().positive() }))
    .mutation(async ({ input }) => {
      const bucket = await db.getBucketById(input.id);
      if (!bucket) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Bucket not found",
        });
      }

      try {
        await db.deleteBucket(input.id);
        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to delete bucket",
        });
      }
    }),
});
