/**
 * CMS Videos Intake Tests
 * Tests for createFromUrl procedure and URL validation
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTRPCMsw } from "trpc-msw";
import * as db from "../db";
import { getDb } from "../db";

describe("CMS Videos - Intake (createFromUrl)", () => {
  let database: Awaited<ReturnType<typeof getDb>>;

  beforeAll(async () => {
    database = await getDb();
    if (!database) {
      throw new Error("Database not available for tests");
    }
  });

  describe("URL Detection & Validation", () => {
    it("should detect Instagram URLs correctly", () => {
      const instagramUrls = [
        "https://www.instagram.com/p/ABC123/",
        "https://instagram.com/p/ABC123/",
        "https://www.instagram.com/reel/ABC123/",
      ];

      instagramUrls.forEach((url) => {
        // Platform detection happens in detectPlatform utility
        const isInstagram =
          url.includes("instagram.com") &&
          (url.includes("/p/") || url.includes("/reel/"));
        expect(isInstagram).toBe(true);
      });
    });

    it("should detect TikTok URLs correctly", () => {
      const tiktokUrls = [
        "https://www.tiktok.com/@user/video/123456789",
        "https://tiktok.com/@user/video/123456789",
      ];

      tiktokUrls.forEach((url) => {
        const isTikTok =
          url.includes("tiktok.com") && url.includes("/video/");
        expect(isTikTok).toBe(true);
      });
    });

    it("should detect YouTube URLs correctly", () => {
      const youtubeUrls = [
        "https://www.youtube.com/watch?v=ABC123",
        "https://youtu.be/ABC123",
        "https://youtube.com/watch?v=ABC123",
      ];

      youtubeUrls.forEach((url) => {
        const isYouTube =
          url.includes("youtube.com") ||
          url.includes("youtu.be");
        expect(isYouTube).toBe(true);
      });
    });

    it("should reject unsupported platform URLs", () => {
      const unsupportedUrls = [
        "https://www.facebook.com/video/123",
        "https://www.twitter.com/user/status/123",
        "https://www.reddit.com/r/videos",
      ];

      unsupportedUrls.forEach((url) => {
        const isSupported =
          url.includes("instagram.com") ||
          url.includes("tiktok.com") ||
          url.includes("youtube.com") ||
          url.includes("youtu.be");
        expect(isSupported).toBe(false);
      });
    });
  });

  describe("Video Creation from URL", () => {
    it("should create a video with minimal required fields", async () => {
      if (!database) throw new Error("Database not available");

      const testVideo = await db.createVideo({
        title: "Test Instagram Video",
        description: undefined,
        platform: "instagram",
        platformUrl: "https://www.instagram.com/p/ABC123/",
        thumbnailUrl: undefined,
        creator: undefined,
        creatorHandle: undefined,
        tags: [],
        status: "draft",
        contentType: "other",
        campaign: undefined,
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      expect(testVideo).toBeDefined();
      expect(testVideo.id).toBeDefined();
      expect(testVideo.title).toBe("Test Instagram Video");
      expect(testVideo.platform).toBe("instagram");
      expect(testVideo.status).toBe("draft");
    });

    it("should create a video with optional title", async () => {
      if (!database) throw new Error("Database not available");

      const testVideo = await db.createVideo({
        title: "Custom Title for TikTok",
        description: undefined,
        platform: "tiktok",
        platformUrl: "https://www.tiktok.com/@boardella/video/123456789",
        thumbnailUrl: undefined,
        creator: undefined,
        creatorHandle: undefined,
        tags: [],
        status: "published",
        contentType: "product",
        campaign: undefined,
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      expect(testVideo.title).toBe("Custom Title for TikTok");
      expect(testVideo.contentType).toBe("product");
    });

    it("should default to 'draft' status if not provided", async () => {
      if (!database) throw new Error("Database not available");

      const testVideo = await db.createVideo({
        title: "Draft Video",
        description: undefined,
        platform: "youtube",
        platformUrl: "https://www.youtube.com/watch?v=ABC123",
        thumbnailUrl: undefined,
        creator: undefined,
        creatorHandle: undefined,
        tags: [],
        status: "draft",
        contentType: "other",
        campaign: undefined,
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      expect(testVideo.status).toBe("draft");
    });

    it("should support all content types", async () => {
      if (!database) throw new Error("Database not available");

      const contentTypes = ["bts", "product", "testimonial", "event", "other"];

      for (const contentType of contentTypes) {
        const testVideo = await db.createVideo({
          title: `Video - ${contentType}`,
          description: undefined,
          platform: "instagram",
          platformUrl: `https://www.instagram.com/p/TEST${contentType}/`,
          thumbnailUrl: undefined,
          creator: undefined,
          creatorHandle: undefined,
          tags: [],
          status: "draft",
          contentType: contentType as any,
          campaign: undefined,
          goLiveAt: undefined,
          expiresAt: undefined,
        });

        expect(testVideo.contentType).toBe(contentType);
      }
    });
  });

  describe("Bucket Assignment", () => {
    it("should attach video to bucket if bucketId provided", async () => {
      if (!database) throw new Error("Database not available");

      // Create a bucket first with unique name
      const bucket = await db.createBucket({
        name: `Test Bucket for Intake ${Date.now()}`,
        description: "Test bucket",
        isPublished: 0,
        displayOrder: 0,
      });

      // Create a video
      const video = await db.createVideo({
        title: "Video for Bucket",
        description: undefined,
        platform: "instagram",
        platformUrl: "https://www.instagram.com/p/BUCKET123/",
        thumbnailUrl: undefined,
        creator: undefined,
        creatorHandle: undefined,
        tags: [],
        status: "draft",
        contentType: "other",
        campaign: undefined,
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      // Add video to bucket
      await db.addVideoToBucket(video.id, bucket.id, 0);

      // Verify video and bucket were created
      expect(video.id).toBeDefined();
      expect(bucket.id).toBeDefined();
      // If no error was thrown, the association was successful
      expect(true).toBe(true);
    });

    it("should support optional bucket assignment", async () => {
      if (!database) throw new Error("Database not available");

      // Create video without bucket
      const video = await db.createVideo({
        title: `Video Without Bucket ${Date.now()}`,
        description: undefined,
        platform: "youtube",
        platformUrl: `https://www.youtube.com/watch?v=NOBUCKET${Date.now()}`,
        thumbnailUrl: undefined,
        creator: undefined,
        creatorHandle: undefined,
        tags: [],
        status: "draft",
        contentType: "other",
        campaign: undefined,
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      expect(video.id).toBeDefined();
      // Video should exist without bucket assignment
      const retrieved = await db.getVideoById(video.id);
      expect(retrieved).toBeDefined();
    });
  });

  describe("Status Transitions", () => {
    it("should allow draft videos to be published", async () => {
      if (!database) throw new Error("Database not available");

      const video = await db.createVideo({
        title: "Draft to Publish",
        description: undefined,
        platform: "instagram",
        platformUrl: "https://www.instagram.com/p/DRAFT2PUB/",
        thumbnailUrl: undefined,
        creator: undefined,
        creatorHandle: undefined,
        tags: [],
        status: "draft",
        contentType: "other",
        campaign: undefined,
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      // Update status to published
      const updated = await db.updateVideoStatus(video.id, "published");
      expect(updated.status).toBe("published");
    });

    it("should preserve all fields during status update", async () => {
      if (!database) throw new Error("Database not available");

      const video = await db.createVideo({
        title: "Preserve Fields",
        description: "Test description",
        platform: "tiktok",
        platformUrl: "https://www.tiktok.com/@test/video/PRESERVE",
        thumbnailUrl: undefined,
        creator: "Test Creator",
        creatorHandle: "@testcreator",
        tags: ["test", "preserve"],
        status: "draft",
        contentType: "product",
        campaign: "Test Campaign",
        goLiveAt: undefined,
        expiresAt: undefined,
      });

      const updated = await db.updateVideoStatus(video.id, "published");
      expect(updated.title).toBe("Preserve Fields");
      expect(updated.platform).toBe("tiktok");
      expect(updated.contentType).toBe("product");
      expect(updated.campaign).toBe("Test Campaign");
    });
  });
});
