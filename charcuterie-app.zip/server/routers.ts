import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { cmsVideosRouter } from "./routers/cmsVideos";
import { cmsBucketsRouter } from "./routers/cmsBuckets";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  boards: router({
    list: publicProcedure.query(() => db.getAllBoards()),
    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getBoardById(input.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        price: z.string(),
        imageUrl: z.string().optional(),
        tags: z.array(z.string()).optional(),
        size: z.string().optional(),
        contents: z.record(z.string(), z.array(z.string())).optional(),
      }))
      .mutation(({ input }) => db.createBoard(input as any)),
  }),

  orders: router({
    create: protectedProcedure
      .input(z.object({
        totalPrice: z.string(),
        items: z.array(z.object({
          boardId: z.number(),
          name: z.string(),
          price: z.string(),
          quantity: z.number(),
        })),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createOrder({
        userId: ctx.user.id,
        email: ctx.user.email || '',
        totalPrice: input.totalPrice,
        items: input.items as any,
        notes: input.notes,
      })),
    list: protectedProcedure.query(({ ctx }) => db.getUserOrders(ctx.user.id)),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getOrderById(input.id)),
  }),

  community: router({
    posts: router({
      list: publicProcedure.query(() => db.getAllCommunityPosts()),
      create: protectedProcedure
        .input(z.object({
          content: z.string(),
          imageUrl: z.string().optional(),
        }))
        .mutation(({ ctx, input }) => db.createCommunityPost({
          userId: ctx.user.id,
          userName: ctx.user.name || "Anonymous",
          content: input.content,
          imageUrl: input.imageUrl,
        } as any)),
    }),
    comments: router({
      list: publicProcedure
        .input(z.object({ postId: z.number() }))
        .query(({ input }) => db.getPostComments(input.postId)),
      create: protectedProcedure
        .input(z.object({
          postId: z.number(),
          content: z.string(),
        }))
        .mutation(({ ctx, input }) => db.createCommunityComment({
          postId: input.postId,
          userId: ctx.user.id,
          userName: ctx.user.name || "Anonymous",
          content: input.content,
        } as any)),
    }),
  }),

  resources: router({
    list: publicProcedure.query(() => db.getAllResources()),
  }),

  videos: router({
    list: publicProcedure.query(() => db.getAllVideos()),
    official: publicProcedure.query(() => db.getOfficialVideos()),
    ugc: publicProcedure.query(() => db.getUGCVideos()),
    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getVideoById(input.id)),
    listPublished: publicProcedure
      .input(z.object({
        bucketId: z.number().optional(),
      }))
      .query(async ({ input }) => {
        if (input.bucketId) {
          const bucket = await db.getBucketById(input.bucketId);
          if (!bucket || !bucket.isPublished) {
            return [];
          }
          const videos = await db.getBucketVideos(input.bucketId);
          return videos.filter((v: any) => v.status === "published");
        }
        return await db.getPublishedVideos();
      }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        platform: z.enum(["instagram", "tiktok", "youtube"]),
        platformUrl: z.string(),
        thumbnailUrl: z.string().optional(),
        creator: z.string().optional(),
        creatorHandle: z.string().optional(),
        isOfficial: z.number().optional(),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(({ input }) => db.createVideo(input as any)),
  }),

  // CMS routers for admin content management
  cmsVideos: cmsVideosRouter,
  cmsBuckets: cmsBucketsRouter,
  
  // Admin procedures
  admin: router({
    siteAccess: router({
      mintBetaToken: protectedProcedure
        .input(z.object({
          label: z.string().optional(),
          maxUses: z.number().optional().default(1),
          expiresAtIso: z.string().optional(),
        }))
        .mutation(async ({ ctx, input }) => {
          if (ctx.user.role !== "admin") {
            throw new Error("Unauthorized: admin only");
          }
          
          const crypto = require("crypto");
          const plainToken = "site_beta_" + crypto.randomBytes(32).toString("hex");
          const tokenHash = crypto.createHash("sha256").update(plainToken).digest("hex");
          
          const expiresAt = input.expiresAtIso ? new Date(input.expiresAtIso) : null;
          const token = await db.createAccessToken({
            tokenHash,
            purpose: "site_beta",
            label: input.label,
            maxUses: input.maxUses,
            usesRemaining: input.maxUses,
            expiresAt,
          });
          
          return {
            id: token.id,
            token: plainToken,
            expiresAt: token.expiresAt,
            maxUses: token.maxUses,
          };
        }),
      
      listTokens: protectedProcedure
        .query(async ({ ctx }) => {
          if (ctx.user.role !== "admin") {
            throw new Error("Unauthorized: admin only");
          }
          
          return await db.listAccessTokens("site_beta");
        }),
      
      revokeToken: protectedProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ ctx, input }) => {
          if (ctx.user.role !== "admin") {
            throw new Error("Unauthorized: admin only");
          }
          
          await db.revokeAccessToken(input.id);
          return { success: true };
        }),
    }),
  }),
});

export type AppRouter = typeof appRouter;
