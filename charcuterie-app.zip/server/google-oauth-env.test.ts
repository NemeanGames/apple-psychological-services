import { describe, it, expect } from "vitest";

describe("Google OAuth Environment Variables", () => {
  it("should have GOOGLE_CLIENT_ID set", () => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    expect(clientId).toBeDefined();
    expect(clientId).toMatch(/^\d+-.+\.apps\.googleusercontent\.com$/);
  });

  it("should have GOOGLE_CLIENT_SECRET set", () => {
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    expect(clientSecret).toBeDefined();
    expect(clientSecret?.length).toBeGreaterThan(0);
  });

  it("should have VITE_GOOGLE_CLIENT_ID set for frontend", () => {
    const viteClientId = process.env.VITE_GOOGLE_CLIENT_ID;
    expect(viteClientId).toBeDefined();
    expect(viteClientId).toMatch(/^\d+-.+\.apps\.googleusercontent\.com$/);
  });

  it("VITE_GOOGLE_CLIENT_ID should match GOOGLE_CLIENT_ID", () => {
    const backendClientId = process.env.GOOGLE_CLIENT_ID;
    const frontendClientId = process.env.VITE_GOOGLE_CLIENT_ID;
    expect(backendClientId).toBe(frontendClientId);
  });

  it("should have valid Google OAuth credentials format", () => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    // Google Client IDs follow format: <numeric-id>-<random-string>.apps.googleusercontent.com
    const parts = clientId?.split("-");
    expect(parts?.length).toBeGreaterThanOrEqual(2);
    expect(parts?.[0]).toMatch(/^\d+$/); // First part is numeric
  });
});
