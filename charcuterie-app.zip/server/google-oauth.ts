import { OAuth2Client } from "google-auth-library";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import type { Express, Request, Response } from "express";
import { COOKIE_NAME } from "../shared/const";
import { sdk } from "./_core/sdk";
import { getSessionCookieOptions } from "./_core/cookies";

// OAuth2Client for token verification only (no redirect needed for Sign-In SDK)
const client = new OAuth2Client({
  clientId: process.env.GOOGLE_CLIENT_ID!,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
});

/**
 * Validate Google ID token server-side
 * Verifies: iss, aud, exp, sub
 */
async function validateGoogleToken(token: string) {
  try {
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: [process.env.GOOGLE_CLIENT_ID!],
    });

    const payload = ticket.getPayload() as any;
    if (!payload) throw new Error("No payload in token");

    // Verify critical claims
    if (payload.iss !== "https://accounts.google.com") {
      throw new Error("Invalid issuer");
    }

    // Audience can be a string or array, check if our client ID is in it
    const aud = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
    if (!aud.includes(process.env.GOOGLE_CLIENT_ID!)) {
      throw new Error("Invalid audience");
    }

    if (!payload.sub) {
      throw new Error("No subject in token");
    }

    if (payload.exp && payload.exp * 1000 < Date.now()) {
      throw new Error("Token expired");
    }

    return {
      sub: payload.sub, // Google's stable user ID
      email: payload.email,
      name: payload.name,
      picture: payload.picture,
    };
  } catch (error) {
    console.error("[Google OAuth] Token validation failed:", error instanceof Error ? error.message : String(error));
    throw new Error("Invalid token");
  }
}

/**
 * Register Google OAuth routes
 */
export function registerGoogleOAuthRoutes(app: Express) {
  // Google OAuth callback
  app.post("/auth/google/callback", async (req: Request, res: Response) => {
    try {
      const { token } = req.body;

      if (!token) {
        return res.status(400).json({ error: "token required" });
      }

      // Validate token server-side
      const payload = await validateGoogleToken(token);

      // Get database
      const db = await getDb();
      if (!db) {
        return res.status(500).json({ error: "Database unavailable" });
      }

      // Find or create user with openId format
      const openId = `google:${payload.sub}`;
      
      // Try to find by openId first
      let existingUsers = await db
        .select()
        .from(users)
        .where(eq(users.openId, openId));

      let user;
      if (existingUsers && existingUsers.length > 0) {
        user = existingUsers[0];
        // Update last signed in
        await db
          .update(users)
          .set({ lastSignedIn: new Date() })
          .where(eq(users.id, user.id));
      } else {
        // Check if there's a legacy user with googleSub but no openId
        const legacyUsers = await db
          .select()
          .from(users)
          .where(eq(users.googleSub, payload.sub));

        if (legacyUsers && legacyUsers.length > 0) {
          user = legacyUsers[0];
          // Update to set openId
          await db
            .update(users)
            .set({ openId, lastSignedIn: new Date() })
            .where(eq(users.id, user.id));
          user.openId = openId;
        } else {
          // Create new user (customer by default)
          const result = await db.insert(users).values({
            openId,
            googleSub: payload.sub,
            email: payload.email,
            name: payload.name,
            loginMethod: "google",
            role: "user",
            lastSignedIn: new Date(),
          });

          user = {
            id: result[0].insertId as number,
            openId,
            googleSub: payload.sub,
            email: payload.email,
            name: payload.name,
            role: "user",
            loginMethod: "google",
            createdAt: new Date(),
            updatedAt: new Date(),
            lastSignedIn: new Date(),
          } as any;
        }
      }

      // Create proper session token using SDK
      const sessionToken = await sdk.createSessionToken(openId, {
        name: user.name || user.email || "",
        expiresInMs: 365 * 24 * 60 * 60 * 1000, // 1 year
      });

      // Set cookie using standard cookie options
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, {
        ...cookieOptions,
        maxAge: 365 * 24 * 60 * 60 * 1000, // 1 year
      });

      // Return success and redirect to home
      return res.json({
        success: true,
        user: {
          id: user.id,
          email: user.email || "",
          name: user.name || "",
          role: user.role,
        },
        redirectUrl: "/",
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      const stack = error instanceof Error ? error.stack : "";
      console.error("[Google OAuth] Callback failed:", message);
      console.error("[Google OAuth] Stack:", stack);
      return res.status(401).json({
        error: "Authentication failed: " + message,
      });
    }
  });

  // Logout endpoint
  app.post("/auth/logout", (req: Request, res: Response) => {
    res.clearCookie(COOKIE_NAME, { path: "/" });
    return res.json({ success: true });
  });
}
