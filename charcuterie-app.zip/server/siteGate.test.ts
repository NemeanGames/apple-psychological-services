import { describe, it, expect, beforeAll, afterAll } from "vitest";
import express, { Express } from "express";
import cookieParser from "cookie-parser";
import request from "supertest";
import { registerSiteGate, renderAccessPage, redeemAccessToken, hashToken, generateToken } from "./_core/siteGate";
import * as db from "./db";

describe("Site Gate (Private Mode)", () => {
  let app: Express;
  let testToken: string;
  let testTokenHash: string;

  beforeAll(async () => {
    // Create a test Express app with the gate
    app = express();
    app.use(express.json());
    app.use(cookieParser());
    
    // Register gate
    registerSiteGate(app);
    
    // Access page and redemption
    app.get("/access", renderAccessPage);
    app.post("/api/access/redeem", redeemAccessToken);
    
    // Test endpoint that requires gate
    app.get("/api/test", (req, res) => {
      res.json({ success: true, message: "Access granted" });
    });
    
    // Create a test token in the database
    testToken = generateToken();
    testTokenHash = hashToken(testToken);
    
    try {
      await db.createAccessToken({
        tokenHash: testTokenHash,
        purpose: "site_beta",
        label: "Test Token",
        maxUses: 1,
        usesRemaining: 1,
        expiresAt: null,
      });
    } catch (err) {
      console.error("Failed to create test token:", err);
    }
  });

  it("should block anonymous requests when private mode is enabled", async () => {
    // Check if SITE_ACCESS_MODE is set to private
    const isPrivateMode = process.env.SITE_ACCESS_MODE === "private";
    
    if (!isPrivateMode) {
      console.log("Skipping test: SITE_ACCESS_MODE is not set to private");
      return;
    }
    
    const response = await request(app)
      .get("/api/test")
      .expect(403);
    
    expect(response.body).toHaveProperty("error", "site_access_required");
  });

  it("should allow access to /access page", async () => {
    const response = await request(app)
      .get("/access")
      .expect(200);
    
    expect(response.text).toContain("Boardella Beta Access");
  });

  it("should redeem a valid token", async () => {
    const response = await request(app)
      .post("/api/access/redeem")
      .send({ token: testToken })
      .expect(200);
    
    expect(response.body).toHaveProperty("success", true);
    expect(response.body).toHaveProperty("redirectTo", "/");
  });

  it("should reject an invalid token", async () => {
    const response = await request(app)
      .post("/api/access/redeem")
      .send({ token: "invalid_token_12345" })
      .expect(403);
    
    expect(response.body).toHaveProperty("error", "Invalid token");
  });
});
