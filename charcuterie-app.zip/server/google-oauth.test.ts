import { describe, it, expect, beforeEach, vi } from "vitest";
import { OAuth2Client } from "google-auth-library";

// Mock the OAuth2Client
vi.mock("google-auth-library", () => ({
  OAuth2Client: vi.fn(),
}));

describe("Google OAuth", () => {
  it("should validate token with correct claims", async () => {
    const mockTicket = {
      getPayload: () => ({
        iss: "https://accounts.google.com",
        aud: process.env.GOOGLE_CLIENT_ID,
        exp: Math.floor(Date.now() / 1000) + 3600, // 1 hour from now
        sub: "google-user-123",
        email: "user@example.com",
        name: "Test User",
        picture: "https://example.com/photo.jpg",
      }),
    };

    const mockVerifyIdToken = vi.fn().mockResolvedValue(mockTicket);
    (OAuth2Client as any).mockImplementation(() => ({
      verifyIdToken: mockVerifyIdToken,
    }));

    // Test that token validation would succeed with correct claims
    expect(mockTicket.getPayload().iss).toBe("https://accounts.google.com");
    expect(mockTicket.getPayload().sub).toBe("google-user-123");
    expect(mockTicket.getPayload().email).toBe("user@example.com");
  });

  it("should reject token with invalid issuer", () => {
    const mockTicket = {
      getPayload: () => ({
        iss: "https://invalid.com",
        aud: process.env.GOOGLE_CLIENT_ID,
        exp: Math.floor(Date.now() / 1000) + 3600,
        sub: "google-user-123",
      }),
    };

    // Invalid issuer should be rejected
    expect(mockTicket.getPayload().iss).not.toBe("https://accounts.google.com");
  });

  it("should reject expired token", () => {
    const mockTicket = {
      getPayload: () => ({
        iss: "https://accounts.google.com",
        aud: process.env.GOOGLE_CLIENT_ID,
        exp: Math.floor(Date.now() / 1000) - 3600, // 1 hour ago
        sub: "google-user-123",
      }),
    };

    const payload = mockTicket.getPayload();
    const isExpired = payload.exp && payload.exp * 1000 < Date.now();
    expect(isExpired).toBe(true);
  });

  it("should reject token with missing subject", () => {
    const mockTicket = {
      getPayload: () => ({
        iss: "https://accounts.google.com",
        aud: process.env.GOOGLE_CLIENT_ID,
        exp: Math.floor(Date.now() / 1000) + 3600,
        // Missing sub
      }),
    };

    const payload = mockTicket.getPayload();
    expect(payload.sub).toBeUndefined();
  });

  it("should extract user data from valid token", () => {
    const mockTicket = {
      getPayload: () => ({
        iss: "https://accounts.google.com",
        aud: process.env.GOOGLE_CLIENT_ID,
        exp: Math.floor(Date.now() / 1000) + 3600,
        sub: "google-user-456",
        email: "customer@boardella.com",
        name: "Jane Doe",
        picture: "https://example.com/jane.jpg",
      }),
    };

    const payload = mockTicket.getPayload();
    expect(payload.sub).toBe("google-user-456");
    expect(payload.email).toBe("customer@boardella.com");
    expect(payload.name).toBe("Jane Doe");
    expect(payload.picture).toBe("https://example.com/jane.jpg");
  });

  it("should handle multiple sign-ins from same user", () => {
    // Simulate two sign-ins from same user
    const user1 = {
      sub: "google-user-789",
      email: "user@example.com",
      name: "User Name",
    };

    const user2 = {
      sub: "google-user-789", // Same sub
      email: "user@example.com",
      name: "User Name Updated",
    };

    // Both should have same sub (stable identifier)
    expect(user1.sub).toBe(user2.sub);
    // Email should match
    expect(user1.email).toBe(user2.email);
  });

  it("should store only minimal user data", () => {
    const payload = {
      sub: "google-user-999",
      email: "minimal@example.com",
      name: "Minimal User",
      picture: "https://example.com/pic.jpg",
    };

    // Should only store sub, email, name (not picture or other fields)
    const storedData = {
      googleSub: payload.sub,
      email: payload.email,
      name: payload.name,
      // picture NOT stored
    };

    expect(storedData.googleSub).toBe("google-user-999");
    expect(storedData.email).toBe("minimal@example.com");
    expect(storedData.name).toBe("Minimal User");
    expect(storedData).not.toHaveProperty("picture");
  });
});
