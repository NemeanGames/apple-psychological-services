import { z } from "zod";

/**
 * Centralized validation schemas for all API inputs.
 * Used across tRPC procedures to ensure type-safe and validated data.
 */

// ============================================================================
// AUTH & USER SCHEMAS
// ============================================================================

export const UserRegistrationSchema = z.object({
  email: z.string().email("Invalid email address"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const UserLoginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const UserUpdateSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").optional(),
  email: z.string().email("Invalid email address").optional(),
});

export const UserRoleUpdateSchema = z.object({
  userId: z.number().positive("User ID must be positive"),
  role: z.enum(["user", "staff", "admin"]).refine(
    (val) => ["user", "staff", "admin"].includes(val),
    "Role must be user, staff, or admin"
  ),
});

// ============================================================================
// PRODUCT/BOARD SCHEMAS
// ============================================================================

export const BoardCreateSchema = z.object({
  name: z.string().min(3, "Board name must be at least 3 characters").max(255),
  description: z.string().min(10, "Description must be at least 10 characters").max(2000),
  price: z.number().positive("Price must be greater than 0"),
  imageUrl: z.string().url("Invalid image URL"),
  tags: z.array(z.string()).optional().default([]),
  size: z.enum(["small", "medium", "large"]).optional(),
  contents: z.array(z.string()).optional().default([]),
});

export const BoardUpdateSchema = BoardCreateSchema.partial().extend({
  id: z.number().positive("Board ID must be positive"),
});

export const BoardDeleteSchema = z.object({
  id: z.number().positive("Board ID must be positive"),
});

export const BoardListSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().positive().max(100).default(20),
  search: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

// ============================================================================
// ORDER SCHEMAS
// ============================================================================

export const OrderItemSchema = z.object({
  boardId: z.number().positive("Board ID must be positive"),
  quantity: z.number().int().positive("Quantity must be at least 1"),
  customDetails: z.string().optional(),
});

export const OrderCreateSchema = z.object({
  items: z.array(OrderItemSchema).min(1, "Order must contain at least one item"),
  shippingAddress: z.object({
    street: z.string().min(5, "Street address is required"),
    city: z.string().min(2, "City is required"),
    state: z.string().min(2, "State is required"),
    zipCode: z.string().regex(/^\d{5}(-\d{4})?$/, "Invalid ZIP code"),
    country: z.string().default("US"),
  }),
  email: z.string().email("Invalid email address"),
  phone: z.string().regex(/^\d{10}$/, "Phone must be 10 digits"),
});

export const OrderStatusUpdateSchema = z.object({
  orderId: z.number().positive("Order ID must be positive"),
  status: z.enum(["pending_payment", "paid", "preparing", "shipped", "delivered"]),
  trackingNumber: z.string().optional(),
});

export const OrderListSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().positive().max(100).default(20),
  status: z.enum(["pending_payment", "paid", "preparing", "shipped", "delivered"]).optional(),
});

// ============================================================================
// COMMUNITY SCHEMAS
// ============================================================================

export const CommunityPostCreateSchema = z.object({
  content: z.string().min(5, "Post must be at least 5 characters").max(5000),
  tags: z.array(z.string()).optional().default([]),
});

export const CommunityPostUpdateSchema = z.object({
  postId: z.number().positive("Post ID must be positive"),
  content: z.string().min(5, "Post must be at least 5 characters").max(5000),
});

export const CommunityPostDeleteSchema = z.object({
  postId: z.number().positive("Post ID must be positive"),
});

export const CommunityCommentCreateSchema = z.object({
  postId: z.number().positive("Post ID must be positive"),
  content: z.string().min(1, "Comment cannot be empty").max(1000),
});

export const CommunityCommentUpdateSchema = z.object({
  commentId: z.number().positive("Comment ID must be positive"),
  content: z.string().min(1, "Comment cannot be empty").max(1000),
});

export const CommunityCommentDeleteSchema = z.object({
  commentId: z.number().positive("Comment ID must be positive"),
});

export const CommunityListSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().positive().max(100).default(20),
  sortBy: z.enum(["newest", "oldest", "mostLiked"]).default("newest"),
});

// ============================================================================
// VIDEO SCHEMAS
// ============================================================================

export const VideoCreateSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(255),
  url: z.string().url("Invalid video URL"),
  platform: z.enum(["instagram", "tiktok", "youtube"]),
  creator: z.string().optional(),
  thumbnail: z.string().url("Invalid thumbnail URL").optional(),
});

export const VideoUpdateSchema = VideoCreateSchema.partial().extend({
  id: z.number().positive("Video ID must be positive"),
});

export const VideoDeleteSchema = z.object({
  id: z.number().positive("Video ID must be positive"),
});

export const VideoListSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().positive().max(100).default(20),
  platform: z.enum(["instagram", "tiktok", "youtube"]).optional(),
});

// ============================================================================
// CART SCHEMAS
// ============================================================================

export const CartAddItemSchema = z.object({
  boardId: z.number().positive("Board ID must be positive"),
  quantity: z.number().int().positive("Quantity must be at least 1"),
  customDetails: z.string().optional(),
});

export const CartUpdateItemSchema = z.object({
  boardId: z.number().positive("Board ID must be positive"),
  quantity: z.number().int().positive("Quantity must be at least 1"),
});

export const CartRemoveItemSchema = z.object({
  boardId: z.number().positive("Board ID must be positive"),
});

// ============================================================================
// PAYMENT SCHEMAS
// ============================================================================

export const StripeCheckoutSchema = z.object({
  items: z.array(OrderItemSchema).min(1, "Cart must contain at least one item"),
  email: z.string().email("Invalid email address"),
});

export const StripeWebhookSchema = z.object({
  type: z.string(),
  data: z.object({
    object: z.any(),
  }),
});

// ============================================================================
// CMS SCHEMAS (Videos & Buckets)
// ============================================================================

export const CMSVideoCreateSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(255),
  description: z.string().max(2000).optional(),
  platform: z.enum(["instagram", "tiktok", "youtube", "uploaded"]),
  platformUrl: z.string().url("Invalid platform URL"),
  thumbnailUrl: z.string().url("Invalid thumbnail URL").optional(),
  creator: z.string().max(255).optional(),
  creatorHandle: z.string().max(255).optional(),
  tags: z.array(z.string()).optional().default([]),
  status: z.enum(["draft", "review", "scheduled", "published", "archived"]).default("draft"),
  contentType: z.enum(["bts", "product", "testimonial", "event", "other"]).default("other"),
  campaign: z.string().max(255).optional(),
  goLiveAt: z.date().optional(),
  expiresAt: z.date().optional(),
});

export const CMSVideoUpdateSchema = CMSVideoCreateSchema.partial();

export const CMSVideoStatusUpdateSchema = z.object({
  videoId: z.number().positive("Video ID must be positive"),
  status: z.enum(["draft", "review", "scheduled", "published", "archived"]),
});

export const CMSBucketCreateSchema = z.object({
  name: z.string().min(3, "Bucket name must be at least 3 characters").max(255),
  description: z.string().max(2000).optional(),
  isPublished: z.number().int().min(0).max(1).default(0),
  displayOrder: z.number().int().nonnegative().default(0),
});

export const CMSBucketUpdateSchema = CMSBucketCreateSchema.partial();

export const CMSBucketAddVideoSchema = z.object({
  bucketId: z.number().positive("Bucket ID must be positive"),
  videoId: z.number().positive("Video ID must be positive"),
  sortOrder: z.number().int().nonnegative().default(0),
});

export const CMSBucketReorderSchema = z.object({
  bucketId: z.number().positive("Bucket ID must be positive"),
  videoId: z.number().positive("Video ID must be positive"),
  sortOrder: z.number().int().nonnegative(),
});

export const CMSEmbedValidationSchema = z.object({
  platform: z.enum(["instagram", "tiktok", "youtube"]),
  url: z.string().url("Invalid URL"),
});

export const CMSVideoIntakeSchema = z.object({
  platformUrl: z.string().url("Invalid platform URL"),
  title: z.string().min(3, "Title must be at least 3 characters").max(255).optional(),
  status: z.enum(["draft", "published"]).default("draft"),
  contentType: z.enum(["bts", "product", "testimonial", "event", "other"]).optional(),
  bucketId: z.number().positive("Bucket ID must be positive").optional(),
});

// ============================================================================
// ADMIN SCHEMAS
// ============================================================================

export const AdminAnalyticsSchema = z.object({
  startDate: z.date().optional(),
  endDate: z.date().optional(),
});

export const AdminSettingsUpdateSchema = z.object({
  businessName: z.string().optional(),
  businessEmail: z.string().email().optional(),
  businessPhone: z.string().optional(),
  shippingRate: z.number().nonnegative().optional(),
  taxRate: z.number().nonnegative().max(1).optional(),
});

// ============================================================================
// EXPORT TYPES
// ============================================================================

export type UserRegistration = z.infer<typeof UserRegistrationSchema>;
export type UserLogin = z.infer<typeof UserLoginSchema>;
export type UserUpdate = z.infer<typeof UserUpdateSchema>;
export type UserRoleUpdate = z.infer<typeof UserRoleUpdateSchema>;

export type BoardCreate = z.infer<typeof BoardCreateSchema>;
export type BoardUpdate = z.infer<typeof BoardUpdateSchema>;
export type BoardDelete = z.infer<typeof BoardDeleteSchema>;
export type BoardList = z.infer<typeof BoardListSchema>;

export type OrderItem = z.infer<typeof OrderItemSchema>;
export type OrderCreate = z.infer<typeof OrderCreateSchema>;
export type OrderStatusUpdate = z.infer<typeof OrderStatusUpdateSchema>;
export type OrderList = z.infer<typeof OrderListSchema>;

export type CommunityPostCreate = z.infer<typeof CommunityPostCreateSchema>;
export type CommunityPostUpdate = z.infer<typeof CommunityPostUpdateSchema>;
export type CommunityPostDelete = z.infer<typeof CommunityPostDeleteSchema>;
export type CommunityCommentCreate = z.infer<typeof CommunityCommentCreateSchema>;
export type CommunityCommentUpdate = z.infer<typeof CommunityCommentUpdateSchema>;
export type CommunityCommentDelete = z.infer<typeof CommunityCommentDeleteSchema>;
export type CommunityList = z.infer<typeof CommunityListSchema>;

export type VideoCreate = z.infer<typeof VideoCreateSchema>;
export type VideoUpdate = z.infer<typeof VideoUpdateSchema>;
export type VideoDelete = z.infer<typeof VideoDeleteSchema>;
export type VideoList = z.infer<typeof VideoListSchema>;

export type CartAddItem = z.infer<typeof CartAddItemSchema>;
export type CartUpdateItem = z.infer<typeof CartUpdateItemSchema>;
export type CartRemoveItem = z.infer<typeof CartRemoveItemSchema>;

export type StripeCheckout = z.infer<typeof StripeCheckoutSchema>;
export type StripeWebhook = z.infer<typeof StripeWebhookSchema>;

export type AdminAnalytics = z.infer<typeof AdminAnalyticsSchema>;
export type AdminSettingsUpdate = z.infer<typeof AdminSettingsUpdateSchema>;

export type CMSVideoCreate = z.infer<typeof CMSVideoCreateSchema>;
export type CMSVideoUpdate = z.infer<typeof CMSVideoUpdateSchema>;
export type CMSVideoIntake = z.infer<typeof CMSVideoIntakeSchema>;
export type CMSVideoStatusUpdate = z.infer<typeof CMSVideoStatusUpdateSchema>;
export type CMSBucketCreate = z.infer<typeof CMSBucketCreateSchema>;
export type CMSBucketUpdate = z.infer<typeof CMSBucketUpdateSchema>;
export type CMSBucketAddVideo = z.infer<typeof CMSBucketAddVideoSchema>;
export type CMSBucketReorder = z.infer<typeof CMSBucketReorderSchema>;
export type CMSEmbedValidation = z.infer<typeof CMSEmbedValidationSchema>;
