import { Request, Response, NextFunction } from "express";
import { getSecurityHeaders } from "./security";

/**
 * Middleware to apply security headers to all HTTP responses.
 * Should be applied early in the Express middleware chain.
 */
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  // Apply all security headers
  const headers = getSecurityHeaders();
  Object.entries(headers).forEach(([key, value]) => {
    res.setHeader(key, value);
  });

  // Additional security headers
  res.setHeader("Server", "Boardella"); // Hide Express version
  res.setHeader("X-Powered-By", "Boardella"); // Custom header instead of Express

  next();
}

/**
 * Middleware to validate CSRF tokens on state-changing requests.
 * Should be applied to POST, PUT, DELETE routes.
 */
export function csrfProtectionMiddleware(req: Request, res: Response, next: NextFunction) {
  // Skip CSRF check for GET, HEAD, OPTIONS requests
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    return next();
  }

  // Get CSRF token from request
  const token = req.headers["x-csrf-token"] as string || req.body?.csrfToken;

  // Get CSRF token from session (stored in cookies/context)
  const sessionToken = (req as any).csrfToken || (req.headers["x-session-token"] as string);

  if (!token || !sessionToken || token !== sessionToken) {
    return res.status(403).json({
      error: "CSRF token validation failed",
      code: "CSRF_INVALID",
    });
  }

  next();
}

/**
 * Middleware for rate limiting to prevent brute force and DoS attacks.
 * Uses in-memory store (for production, use Redis).
 */
interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

const rateLimitStore: RateLimitStore = {};

export function createRateLimitMiddleware(
  windowMs: number = 60000, // 1 minute
  maxRequests: number = 100,
  keyGenerator: (req: Request) => string = (req) => req.ip || "unknown"
) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = keyGenerator(req);
    const now = Date.now();

    // Initialize or reset if window expired
    if (!rateLimitStore[key] || rateLimitStore[key].resetTime < now) {
      rateLimitStore[key] = {
        count: 0,
        resetTime: now + windowMs,
      };
    }

    // Increment request count
    rateLimitStore[key].count++;

    // Set rate limit headers
    res.setHeader("X-RateLimit-Limit", maxRequests);
    res.setHeader("X-RateLimit-Remaining", Math.max(0, maxRequests - rateLimitStore[key].count));
    res.setHeader("X-RateLimit-Reset", rateLimitStore[key].resetTime);

    // Check if limit exceeded
    if (rateLimitStore[key].count > maxRequests) {
      return res.status(429).json({
        error: "Too many requests",
        code: "RATE_LIMIT_EXCEEDED",
        retryAfter: Math.ceil((rateLimitStore[key].resetTime - now) / 1000),
      });
    }

    next();
  };
}

/**
 * Middleware for request body size limiting to prevent large payload attacks.
 */
export function requestSizeLimitMiddleware(maxSize: string = "10mb") {
  return (req: Request, res: Response, next: NextFunction) => {
    const contentLength = req.headers["content-length"];

    if (contentLength) {
      const bytes = parseInt(contentLength, 10);
      const maxBytes = parseSize(maxSize);

      if (bytes > maxBytes) {
        return res.status(413).json({
          error: "Payload too large",
          code: "PAYLOAD_TOO_LARGE",
          maxSize,
        });
      }
    }

    next();
  };
}

/**
 * Parse size string (e.g., "10mb", "1gb") to bytes.
 */
function parseSize(size: string): number {
  const units: Record<string, number> = {
    b: 1,
    kb: 1024,
    mb: 1024 * 1024,
    gb: 1024 * 1024 * 1024,
  };

  const match = size.toLowerCase().match(/^(\d+)(b|kb|mb|gb)$/);
  if (!match) {
    throw new Error(`Invalid size format: ${size}`);
  }

  const [, value, unit] = match;
  return parseInt(value, 10) * (units[unit] || 1);
}

/**
 * Middleware to validate and sanitize request headers.
 * Prevents header injection attacks.
 */
export function headerValidationMiddleware(req: Request, res: Response, next: NextFunction) {
  // Check for suspicious header values
  const suspiciousPatterns = [
    /[\r\n]/g, // CRLF injection
    /javascript:/i, // JavaScript protocol
    /<script/i, // Script tags
  ];

  const headerNames = Object.keys(req.headers);

  for (const headerName of headerNames) {
    const headerValue = req.headers[headerName];

    if (typeof headerValue === "string") {
      for (const pattern of suspiciousPatterns) {
        if (pattern.test(headerValue)) {
          return res.status(400).json({
            error: "Invalid header value",
            code: "INVALID_HEADER",
          });
        }
      }
    }
  }

  next();
}

/**
 * Middleware to log security events.
 * Useful for monitoring and alerting on suspicious activity.
 */
export function securityLoggingMiddleware(req: Request, res: Response, next: NextFunction) {
  const startTime = Date.now();

  // Log on response finish
  res.on("finish", () => {
    const duration = Date.now() - startTime;
    const statusCode = res.statusCode;

    // Log security-relevant events
    if (statusCode >= 400) {
      console.log(
        `[SECURITY] ${req.method} ${req.path} - Status: ${statusCode} - IP: ${req.ip} - Duration: ${duration}ms`
      );
    }

    // Log rate limit violations
    if (statusCode === 429) {
      console.warn(`[RATE_LIMIT] IP: ${req.ip} - Path: ${req.path}`);
    }

    // Log CSRF failures
    if (statusCode === 403) {
      console.warn(`[CSRF_FAILURE] IP: ${req.ip} - Path: ${req.path}`);
    }
  });

  next();
}
