import { describe, it, expect } from "vitest";
import {
  encodeHtmlEntity,
  decodeHtmlEntity,
  sanitizeMarkdown,
  validateImageUrl,
  sanitizeImageUrl,
  sanitizeString,
  sanitizeEmail,
  sanitizePhoneNumber,
  sanitizeFileName,
  validateRedirectUrl,
  generateCSRFToken,
  validateCSRFToken,
} from "./security";

describe("Security Utilities", () => {
  describe("HTML Entity Encoding", () => {
    it("should encode HTML special characters", () => {
      expect(encodeHtmlEntity("<script>alert('xss')</script>")).toBe(
        "&lt;script&gt;alert(&#39;xss&#39;)&lt;&#x2F;script&gt;"
      );
    });

    it("should encode ampersands", () => {
      expect(encodeHtmlEntity("Tom & Jerry")).toBe("Tom &amp; Jerry");
    });

    it("should encode quotes", () => {
      expect(encodeHtmlEntity('Say "Hello"')).toBe("Say &quot;Hello&quot;");
    });

    it("should handle empty strings", () => {
      expect(encodeHtmlEntity("")).toBe("");
    });

    it("should decode HTML entities", () => {
      expect(decodeHtmlEntity("&lt;div&gt;")).toBe("<div>");
      expect(decodeHtmlEntity("&amp;")).toBe("&");
      expect(decodeHtmlEntity("&quot;")).toBe('"');
    });
  });

  describe("Markdown Sanitization", () => {
    it("should remove script tags", () => {
      const input = "Hello <script>alert('xss')</script> World";
      const result = sanitizeMarkdown(input);
      expect(result).not.toContain("<script>");
      expect(result).not.toContain("alert");
    });

    it("should remove event handlers", () => {
      const input = '<img src="x" onerror="alert(\'xss\')">';
      const result = sanitizeMarkdown(input);
      expect(result).not.toContain("onerror");
    });

    it("should remove javascript protocol", () => {
      const input = '<a href="javascript:alert(\'xss\')">Click</a>';
      const result = sanitizeMarkdown(input);
      expect(result).not.toContain("javascript:");
    });

    it("should remove data:text/html protocol", () => {
      const input = '<iframe src="data:text/html,<script>alert(1)</script>"></iframe>';
      const result = sanitizeMarkdown(input);
      expect(result).not.toContain("data:text/html");
    });

    it("should preserve safe markdown", () => {
      const input = "# Heading\n\n**Bold** and *italic* text";
      const result = sanitizeMarkdown(input);
      expect(result).toContain("# Heading");
      expect(result).toContain("**Bold**");
    });
  });

  describe("Image URL Validation", () => {
    it("should accept https URLs", () => {
      expect(validateImageUrl("https://example.com/image.png")).toBe(true);
    });

    it("should accept http URLs", () => {
      expect(validateImageUrl("http://example.com/image.jpg")).toBe(true);
    });

    it("should accept data URLs for images", () => {
      expect(validateImageUrl("data:image/png;base64,iVBORw0KGgo=")).toBe(true);
      expect(validateImageUrl("data:image/jpeg;base64,/9j/4AAQSkZJRg==")).toBe(true);
    });

    it("should reject data URLs for non-images", () => {
      expect(validateImageUrl("data:text/html,<script>alert(1)</script>")).toBe(false);
    });

    it("should reject javascript protocol", () => {
      expect(validateImageUrl("javascript:alert('xss')")).toBe(false);
    });

    it("should reject invalid URLs", () => {
      expect(validateImageUrl("not a url")).toBe(false);
    });
  });

  describe("Image URL Sanitization", () => {
    it("should return valid URLs unchanged", () => {
      const url = "https://example.com/image.png";
      expect(sanitizeImageUrl(url)).toBe(url);
    });

    it("should return default URL for invalid URLs", () => {
      expect(sanitizeImageUrl("javascript:alert('xss')")).toBe("/images/placeholder.png");
    });

    it("should use custom default URL", () => {
      expect(sanitizeImageUrl("invalid", "/custom-placeholder.png")).toBe("/custom-placeholder.png");
    });
  });

  describe("String Sanitization", () => {
    it("should remove null bytes", () => {
      expect(sanitizeString("Hello\x00World")).toBe("HelloWorld");
    });

    it("should remove control characters", () => {
      expect(sanitizeString("Hello\x01\x02World")).toBe("HelloWorld");
    });

    it("should trim excessive whitespace", () => {
      expect(sanitizeString("Hello    World")).toBe("Hello World");
    });

    it("should truncate to max length", () => {
      const longString = "a".repeat(10001);
      const result = sanitizeString(longString, 10000);
      expect(result.length).toBe(10000);
    });

    it("should normalize newlines and tabs to spaces", () => {
      const input = "Line1\nLine2\tTabbed";
      const result = sanitizeString(input);
      // Whitespace is normalized to single spaces
      expect(result).toBe("Line1 Line2 Tabbed");
    });
  });

  describe("Email Sanitization", () => {
    it("should accept valid emails", () => {
      expect(sanitizeEmail("user@example.com")).toBe("user@example.com");
    });

    it("should convert to lowercase", () => {
      expect(sanitizeEmail("User@EXAMPLE.COM")).toBe("user@example.com");
    });

    it("should trim whitespace", () => {
      expect(sanitizeEmail("  user@example.com  ")).toBe("user@example.com");
    });

    it("should reject invalid emails", () => {
      expect(sanitizeEmail("not-an-email")).toBe("");
      expect(sanitizeEmail("@example.com")).toBe("");
      expect(sanitizeEmail("user@")).toBe("");
    });
  });

  describe("Phone Number Sanitization", () => {
    it("should keep digits and common separators", () => {
      expect(sanitizePhoneNumber("(555) 123-4567")).toBe("(555) 123-4567");
    });

    it("should remove invalid characters", () => {
      expect(sanitizePhoneNumber("555-123-4567abc")).toBe("555-123-4567");
    });

    it("should handle plus sign for international", () => {
      expect(sanitizePhoneNumber("+1-555-123-4567")).toBe("+1-555-123-4567");
    });

    it("should limit length to prevent DoS", () => {
      const longPhone = "1234567890".repeat(5);
      const result = sanitizePhoneNumber(longPhone);
      expect(result.length).toBeLessThanOrEqual(20);
    });
  });

  describe("File Name Sanitization", () => {
    it("should remove path separators", () => {
      expect(sanitizeFileName("../../../etc/passwd")).toBe("etcpasswd");
    });

    it("should remove leading dots", () => {
      expect(sanitizeFileName("...hidden.txt")).toBe("hidden.txt");
    });

    it("should remove null bytes", () => {
      expect(sanitizeFileName("file\x00.txt")).toBe("file.txt");
    });

    it("should limit length to 255 characters", () => {
      const longName = "a".repeat(300) + ".txt";
      const result = sanitizeFileName(longName);
      expect(result.length).toBeLessThanOrEqual(255);
    });

    it("should handle normal file names", () => {
      expect(sanitizeFileName("document.pdf")).toBe("document.pdf");
    });
  });

  describe("Redirect URL Validation", () => {
    it("should allow relative URLs", () => {
      expect(validateRedirectUrl("/dashboard")).toBe(true);
      expect(validateRedirectUrl("/user/profile")).toBe(true);
    });

    it("should reject protocol-relative URLs", () => {
      expect(validateRedirectUrl("//evil.com")).toBe(false);
    });

    it("should reject absolute URLs to other domains", () => {
      expect(validateRedirectUrl("https://evil.com")).toBe(false);
    });

    it("should allow URLs from allowed origins", () => {
      expect(validateRedirectUrl("https://example.com/page", ["https://example.com"])).toBe(true);
    });

    it("should reject invalid URLs", () => {
      expect(validateRedirectUrl("not a valid url")).toBe(false);
    });
  });

  describe("CSRF Token Generation and Validation", () => {
    it("should generate random tokens", () => {
      const token1 = generateCSRFToken();
      const token2 = generateCSRFToken();
      expect(token1).not.toBe(token2);
    });

    it("should generate 64-character hex strings", () => {
      const token = generateCSRFToken();
      expect(token).toMatch(/^[a-f0-9]{64}$/);
    });

    it("should validate matching tokens", () => {
      const token = generateCSRFToken();
      expect(validateCSRFToken(token, token)).toBe(true);
    });

    it("should reject non-matching tokens", () => {
      const token1 = generateCSRFToken();
      const token2 = generateCSRFToken();
      expect(validateCSRFToken(token1, token2)).toBe(false);
    });

    it("should reject empty tokens", () => {
      expect(validateCSRFToken("", "token")).toBe(false);
      expect(validateCSRFToken("token", "")).toBe(false);
    });

    it("should use constant-time comparison", () => {
      const token = generateCSRFToken();
      // Both should take similar time regardless of where they differ
      const start1 = Date.now();
      validateCSRFToken("a" + token.slice(1), token);
      const time1 = Date.now() - start1;

      const start2 = Date.now();
      validateCSRFToken(token.slice(0, -1) + "z", token);
      const time2 = Date.now() - start2;

      // Times should be similar (within 10ms due to JS timing variance)
      expect(Math.abs(time1 - time2)).toBeLessThan(10);
    });
  });
});
