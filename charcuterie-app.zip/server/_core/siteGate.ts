import { Express, Request, Response, NextFunction } from "express";
import { jwtVerify, SignJWT } from "jose";
import crypto from "crypto";
import { getDb, getAccessTokenByHash, updateAccessTokenUses } from "../db";

const SITE_BETA_COOKIE_NAME = "boardella_site_beta";

/**
 * Whitelist gate middleware for private mode
 * When SITE_ACCESS_MODE=private, all requests are blocked unless:
 * 1. Request is to /access or /api/access/redeem (entry points)
 * 2. Request has valid admin session cookie
 * 3. Request has valid site_beta access cookie
 */

function getJwtSecret(): Uint8Array {
  const raw = process.env.JWT_SECRET;
  if (!raw) throw new Error("Missing JWT_SECRET");
  return new TextEncoder().encode(raw);
}

export function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export function generateToken(): string {
  return "site_beta_" + crypto.randomBytes(32).toString("hex");
}

export function registerSiteGate(app: Express) {
  const accessMode = process.env.SITE_ACCESS_MODE || "public";

  if (accessMode !== "private") {
    console.log("[SiteGate] Access mode is public, gate disabled");
    return;
  }

  console.log("[SiteGate] Access mode is private, gate enabled");

  // Middleware to check access
  app.use(async (req: Request, res: Response, next: NextFunction) => {
    // Allow entry points
    if (req.path === "/access" || req.path === "/api/access/redeem") {
      return next();
    }

    // Allow OAuth callbacks (Manus and Google)
    if (req.path === "/api/oauth/callback" || req.path === "/auth/google/callback") {
      return next();
    }

    // Check for valid session (admin bypass)
    const user = (req as any).user;
    if (user && (user.role === "admin" || user.role === "employee")) {
      return next();
    }

    // Check for valid site beta access cookie
    const cookie = req.cookies[SITE_BETA_COOKIE_NAME];
    if (cookie) {
      try {
        const decoded = await jwtVerify(cookie, getJwtSecret()) as any;

        if (decoded.payload?.scope === "site_access") {
          return next();
        }
      } catch (err) {
        console.error("[SiteGate] Invalid cookie:", err);
      }
    }

    // Access denied
    if (req.path.startsWith("/api/")) {
      return res.status(403).json({
        error: "site_access_required",
        accessUrl: "/access",
      });
    }

    // Redirect to access page for non-API requests
    return res.redirect("/access");
  });
}

/**
 * Render the access page (GET /access)
 */
export async function renderAccessPage(req: Request, res: Response) {
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Boardella - Access Required</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-width: 500px;
      width: 100%;
      padding: 40px;
    }
    h1 {
      color: #333;
      margin-bottom: 10px;
      font-size: 28px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .icon {
      font-size: 32px;
    }
    p {
      color: #666;
      margin-bottom: 30px;
      line-height: 1.6;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    label {
      display: block;
      color: #333;
      font-weight: 500;
      margin-bottom: 5px;
    }
    input {
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 16px;
      font-family: monospace;
    }
    input:focus {
      outline: none;
      border-color: #667eea;
      box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    button {
      padding: 12px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s;
    }
    button:hover {
      transform: translateY(-2px);
    }
    button:active {
      transform: translateY(0);
    }
    .error {
      display: none;
      padding: 12px;
      background: #fee;
      border: 1px solid #fcc;
      border-radius: 6px;
      color: #c33;
      margin-bottom: 15px;
    }
    .success {
      display: none;
      padding: 12px;
      background: #efe;
      border: 1px solid #cfc;
      border-radius: 6px;
      color: #3c3;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1><span class="icon">🔐</span> Boardella Beta Access</h1>
    <p>This site is currently in private beta. Enter your access token below to continue.</p>
    
    <div id="error" class="error"></div>
    <div id="success" class="success"></div>

    <form id="accessForm">
      <label for="token">Access Token</label>
      <input 
        type="text" 
        id="token" 
        placeholder="site_beta_..." 
        required 
        autocomplete="off"
      >
      <button type="submit">Grant Access</button>
    </form>
  </div>

  <script>
    document.getElementById('accessForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const token = document.getElementById('token').value.trim();
      const errorDiv = document.getElementById('error');
      const successDiv = document.getElementById('success');
      
      errorDiv.style.display = 'none';
      successDiv.style.display = 'none';

      try {
        const response = await fetch('/api/access/redeem', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token }),
        });

        if (response.ok) {
          successDiv.textContent = 'Access granted! Redirecting...';
          successDiv.style.display = 'block';
          setTimeout(() => {
            window.location.href = '/';
          }, 1500);
        } else {
          const data = await response.json();
          errorDiv.textContent = data.error || 'Invalid token';
          errorDiv.style.display = 'block';
        }
      } catch (err) {
        errorDiv.textContent = 'Error: ' + (err instanceof Error ? err.message : 'Unknown error');
        errorDiv.style.display = 'block';
      }
    });
  </script>
</body>
</html>
  `;

  res.setHeader("Content-Type", "text/html");
  res.send(html);
}

/**
 * Handle POST /api/access/redeem
 * Validates token and sets site_beta access cookie
 */
export async function redeemAccessToken(req: Request, res: Response) {
  const { token } = req.body;

  if (!token || typeof token !== "string") {
    return res.status(400).json({ error: "Token required" });
  }

  try {
    const tokenHash = hashToken(token);
    const accessToken = await getAccessTokenByHash(tokenHash);

    if (!accessToken) {
      return res.status(403).json({ error: "Invalid token" });
    }

    // Check if revoked
    if (accessToken.revokedAt) {
      return res.status(403).json({ error: "Token revoked" });
    }

    // Check if expired
    if (accessToken.expiresAt && new Date() > accessToken.expiresAt) {
      return res.status(403).json({ error: "Token expired" });
    }

    // Check if uses remaining (skip check for unlimited tokens where usesRemaining = -1)
    const usesRemaining = accessToken.usesRemaining ?? 0;
    if (usesRemaining !== -1 && usesRemaining <= 0) {
      return res.status(403).json({ error: "Token exhausted" });
    }

    // Decrement uses (only if not unlimited)
    if (usesRemaining !== -1) {
      const remaining = usesRemaining - 1;
      await updateAccessTokenUses(accessToken.id, remaining);
    }

    // Create JWT cookie using jose
    const maxDays = parseInt(process.env.COOKIE_MAX_DAYS || "30");
    const now = Math.floor(Date.now() / 1000);
    const exp = now + maxDays * 24 * 60 * 60;

    const cookieValue = await new SignJWT({
      sub: String(accessToken.id),
      scope: "site_access",
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt(now)
      .setExpirationTime(exp)
      .sign(getJwtSecret());

    // Set httpOnly, secure, sameSite cookie
    res.cookie(SITE_BETA_COOKIE_NAME, cookieValue, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: maxDays * 24 * 60 * 60 * 1000,
      path: "/",
    });

    return res.json({ success: true, redirectTo: "/" });
  } catch (err) {
    console.error("[SiteGate] Redemption error:", err);
    return res.status(500).json({ error: "Server error" });
  }
}
