/**
 * Security utilities for output encoding, XSS prevention, and content sanitization.
 * All user-generated content should be processed through these functions before
 * being sent to the client or stored in the database.
 */

/**
 * HTML entity encoding to prevent XSS attacks.
 * Converts special HTML characters to their entity equivalents.
 */
export function encodeHtmlEntity(text: string): string {
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
    "/": "&#x2F;",
  };
  return text.replace(/[&<>"'\/]/g, (char) => map[char] || char);
}

/**
 * Decode HTML entities (reverse of encodeHtmlEntity).
 * Use only when you need to display previously encoded content.
 */
export function decodeHtmlEntity(text: string): string {
  const map: Record<string, string> = {
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">",
    "&quot;": '"',
    "&#39;": "'",
    "&#x2F;": "/",
  };
  return text.replace(/&[a-z]+;|&#[0-9]+;|&#x[0-9a-f]+;/gi, (entity) => map[entity] || entity);
}

/**
 * Sanitize markdown content to prevent XSS while preserving formatting.
 * Removes potentially dangerous HTML/script tags while allowing safe markdown.
 */
export function sanitizeMarkdown(content: string): string {
  // Remove script tags and their content
  let sanitized = content.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");

  // Remove event handlers
  sanitized = sanitized.replace(/on\w+\s*=\s*["'][^"']*["']/gi, "");
  sanitized = sanitized.replace(/on\w+\s*=\s*[^\s>]*/gi, "");

  // Remove dangerous HTML tags but keep safe markdown-related ones
  const dangerousTags = ["iframe", "object", "embed", "link", "style", "meta"];
  dangerousTags.forEach((tag) => {
    const regex = new RegExp(`<${tag}\\b[^<]*(?:(?!<\\/${tag}>)<[^<]*)*<\\/${tag}>`, "gi");
    sanitized = sanitized.replace(regex, "");
  });

  // Remove javascript: protocol
  sanitized = sanitized.replace(/javascript:/gi, "");

  // Remove data: protocol (can be used for XSS)
  sanitized = sanitized.replace(/data:text\/html/gi, "");

  return sanitized.trim();
}

/**
 * Validate and sanitize image URLs to prevent injection attacks.
 * Only allows http(s) and data URLs with image MIME types.
 */
export function validateImageUrl(url: string): boolean {
  try {
    const urlObj = new URL(url);

    // Allow http and https
    if (urlObj.protocol === "http:" || urlObj.protocol === "https:") {
      return true;
    }

    // Allow data URLs only for images
    if (urlObj.protocol === "data:") {
      return /^data:image\/(png|jpg|jpeg|gif|webp|svg\+xml);/.test(url);
    }

    return false;
  } catch {
    return false;
  }
}

/**
 * Sanitize image URL to ensure it's safe.
 * Returns the URL if valid, otherwise returns a default placeholder.
 */
export function sanitizeImageUrl(url: string, defaultUrl = "/images/placeholder.png"): string {
  if (validateImageUrl(url)) {
    return url;
  }
  return defaultUrl;
}

/**
 * Sanitize user input strings to prevent injection attacks.
 * Removes null bytes, control characters, and excessive whitespace.
 */
export function sanitizeString(input: string, maxLength = 10000): string {
  // Remove null bytes
  let sanitized = input.replace(/\0/g, "");

  // Remove control characters (except newlines, tabs)
  sanitized = sanitized.replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, "");

  // Trim excessive whitespace
  sanitized = sanitized.replace(/\s+/g, " ").trim();

  // Truncate to max length
  if (sanitized.length > maxLength) {
    sanitized = sanitized.substring(0, maxLength);
  }

  return sanitized;
}

/**
 * Sanitize email addresses to prevent injection attacks.
 * Validates format and removes potentially dangerous characters.
 */
export function sanitizeEmail(email: string): string {
  const sanitized = email.toLowerCase().trim();

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(sanitized)) {
    return "";
  }

  return sanitized;
}

/**
 * Sanitize phone numbers to prevent injection attacks.
 * Keeps only digits and common separators.
 */
export function sanitizePhoneNumber(phone: string): string {
  // Remove all non-digit and non-separator characters
  const sanitized = phone.replace(/[^\d\-\(\)\s\+]/g, "").trim();

  // Limit length to prevent DoS
  return sanitized.substring(0, 20);
}

/**
 * Escape JSON strings to prevent injection in JSON responses.
 * Ensures special characters are properly escaped.
 */
export function escapeJsonString(str: string): string {
  return str
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r")
    .replace(/\t/g, "\\t")
    .replace(/\b/g, "\\b")
    .replace(/\f/g, "\\f");
}

/**
 * Validate URL to prevent open redirect attacks.
 * Only allows relative URLs and same-origin URLs.
 */
export function validateRedirectUrl(url: string, allowedOrigins: string[] = []): boolean {
  try {
    // Allow relative URLs
    if (url.startsWith("/") && !url.startsWith("//")) {
      return true;
    }

    // Check against allowed origins
    const urlObj = new URL(url);
    if (allowedOrigins.includes(urlObj.origin)) {
      return true;
    }

    return false;
  } catch {
    return false;
  }
}

/**
 * Sanitize file names to prevent directory traversal attacks.
 * Removes path separators and dangerous characters.
 */
export function sanitizeFileName(fileName: string): string {
  // Remove path separators
  let sanitized = fileName.replace(/[\/\\]/g, "");

  // Remove null bytes
  sanitized = sanitized.replace(/\0/g, "");

  // Remove leading dots (prevent hidden files and parent directory access)
  sanitized = sanitized.replace(/^\.+/, "");

  // Remove multiple consecutive dots
  sanitized = sanitized.replace(/\.{2,}/g, ".");

  // Limit length
  sanitized = sanitized.substring(0, 255);

  return sanitized || "file";
}

/**
 * Create a Content Security Policy (CSP) header value.
 * Restricts resource loading to prevent XSS and injection attacks.
 */
export function generateCSPHeader(): string {
  const policies = [
    "default-src 'self'", // Default: only same-origin
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // Scripts: allow same-origin and inline (for Vite)
    "style-src 'self' 'unsafe-inline'", // Styles: allow same-origin and inline
    "img-src 'self' data: https:", // Images: allow same-origin, data URLs, and https
    "font-src 'self' data:", // Fonts: allow same-origin and data URLs
    "connect-src 'self' https:", // API calls: allow same-origin and https
    "frame-ancestors 'none'", // Prevent framing
    "base-uri 'self'", // Base tag: only same-origin
    "form-action 'self'", // Form submissions: only same-origin
  ];

  return policies.join("; ");
}

/**
 * Get all security headers as an object.
 * Should be applied to all HTTP responses.
 */
export function getSecurityHeaders(): Record<string, string> {
  return {
    // Content Security Policy
    "Content-Security-Policy": generateCSPHeader(),

    // Prevent MIME type sniffing
    "X-Content-Type-Options": "nosniff",

    // Prevent clickjacking
    "X-Frame-Options": "DENY",

    // Enable XSS protection in older browsers
    "X-XSS-Protection": "1; mode=block",

    // Referrer policy
    "Referrer-Policy": "strict-origin-when-cross-origin",

    // Permissions policy (formerly Feature-Policy)
    "Permissions-Policy":
      "geolocation=(), microphone=(), camera=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()",

    // HSTS (HTTP Strict Transport Security)
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",

    // Prevent caching of sensitive data
    "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
    "Pragma": "no-cache",
    "Expires": "0",
  };
}

/**
 * Validate CSRF token.
 * Compares token from request with session token.
 */
export function validateCSRFToken(requestToken: string, sessionToken: string): boolean {
  if (!requestToken || !sessionToken) {
    return false;
  }

  // Use constant-time comparison to prevent timing attacks
  return constantTimeCompare(requestToken, sessionToken);
}

/**
 * Constant-time string comparison to prevent timing attacks.
 * Compares strings in constant time regardless of where they differ.
 */
function constantTimeCompare(a: string, b: string): boolean {
  if (a.length !== b.length) {
    return false;
  }

  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }

  return result === 0;
}

/**
 * Generate a random CSRF token.
 * Should be stored in session and validated on state-changing requests.
 */
export function generateCSRFToken(): string {
  const crypto = require("crypto");
  return crypto.randomBytes(32).toString("hex");
}
