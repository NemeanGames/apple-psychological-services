import { describe, it, expect } from "vitest";

const ADMIN_EMAILS = [
  "adrianarvizu1994@gmail.com",
  "eriflores21@gmail.com",
];

describe("Admin Access Control", () => {
  it("should allow authorized admin emails", () => {
    const authorizedEmails = [
      "adrianarvizu1994@gmail.com",
      "eriflores21@gmail.com",
    ];

    authorizedEmails.forEach((email) => {
      const isAuthorized = ADMIN_EMAILS.includes(email);
      expect(isAuthorized).toBe(true);
    });
  });

  it("should deny unauthorized emails", () => {
    const unauthorizedEmails = [
      "customer@example.com",
      "user@boardella.com",
      "admin@other.com",
    ];

    unauthorizedEmails.forEach((email) => {
      const isAuthorized = ADMIN_EMAILS.includes(email);
      expect(isAuthorized).toBe(false);
    });
  });

  it("should deny empty or null emails", () => {
    expect(ADMIN_EMAILS.includes("")).toBe(false);
    expect(ADMIN_EMAILS.includes(null as any)).toBe(false);
    expect(ADMIN_EMAILS.includes(undefined as any)).toBe(false);
  });

  it("should be case-sensitive for email matching", () => {
    const capitalizedEmail = "ADRIANARVIZU1994@GMAIL.COM";
    const isAuthorized = ADMIN_EMAILS.includes(capitalizedEmail);
    expect(isAuthorized).toBe(false);
  });

  it("should have exactly 2 authorized admins", () => {
    expect(ADMIN_EMAILS.length).toBe(2);
  });

  it("should have valid email format for all admins", () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    ADMIN_EMAILS.forEach((email) => {
      expect(emailRegex.test(email)).toBe(true);
    });
  });

  it("should deny access with whitespace variations", () => {
    const emailWithSpaces = " adrianarvizu1994@gmail.com ";
    const isAuthorized = ADMIN_EMAILS.includes(emailWithSpaces);
    expect(isAuthorized).toBe(false);
  });
});
