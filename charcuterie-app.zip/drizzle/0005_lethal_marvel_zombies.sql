ALTER TABLE `orders` MODIFY COLUMN `userId` int;--> statement-breakpoint
ALTER TABLE `orders` MODIFY COLUMN `status` enum('pending','paid','ready_for_fulfillment','shipped','delivered','cancelled') DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `orders` ADD `email` varchar(320) NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `shippingAddress` json;--> statement-breakpoint
ALTER TABLE `orders` ADD `stripePaymentIntentId` varchar(255);