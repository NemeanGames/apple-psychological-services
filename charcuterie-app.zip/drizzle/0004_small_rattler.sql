CREATE TABLE `accessTokens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tokenHash` varchar(64) NOT NULL,
	`purpose` enum('site_beta','agent_key','invite') NOT NULL DEFAULT 'site_beta',
	`label` varchar(255),
	`maxUses` int DEFAULT 1,
	`usesRemaining` int DEFAULT 1,
	`expiresAt` timestamp,
	`revokedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `accessTokens_id` PRIMARY KEY(`id`),
	CONSTRAINT `accessTokens_tokenHash_unique` UNIQUE(`tokenHash`)
);
