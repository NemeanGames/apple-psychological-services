CREATE TABLE `buckets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`isPublished` int DEFAULT 0,
	`displayOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `buckets_id` PRIMARY KEY(`id`),
	CONSTRAINT `buckets_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `videoAnalytics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`bucketId` int,
	`date` varchar(10) NOT NULL,
	`impressions` int DEFAULT 0,
	`clicks` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoAnalytics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `videoBuckets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`bucketId` int NOT NULL,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoBuckets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `videos` MODIFY COLUMN `platform` enum('instagram','tiktok','youtube','uploaded') NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `status` enum('draft','review','scheduled','published','archived') DEFAULT 'draft' NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `contentType` enum('bts','product','testimonial','event','other') DEFAULT 'other' NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `campaign` varchar(255);--> statement-breakpoint
ALTER TABLE `videos` ADD `goLiveAt` timestamp;--> statement-breakpoint
ALTER TABLE `videos` ADD `expiresAt` timestamp;