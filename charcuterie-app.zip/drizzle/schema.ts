import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  googleSub: varchar("googleSub", { length: 255 }).unique(),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export interface GoogleOAuthUser {
  googleSub: string;
  email?: string;
  name?: string;
}

/**
 * Charcuterie boards/products table
 */
export const boards = mysqlTable("boards", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  imageUrl: varchar("imageUrl", { length: 500 }),
  tags: json("tags").$type<string[]>(),
  size: varchar("size", { length: 50 }), // Small, Medium, Large
  contents: json("contents").$type<Record<string, string[]>>(), // { cheeses: [...], meats: [...], etc }
  isActive: int("isActive").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Board = typeof boards.$inferSelect;
export type InsertBoard = typeof boards.$inferInsert;

/**
 * Orders table
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // NULL for guest checkout
  email: varchar("email", { length: 320 }).notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "paid", "ready_for_fulfillment", "shipped", "delivered", "cancelled"]).default("pending"),
  items: json("items").$type<Record<string, any>[]>(),
  shippingAddress: json("shippingAddress").$type<Record<string, string>>(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

export type ShippingAddress = {
  fullName: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
};

export type OrderItem = {
  boardId: number;
  name: string;
  price: string;
  quantity: number;
};

/**
 * Community posts table
 */
export const communityPosts = mysqlTable("communityPosts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 255 }),
  content: text("content").notNull(),
  imageUrl: varchar("imageUrl", { length: 500 }),
  likes: int("likes").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityPost = typeof communityPosts.$inferSelect;
export type InsertCommunityPost = typeof communityPosts.$inferInsert;

/**
 * Community comments table
 */
export const communityComments = mysqlTable("communityComments", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 255 }),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityComment = typeof communityComments.$inferSelect;
export type InsertCommunityComment = typeof communityComments.$inferInsert;

/**
 * Resources table (PDFs, guides, etc)
 */
export const resources = mysqlTable("resources", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  fileUrl: varchar("fileUrl", { length: 500 }).notNull(),
  fileType: varchar("fileType", { length: 50 }), // pdf, guide, etc
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Resource = typeof resources.$inferSelect;
export type InsertResource = typeof resources.$inferInsert;

/**
 * Videos table for storing social media video metadata (Instagram, TikTok, YouTube)
 * Actual video files are hosted on their respective platforms, not on our S3
 * Extended with CMS workflow states, scheduling, and facets
 */
export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  platform: mysqlEnum("platform", ["instagram", "tiktok", "youtube", "uploaded"]).notNull(),
  platformUrl: varchar("platformUrl", { length: 500 }).notNull(),
  thumbnailUrl: varchar("thumbnailUrl", { length: 500 }),
  creator: varchar("creator", { length: 255 }),
  creatorHandle: varchar("creatorHandle", { length: 255 }),
  isOfficial: int("isOfficial").default(0),
  likes: int("likes").default(0),
  views: int("views").default(0),
  tags: json("tags").$type<string[]>(),
  // CMS workflow fields
  status: mysqlEnum("status", ["draft", "review", "scheduled", "published", "archived"]).default("draft").notNull(),
  contentType: mysqlEnum("contentType", ["bts", "product", "testimonial", "event", "other"]).default("other").notNull(),
  campaign: varchar("campaign", { length: 255 }), // e.g., "Holiday 2025"
  goLiveAt: timestamp("goLiveAt"), // When to publish if scheduled
  expiresAt: timestamp("expiresAt"), // When to archive
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

/**
 * Buckets table for curated video collections
 * Examples: "Homepage Hero", "Holiday 2025", "Testimonials", "Behind the Boards", "Events"
 */
export const buckets = mysqlTable("buckets", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  description: text("description"),
  isPublished: int("isPublished").default(0), // Only published buckets appear on public pages
  displayOrder: int("displayOrder").default(0), // For ordering buckets on homepage
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Bucket = typeof buckets.$inferSelect;
export type InsertBucket = typeof buckets.$inferInsert;

/**
 * Many-to-many relationship between videos and buckets
 * Allows videos to belong to multiple buckets with manual sort order
 */
export const videoBuckets = mysqlTable("videoBuckets", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  bucketId: int("bucketId").notNull(),
  sortOrder: int("sortOrder").default(0), // Manual sort order within bucket
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VideoBucket = typeof videoBuckets.$inferSelect;
export type InsertVideoBucket = typeof videoBuckets.$inferInsert;

/**
 * Analytics table for tracking video impressions and clicks
 * Stores daily snapshots of engagement metrics
 */
export const videoAnalytics = mysqlTable("videoAnalytics", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull(),
  bucketId: int("bucketId"), // NULL if not in a bucket
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD format
  impressions: int("impressions").default(0), // Times video was displayed
  clicks: int("clicks").default(0), // Times video was clicked/played
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VideoAnalytics = typeof videoAnalytics.$inferSelect;
export type InsertVideoAnalytics = typeof videoAnalytics.$inferInsert;

/**
 * Access tokens table for whitelist gate (private mode)
 * Stores hashed tokens for site beta access
 * Tokens are single-use or limited-use, with optional expiry
 */
export const accessTokens = mysqlTable("accessTokens", {
  id: int("id").autoincrement().primaryKey(),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(), // SHA-256 hash
  purpose: mysqlEnum("purpose", ["site_beta", "agent_key", "invite"]).default("site_beta").notNull(),
  label: varchar("label", { length: 255 }), // Human-readable label (e.g., "ChatGPT Agent Test")
  maxUses: int("maxUses").default(1), // -1 for unlimited
  usesRemaining: int("usesRemaining").default(1),
  expiresAt: timestamp("expiresAt"), // NULL for no expiry
  revokedAt: timestamp("revokedAt"), // NULL if active
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AccessToken = typeof accessTokens.$inferSelect;
export type InsertAccessToken = typeof accessTokens.$inferInsert;
