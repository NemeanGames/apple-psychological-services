CREATE TABLE `videos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`platform` enum('instagram','tiktok','youtube') NOT NULL,
	`platformUrl` varchar(500) NOT NULL,
	`thumbnailUrl` varchar(500),
	`creator` varchar(255),
	`creatorHandle` varchar(255),
	`isOfficial` int DEFAULT 0,
	`likes` int DEFAULT 0,
	`views` int DEFAULT 0,
	`tags` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `videos_id` PRIMARY KEY(`id`)
);
