import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

interface CartItem {
  boardId: number;
  name: string;
  price: string;
  quantity: number;
}

interface ShippingData {
  fullName: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  email: string;
}

export default function Checkout() {
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  const [toastMessage, setToastMessage] = useState<{title: string; description: string} | null>(null);

  const toast = (config: any) => {
    setToastMessage(config);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Get cart from localStorage
  const cartItems: CartItem[] = JSON.parse(localStorage.getItem("cart") || "[]");
  const totalPrice = cartItems.reduce((sum, item) => sum + parseFloat(item.price) * item.quantity, 0);

  // Form state
  const [shipping, setShipping] = useState<ShippingData>({
    fullName: "",
    street: "",
    city: "",
    state: "",
    zipCode: "",
    country: "US",
    email: "",
  });

  const handleShippingChange = (field: keyof ShippingData, value: string) => {
    setShipping((prev) => ({ ...prev, [field]: value }));
  };

  const handleCheckout = async () => {
    // Validate form
    if (!shipping.fullName || !shipping.street || !shipping.city || !shipping.state || !shipping.zipCode || !shipping.email) {
      toast({
        title: "Missing Information",
        description: "Please fill in all shipping fields.",
        variant: "destructive",
      });
      return;
    }

    if (cartItems.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Please add items to your cart before checkout.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Create PaymentIntent on server
      const response = await fetch("/api/checkout/create-payment-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cartItems,
          totalPrice: (totalPrice * 100).toFixed(0), // Convert to cents
          shippingAddress: shipping,
          email: shipping.email,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to create payment intent");
      }

      const { clientSecret } = await response.json();

      // Redirect to Stripe payment form (using Stripe.js)
      // For now, show a placeholder message
      toast({
        title: "Payment Intent Created",
        description: "Redirecting to payment...",
      });

      // In a real implementation, you would use Stripe.js to confirm the payment
      // For MVP, we'll redirect to a payment confirmation page
      localStorage.setItem("currentOrder", JSON.stringify({
        items: cartItems,
        totalPrice,
        shippingAddress: shipping,
        clientSecret,
      }));

      setLocation("/payment-confirmation");
    } catch (error) {
      toast({
        title: "Checkout Error",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Your Cart is Empty</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Add items to your cart before proceeding to checkout.</p>
            <Button onClick={() => setLocation("/")}>Continue Shopping</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>

      <div className="grid gap-8">
        {/* Order Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.boardId} className="flex justify-between items-center pb-4 border-b">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-semibold">${(parseFloat(item.price) * item.quantity).toFixed(2)}</p>
                </div>
              ))}
              <div className="flex justify-between items-center pt-4 border-t-2">
                <p className="text-lg font-bold">Total</p>
                <p className="text-lg font-bold">${totalPrice.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Shipping Address */}
        <Card>
          <CardHeader>
            <CardTitle>Shipping Address</CardTitle>
            <CardDescription>Where should we send your order?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={shipping.fullName}
                  onChange={(e) => handleShippingChange("fullName", e.target.value)}
                  placeholder="John Doe"
                />
              </div>
              <div className="col-span-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={shipping.email}
                  onChange={(e) => handleShippingChange("email", e.target.value)}
                  placeholder="john@example.com"
                />
              </div>
              <div className="col-span-2">
                <Label htmlFor="street">Street Address</Label>
                <Input
                  id="street"
                  value={shipping.street}
                  onChange={(e) => handleShippingChange("street", e.target.value)}
                  placeholder="123 Main St"
                />
              </div>
              <div>
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={shipping.city}
                  onChange={(e) => handleShippingChange("city", e.target.value)}
                  placeholder="San Francisco"
                />
              </div>
              <div>
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={shipping.state}
                  onChange={(e) => handleShippingChange("state", e.target.value)}
                  placeholder="CA"
                  maxLength={2}
                />
              </div>
              <div>
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input
                  id="zipCode"
                  value={shipping.zipCode}
                  onChange={(e) => handleShippingChange("zipCode", e.target.value)}
                  placeholder="94102"
                />
              </div>
              <div>
                <Label htmlFor="country">Country</Label>
                <Input
                  id="country"
                  value={shipping.country}
                  onChange={(e) => handleShippingChange("country", e.target.value)}
                  placeholder="US"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Billing & Payment */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Method</CardTitle>
            <CardDescription>Secure payment powered by Stripe</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Click "Complete Purchase" to proceed to secure payment. Your card information will be processed securely by Stripe.
            </p>
            <Button
              onClick={handleCheckout}
              disabled={isProcessing}
              size="lg"
              className="w-full"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                `Complete Purchase - $${totalPrice.toFixed(2)}`
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
