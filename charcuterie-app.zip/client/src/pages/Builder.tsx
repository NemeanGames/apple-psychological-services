import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, ChevronRight } from "lucide-react";

export default function Builder() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);

  const [selections, setSelections] = useState({
    size: null as string | null,
    cheeses: [] as string[],
    meats: [] as string[],
    extras: [] as string[],
  });

  const steps = [
    {
      title: "Select Board Size",
      subtitle: "Choose the perfect size for your gathering",
      options: ["Small (4-6 servings)", "Medium (8-10 servings)", "Large (12-16 servings)"],
      key: "size",
    },
    {
      title: "Curate Your Cheeses",
      subtitle: "Select from our premium cheese collection",
      options: ["Aged Cheddar", "Creamy Brie", "Goat Cheese", "Manchego", "Gruyère", "None"],
      key: "cheeses",
      multi: true,
    },
    {
      title: "Choose Your Meats",
      subtitle: "Select premium cured selections",
      options: ["Prosciutto di Parma", "Salami", "Turkey Breast", "Coppa", "Pancetta", "None"],
      key: "meats",
      multi: true,
    },
    {
      title: "Add Accompaniments",
      subtitle: "Complete your board with artisan selections",
      options: ["Fresh Fruits", "Roasted Nuts", "Artisan Crackers", "Olives", "Honey", "Pickles"],
      key: "extras",
      multi: true,
    },
    {
      title: "Review Your Creation",
      subtitle: "Confirm your bespoke board",
      options: [],
      key: "review",
    },
  ];

  const step = steps[currentStep];

  const handleSelect = (option: string) => {
    if ((step as any).multi) {
      setSelections((prev) => {
        const key = step.key as keyof typeof selections;
        const current = prev[key] as string[];
        return {
          ...prev,
          [key]: current.includes(option)
            ? current.filter((o) => o !== option)
            : [...current, option],
        };
      });
    } else {
      setSelections((prev) => ({
        ...prev,
        [step.key]: option,
      }));
      if (currentStep < steps.length - 1) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handlePlaceOrder = () => {
    setLocation("/cart");
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded transition"
          >
            <ArrowLeft size={20} className="text-slate-900" />
          </button>
          <h1 className="text-2xl font-light tracking-wide text-slate-900">Bespoke Studio</h1>
        </div>
      </nav>

      {/* Progress Bar */}
      <div className="px-6 py-8 bg-slate-50 border-b border-slate-200">
        <div className="container mx-auto max-w-2xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium text-slate-900">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-slate-600">{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-1 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-slate-900 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <section className="py-16">
        <div className="container mx-auto px-6 max-w-2xl">
          <div className="mb-12">
            <p className="text-xs font-semibold tracking-widest text-slate-500 uppercase mb-2">
              Step {currentStep + 1}
            </p>
            <h2 className="text-4xl font-light text-slate-900 mb-3">{step.title}</h2>
            <p className="text-slate-600">{step.subtitle}</p>
          </div>

          {currentStep === steps.length - 1 ? (
            // Review Step
            <div className="bg-slate-50 border border-slate-200 p-8 mb-12">
              <h3 className="text-lg font-light text-slate-900 mb-8 tracking-wide">Your Selection</h3>
              <div className="space-y-6">
                <div className="flex justify-between items-start pb-6 border-b border-slate-200">
                  <span className="font-medium text-slate-900">Board Size</span>
                  <span className="text-slate-600 text-right">{selections.size || "Not selected"}</span>
                </div>
                <div className="flex justify-between items-start pb-6 border-b border-slate-200">
                  <span className="font-medium text-slate-900">Cheeses</span>
                  <span className="text-slate-600 text-right">
                    {selections.cheeses.length > 0 ? selections.cheeses.join(", ") : "None"}
                  </span>
                </div>
                <div className="flex justify-between items-start pb-6 border-b border-slate-200">
                  <span className="font-medium text-slate-900">Meats</span>
                  <span className="text-slate-600 text-right">
                    {selections.meats.length > 0 ? selections.meats.join(", ") : "None"}
                  </span>
                </div>
                <div className="flex justify-between items-start">
                  <span className="font-medium text-slate-900">Accompaniments</span>
                  <span className="text-slate-600 text-right">
                    {selections.extras.length > 0 ? selections.extras.join(", ") : "None"}
                  </span>
                </div>
              </div>

              <div className="mt-8 p-6 bg-white border border-slate-200">
                <p className="text-sm text-slate-600 mb-2">Estimated Price</p>
                <p className="text-3xl font-light text-slate-900">$95 - $125</p>
              </div>
            </div>
          ) : (
            // Options Grid
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-12">
              {step.options.map((option) => {
                const isSelected = (step as any).multi
                  ? (selections[step.key as keyof typeof selections] as string[]).includes(option)
                  : selections[step.key as keyof typeof selections] === option;

                return (
                  <button
                    key={option}
                    onClick={() => handleSelect(option)}
                    className={`p-6 border-2 transition text-left ${
                      isSelected
                        ? "border-slate-900 bg-slate-50"
                        : "border-slate-200 bg-white hover:border-slate-400"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-900">{option}</span>
                      {isSelected && <ChevronRight size={20} className="text-slate-900" />}
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex gap-4 justify-between">
            <Button
              onClick={handleBack}
              disabled={currentStep === 0}
              variant="outline"
              className="border-2 border-slate-900 text-slate-900 hover:bg-slate-50 px-8 py-3 rounded-none font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Back
            </Button>

            {currentStep === steps.length - 1 ? (
              <Button
                onClick={handlePlaceOrder}
                className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-none font-medium tracking-wide"
              >
                Add to Cart
              </Button>
            ) : (
              <Button
                onClick={handleNext}
                className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-none font-medium tracking-wide"
              >
                Continue
              </Button>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
