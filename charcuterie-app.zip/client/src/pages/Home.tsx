import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import Navigation from "@/components/Navigation";
import { useBrand } from "@/contexts/BrandContext";
import { ArrowRight } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const { currentTheme, brandName } = useBrand();

  const featuredBoards = [
    {
      id: 1,
      name: "Velvet & Vine",
      description: "A sophisticated selection of aged cheddar, creamy brie, and prosciutto di Parma.",
      price: "$85",
      image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663240826589/doVUfXgCPbHInBjh.png",
    },
    {
      id: 2,
      name: "Goldleaf Grazing",
      description: "Premium artisan cheeses paired with house-cured meats and seasonal accompaniments.",
      price: "$95",
      image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663240826589/FTlQtwmMuGaFeBDi.png",
    },
    {
      id: 3,
      name: "The Opulent Board",
      description: "Our signature collection featuring rare imports, aged selections, and curated delicacies.",
      price: "$125",
      image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663240826589/jNaFvHVzmZnclPKn.png",
    },
  ];

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Full-Screen Hero Section with Background Image */}
      <section className="relative min-h-screen md:ml-64">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: "url('/hero-grazing-table.png')",
          }}
        >
          {/* Dark Overlay */}
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 flex items-center justify-center min-h-screen px-6 py-32">
          <div className="text-center max-w-4xl">
            <h1
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light leading-tight mb-6 text-white"
              style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
            >
              Boardella
              <br />
              <span className="italic">Gourmet Charcuterie Boards</span>
              <br />
              & Event Grazing Tables
            </h1>

            <p className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl mx-auto leading-relaxed">
              Curated artisan boards delivered fresh to your door. Premium imported meats, aged cheeses, and handcrafted accompaniments for every occasion.
            </p>

            <Button
              onClick={() => setLocation("/menu")}
              className="px-10 py-4 text-lg font-medium rounded-full transition-all hover:scale-105"
              style={{
                backgroundColor: currentTheme.accent,
                color: "white",
              }}
            >
              Shop Now
            </Button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-bounce"></div>
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section
        className="py-24 md:ml-64"
        style={{ backgroundColor: currentTheme.background }}
      >
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <p
              className="text-xs font-semibold tracking-widest uppercase mb-4"
              style={{ color: currentTheme.accent }}
            >
              Featured
            </p>
            <h3
              className="text-4xl font-light"
              style={{ color: currentTheme.primary }}
            >
              Signature Collections
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {featuredBoards.map((board) => (
              <div
                key={board.id}
                className="group overflow-hidden rounded-lg hover:shadow-xl transition-all duration-300"
                style={{
                  backgroundColor: currentTheme.background,
                  border: `1px solid ${currentTheme.border}`,
                }}
              >
                <div className="h-56 overflow-hidden">
                  <img
                    src={board.image}
                    alt={board.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <h4
                    className="text-xl font-medium mb-3 tracking-wide"
                    style={{ color: currentTheme.primary }}
                  >
                    {board.name}
                  </h4>
                  <p
                    className="text-sm mb-6 leading-relaxed"
                    style={{ color: currentTheme.text }}
                  >
                    {board.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span
                      className="text-2xl font-light"
                      style={{ color: currentTheme.primary }}
                    >
                      {board.price}
                    </span>
                    <button
                      onClick={() => setLocation("/menu")}
                      className="flex items-center gap-2 text-sm font-medium transition hover:gap-3"
                      style={{ color: currentTheme.accent }}
                    >
                      View <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section
        className="py-24 md:ml-64"
        style={{
          backgroundColor: currentTheme.primary,
        }}
      >
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
            <div className="text-center">
              <div
                className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${currentTheme.background}20` }}
              >
                <span className="text-2xl">🌍</span>
              </div>
              <h4
                className="text-sm font-semibold tracking-widest uppercase mb-4"
                style={{ color: currentTheme.background }}
              >
                Sourced Globally
              </h4>
              <p style={{ color: `${currentTheme.background}cc` }} className="leading-relaxed">
                We partner with renowned producers across Europe and beyond to bring you the finest selections.
              </p>
            </div>
            <div className="text-center">
              <div
                className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${currentTheme.background}20` }}
              >
                <span className="text-2xl">✨</span>
              </div>
              <h4
                className="text-sm font-semibold tracking-widest uppercase mb-4"
                style={{ color: currentTheme.background }}
              >
                Expertly Curated
              </h4>
              <p style={{ color: `${currentTheme.background}cc` }} className="leading-relaxed">
                Each board is thoughtfully composed by our team of culinary specialists and sommeliers.
              </p>
            </div>
            <div className="text-center">
              <div
                className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${currentTheme.background}20` }}
              >
                <span className="text-2xl">🎨</span>
              </div>
              <h4
                className="text-sm font-semibold tracking-widest uppercase mb-4"
                style={{ color: currentTheme.background }}
              >
                Bespoke Service
              </h4>
              <p style={{ color: `${currentTheme.background}cc` }} className="leading-relaxed">
                Customize your board to your exact preferences with our interactive design studio.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section
        className="py-24 md:ml-64"
        style={{
          backgroundColor: currentTheme.background,
        }}
      >
        <div className="container mx-auto px-6 max-w-2xl text-center">
          <p
            className="text-xs font-semibold tracking-widest uppercase mb-4"
            style={{ color: currentTheme.accent }}
          >
            Community
          </p>
          <h3
            className="text-4xl font-light mb-6"
            style={{ color: currentTheme.primary }}
          >
            Join Our Circle
          </h3>
          <p
            className="mb-8 leading-relaxed"
            style={{ color: currentTheme.text }}
          >
            Connect with fellow connoisseurs, share your curated moments, and discover inspiration from our community of discerning collectors.
          </p>
          <Button
            onClick={() => setLocation("/community")}
            className="text-white px-8 py-3 rounded-full font-medium tracking-wide"
            style={{ backgroundColor: currentTheme.accent }}
          >
            Explore Community
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer
        className="py-16 md:ml-64"
        style={{ backgroundColor: currentTheme.primary }}
      >
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div>
              <h5
                className="font-medium text-sm mb-4 tracking-wide"
                style={{ color: currentTheme.background }}
              >
                Shop
              </h5>
              <ul className="space-y-3 text-sm">
                <li>
                  <button
                    onClick={() => setLocation("/menu")}
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Collections
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setLocation("/builder")}
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Bespoke
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h5
                className="font-medium text-sm mb-4 tracking-wide"
                style={{ color: currentTheme.background }}
              >
                Account
              </h5>
              <ul className="space-y-3 text-sm">
                <li>
                  <button
                    onClick={() => setLocation("/orders")}
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Orders
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setLocation("/community")}
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Community
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h5
                className="font-medium text-sm mb-4 tracking-wide"
                style={{ color: currentTheme.background }}
              >
                Resources
              </h5>
              <ul className="space-y-3 text-sm">
                <li>
                  <button
                    onClick={() => setLocation("/discover")}
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Discover
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setLocation("/gallery")}
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Gallery
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h5
                className="font-medium text-sm mb-4 tracking-wide"
                style={{ color: currentTheme.background }}
              >
                Connect
              </h5>
              <ul className="space-y-3 text-sm">
                <li>
                  <a
                    href="#"
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    Instagram
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    style={{ color: currentTheme.background }}
                    className="hover:opacity-70 transition"
                  >
                    TikTok
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div
            className="border-t pt-8 text-center text-sm"
            style={{
              borderColor: `${currentTheme.background}40`,
              color: currentTheme.background,
            }}
          >
            <p>&copy; 2025 {brandName}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
