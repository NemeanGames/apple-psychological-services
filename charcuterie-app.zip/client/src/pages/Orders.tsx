import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, CheckCircle, Truck, Clock } from "lucide-react";

export default function Orders() {
  const [, setLocation] = useLocation();

  const orders = [
    {
      id: "ORD-2025-001",
      date: "December 8, 2025",
      status: "delivered",
      total: "$125.00",
      items: ["The Opulent Board", "Seasonal Selection"],
      estimatedDelivery: "Delivered December 10",
    },
    {
      id: "ORD-2025-002",
      date: "December 5, 2025",
      status: "shipped",
      total: "$85.00",
      items: ["Velvet & Vine"],
      estimatedDelivery: "Arriving December 12",
    },
    {
      id: "ORD-2025-003",
      date: "December 1, 2025",
      status: "delivered",
      total: "$250.00",
      items: ["Goldleaf Grazing", "Artisan Vegan", "Seasonal Selection"],
      estimatedDelivery: "Delivered December 5",
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle className="text-green-600" size={20} />;
      case "shipped":
        return <Truck className="text-blue-600" size={20} />;
      case "pending":
        return <Clock className="text-slate-600" size={20} />;
      default:
        return <Clock size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-50 text-green-700 border-green-200";
      case "shipped":
        return "bg-blue-50 text-blue-700 border-blue-200";
      case "pending":
        return "bg-slate-50 text-slate-700 border-slate-200";
      default:
        return "bg-slate-50 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded transition"
          >
            <ArrowLeft size={20} className="text-slate-900" />
          </button>
          <h1 className="text-2xl font-light tracking-wide text-slate-900">Order History</h1>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b border-slate-200">
        <div className="container mx-auto px-6 py-12 max-w-3xl">
          <p className="text-xs font-semibold tracking-widest text-slate-500 uppercase mb-4">
            Account
          </p>
          <h2 className="text-4xl font-light text-slate-900">
            Your Orders
          </h2>
        </div>
      </section>

      {/* Orders List */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-3xl">
          {orders.length > 0 ? (
            <div className="space-y-8">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="border border-slate-200 p-8 hover:shadow-lg transition-shadow"
                >
                  {/* Order Header */}
                  <div className="flex items-start justify-between mb-8 pb-8 border-b border-slate-200">
                    <div>
                      <h3 className="text-lg font-light text-slate-900 tracking-wide">{order.id}</h3>
                      <p className="text-sm text-slate-600 mt-1">{order.date}</p>
                    </div>
                    <div className={`flex items-center gap-2 px-4 py-2 border ${getStatusColor(order.status)}`}>
                      {getStatusIcon(order.status)}
                      <span className="font-medium text-sm capitalize">{order.status}</span>
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="mb-8 pb-8 border-b border-slate-200">
                    <h4 className="font-medium text-slate-900 mb-4 text-sm tracking-wide">ITEMS</h4>
                    <ul className="space-y-2">
                      {order.items.map((item, idx) => (
                        <li key={idx} className="flex items-center gap-3 text-slate-700">
                          <span className="text-slate-400">•</span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Order Footer */}
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-slate-600 mb-2 font-medium">TOTAL</p>
                      <p className="text-2xl font-light text-slate-900">{order.total}</p>
                      <p className="text-xs text-slate-600 mt-2">{order.estimatedDelivery}</p>
                    </div>
                    <Button
                      onClick={() => setLocation("/menu")}
                      className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-2 rounded-none font-medium"
                    >
                      Order Again
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <h3 className="text-2xl font-light text-slate-900 mb-4">No Orders Yet</h3>
              <p className="text-slate-600 mb-8">Begin your collection with our curated selections.</p>
              <Button
                onClick={() => setLocation("/menu")}
                className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-none font-medium"
              >
                Explore Collections
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
