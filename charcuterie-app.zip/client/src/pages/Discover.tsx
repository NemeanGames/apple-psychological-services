import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import Navigation from "@/components/Navigation";
import SocialVideoPlayer from "@/components/SocialVideoPlayer";
import { useBrand } from "@/contexts/BrandContext";
import { trpc } from "@/lib/trpc";
import { Play, Image as ImageIcon, X, Loader2 } from "lucide-react";

interface DiscoverItem {
  id: number;
  type: "video" | "image";
  platform?: "instagram" | "tiktok" | "youtube";
  url: string;
  title: string;
  description: string;
  creator: string;
  creatorHandle?: string;
  likes: number;
  comments: number;
  thumbnail?: string;
}

export default function Discover() {
  const [, setLocation] = useLocation();
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const { currentTheme } = useBrand();

  // Fetch published videos from backend
  const { data: publishedVideos = [], isLoading } = trpc.videos.listPublished.useQuery({});

  // Transform videos to DiscoverItem format
  const transformedVideos = useMemo(() => {
    return publishedVideos.map((video: any) => ({
      id: video.id,
      type: "video" as const,
      platform: video.platform,
      url: video.platformUrl,
      title: video.title,
      description: video.description || "Curated Boardella content",
      creator: video.creator || "Boardella Official",
      creatorHandle: video.creatorHandle || "@BoardellaOfficial",
      likes: 0,
      comments: 0,
      thumbnail: video.thumbnailUrl,
    }));
  }, [publishedVideos]);

  // Use only transformed videos (no fallback sample data)
  const discoverItems = transformedVideos;
  const selectedItem = selectedIndex !== null ? discoverItems[selectedIndex] : null;

  return (
    <div className="min-h-screen" style={{ backgroundColor: currentTheme.background }}>
      <Navigation />

      {/* Modal for selected video/image */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">{selectedItem.title}</h2>
              <button
                onClick={() => setSelectedIndex(null)}
                className="p-2 hover:bg-gray-100 rounded transition"
              >
                <X size={24} />
              </button>
            </div>

            <div className="p-6">
              {selectedItem.type === "video" && selectedItem.platform ? (
                <SocialVideoPlayer
                  platform={selectedItem.platform}
                  platformUrl={selectedItem.url}
                  title={selectedItem.title}
                  creator={selectedItem.creator}
                  creatorHandle={selectedItem.creatorHandle}
                  className="mb-6"
                />
              ) : (
                <img
                  src={selectedItem.url}
                  alt={selectedItem.title}
                  className="w-full rounded-lg mb-6"
                />
              )}

              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{selectedItem.title}</h3>
                  <p className="text-gray-600 mt-2">{selectedItem.description}</p>
                </div>

                <div className="flex items-center gap-6 text-sm text-gray-600 border-t border-gray-200 pt-4">
                  <span className="font-medium text-gray-900">{selectedItem.creator}</span>
                  {selectedItem.creatorHandle && (
                    <span className="text-gray-500">{selectedItem.creatorHandle}</span>
                  )}
                  <span>❤️ {selectedItem.likes}</span>
                  <span>💬 {selectedItem.comments}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="md:ml-64 pt-8">
        {/* Header */}
        <section className="px-6 mb-12">
          <div className="max-w-4xl mx-auto">
            <p
              className="text-xs font-semibold tracking-widest uppercase mb-4"
              style={{ color: currentTheme.primary }}
            >
              Discover
            </p>
            <h1
              className="text-4xl md:text-5xl font-light mb-6"
              style={{ color: currentTheme.primary }}
            >
              Boardella Moments
            </h1>
            <p
              className="text-lg"
              style={{ color: currentTheme.secondary }}
            >
              Explore curated content from our community and official channels. Follow @BoardellaOfficial on Instagram, TikTok, and YouTube for daily inspiration.
            </p>
          </div>
        </section>

        {/* Grid */}
        <section className="px-6 pb-16">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {isLoading ? (
                <div className="col-span-full flex items-center justify-center py-12">
                  <Loader2 className="animate-spin" size={32} />
                </div>
              ) : null}
              {!isLoading && discoverItems.length === 0 ? (
                <div className="col-span-full text-center py-16">
                  <p className="text-lg" style={{ color: currentTheme.secondary }}>
                    No videos available yet. Check back soon for curated Boardella content!
                  </p>
                </div>
              ) : null}
              {!isLoading &&
                discoverItems.map((item: DiscoverItem, index: number) => (
                  <div
                    key={item.id}
                    onClick={() => setSelectedIndex(index)}
                    className="group cursor-pointer overflow-hidden rounded-lg transition-transform hover:scale-105"
                    style={{ backgroundColor: currentTheme.background }}
                  >
                    <div className="relative overflow-hidden h-64 bg-gray-200">
                      {item.type === "video" ? (
                        <>
                          <img
                            src={
                              item.thumbnail ||
                              "https://via.placeholder.com/400x300?text=Video"
                            }
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition flex items-center justify-center">
                            <Play
                              size={48}
                              className="text-white opacity-80 group-hover:opacity-100 transition"
                              fill="white"
                            />
                          </div>
                        </>
                      ) : (
                        <img
                          src={item.url}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                        />
                      )}
                    </div>

                    <div className="p-4">
                      <h3
                        className="font-semibold text-lg mb-2"
                        style={{ color: currentTheme.primary }}
                      >
                        {item.title}
                      </h3>
                      <p
                        className="text-sm mb-4"
                        style={{ color: currentTheme.secondary }}
                      >
                        {item.description}
                      </p>
                      <div className="flex items-center justify-between text-xs">
                        <span style={{ color: currentTheme.secondary }}>
                          by {item.creator}
                        </span>
                        <div className="flex gap-4">
                          <span style={{ color: currentTheme.secondary }}>
                            ❤️ {item.likes}
                          </span>
                          <span style={{ color: currentTheme.secondary }}>
                            💬 {item.comments}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section
          className="px-6 py-16"
          style={{ backgroundColor: currentTheme.accent }}
        >
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-light text-white mb-4">
              Share Your Boardella Moment
            </h2>
            <p className="text-white/90 mb-6">
              Tag @BoardellaOfficial on Instagram, TikTok, or YouTube for a chance to be featured in our Discover section.
            </p>
            <a
              href="https://instagram.com/BoardellaOfficial"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-3 bg-white text-gray-900 font-medium rounded-lg hover:bg-gray-100 transition"
            >
              Follow @BoardellaOfficial
            </a>
          </div>
        </section>
      </div>
    </div>
  );
}
