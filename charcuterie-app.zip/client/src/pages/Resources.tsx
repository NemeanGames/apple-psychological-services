import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Download, FileText, BookOpen, Instagram, Facebook, Twitter } from "lucide-react";

export default function Resources() {
  const [, setLocation] = useLocation();

  const resources = [
    {
      id: 1,
      title: "The Art of Charcuterie",
      description: "A comprehensive guide to selecting, pairing, and presenting premium charcuterie boards.",
      type: "guide",
      downloadUrl: "#",
    },
    {
      id: 2,
      title: "Pairing Excellence: Meats & Cheeses",
      description: "Expert recommendations for flavor combinations that create harmonious culinary experiences.",
      type: "guide",
      downloadUrl: "#",
    },
    {
      id: 3,
      title: "Seasonal Collections Guide",
      description: "Discover seasonal ingredients and themes for your boards throughout the year.",
      type: "pdf",
      downloadUrl: "#",
    },
    {
      id: 4,
      title: "Photography & Presentation",
      description: "Master the art of capturing and presenting your boards for social sharing.",
      type: "guide",
      downloadUrl: "#",
    },
    {
      id: 5,
      title: "Hosting with Sophistication",
      description: "Complete guide to hosting memorable gatherings centered around curated boards.",
      type: "pdf",
      downloadUrl: "#",
    },
    {
      id: 6,
      title: "Dietary Considerations",
      description: "Create inclusive boards for various dietary preferences and requirements.",
      type: "guide",
      downloadUrl: "#",
    },
  ];

  const getTypeIcon = (type: string) => {
    return type === "pdf" ? <FileText size={20} /> : <BookOpen size={20} />;
  };

  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded transition"
          >
            <ArrowLeft size={20} className="text-slate-900" />
          </button>
          <h1 className="text-2xl font-light tracking-wide text-slate-900">Boardella Resources</h1>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b border-slate-200">
        <div className="container mx-auto px-6 py-16 max-w-3xl">
          <p className="text-xs font-semibold tracking-widest text-slate-500 uppercase mb-4">
            Learning Center
          </p>
          <h2 className="text-4xl font-light text-slate-900 mb-6">
            Curated Knowledge
          </h2>
          <p className="text-slate-600 leading-relaxed">
            Explore our collection of guides and resources to deepen your appreciation for the art of charcuterie with Boardella.
          </p>
        </div>
      </section>

      {/* Resources Grid */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl">
            {resources.map((resource) => (
              <div
                key={resource.id}
                className="border border-slate-200 p-8 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-lg font-light text-slate-900 tracking-wide flex-1">
                    {resource.title}
                  </h3>
                  <div className="text-slate-600 ml-4">{getTypeIcon(resource.type)}</div>
                </div>

                <p className="text-slate-600 text-sm mb-6 leading-relaxed h-12 line-clamp-2">
                  {resource.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="inline-block px-3 py-1 bg-slate-100 text-slate-700 text-xs font-medium tracking-wide">
                    {resource.type === "pdf" ? "PDF" : "Guide"}
                  </div>
                  <Button
                    onClick={() => window.open(resource.downloadUrl, "_blank")}
                    className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-none font-medium flex items-center gap-2"
                  >
                    <Download size={16} />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Media Section */}
      <section className="py-16 bg-slate-50 border-t border-slate-200">
        <div className="container mx-auto px-6 max-w-2xl text-center">
          <p className="text-xs font-semibold tracking-widest text-slate-500 uppercase mb-4">
            Connect With Us
          </p>
          <h3 className="text-3xl font-light text-slate-900 mb-6">
            Follow Boardella
          </h3>
          <p className="text-slate-600 mb-8 leading-relaxed">
            Stay updated with our latest collections, tips, and inspiration by following us on social media.
          </p>
          <div className="flex justify-center gap-6 mb-8">
            <a
              href="https://instagram.com/BoardellaOfficial"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded transition"
            >
              <Instagram size={20} />
              @BoardellaOfficial
            </a>
            <a
              href="https://facebook.com/BoardellaOfficial"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded transition"
            >
              <Facebook size={20} />
              Boardella
            </a>
            <a
              href="https://twitter.com/BoardellaOfficial"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded transition"
            >
              <Twitter size={20} />
              @BoardellaOfficial
            </a>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 border-t border-slate-200">
        <div className="container mx-auto px-6 max-w-2xl text-center">
          <p className="text-xs font-semibold tracking-widest text-slate-500 uppercase mb-4">
            Ready to Create
          </p>
          <h3 className="text-3xl font-light text-slate-900 mb-6">
            Begin Your Boardella Collection
          </h3>
          <p className="text-slate-600 mb-8 leading-relaxed">
            Use these resources to inform your selections and create the perfect board for any occasion.
          </p>
          <Button
            onClick={() => setLocation("/builder")}
            className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-none font-medium tracking-wide"
          >
            Create Bespoke Board
          </Button>
        </div>
      </section>
    </div>
  );
}
