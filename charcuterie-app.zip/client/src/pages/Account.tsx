import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { LogOut, User, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

type GoogleWindow = Window & {
  google?: {
    accounts: {
      id: {
        initialize: (config: any) => void;
        renderButton: (element: HTMLElement, options: any) => void;
        cancel: () => void;
      };
    };
  };
};

export default function Account() {
  const [, setLocation] = useLocation();
  const { user, loading, logout } = useAuth();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [googleReady, setGoogleReady] = useState(false);

  // Handle Google Sign-In response
  const handleGoogleSignIn = useCallback(async (response: any) => {
    try {
      setIsSigningIn(true);
      setError(null);

      const token = response.credential;
      if (!token) {
        throw new Error("No credential received");
      }

      // Send token to backend for validation and session creation
      const res = await fetch("/auth/google/callback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
        credentials: "include", // Include cookies
      });

      // Get response text first to check if it's valid JSON
      const responseText = await res.text();
      
      if (!res.ok) {
        try {
          const data = JSON.parse(responseText);
          throw new Error(data.error || "Authentication failed");
        } catch (parseErr) {
          throw new Error(`Authentication failed: ${res.status} ${res.statusText}`);
        }
      }

      try {
        const result = JSON.parse(responseText);
        // Redirect to home after successful authentication
        if (result.redirectUrl) {
          window.location.href = result.redirectUrl;
        } else {
          window.location.reload();
        }
      } catch (parseErr) {
        throw new Error("Invalid response from server");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Sign-in failed";
      setError(message);
      console.error("Google Sign-In error:", err);
    } finally {
      setIsSigningIn(false);
    }
  }, []);

  // Load Google Sign-In script once
  useEffect(() => {
    // already loaded
    if ((window as GoogleWindow).google?.accounts?.id) {
      setGoogleReady(true);
      return;
    }

    // avoid duplicate script tags
    const existing = document.getElementById("google-gsi-script") as HTMLScriptElement | null;
    if (existing) {
      // if it loads later, the onload handler below may not exist; use a small poll
      const t = window.setInterval(() => {
        if ((window as GoogleWindow).google?.accounts?.id) {
          window.clearInterval(t);
          setGoogleReady(true);
        }
      }, 50);
      return () => window.clearInterval(t);
    }

    const script = document.createElement("script");
    script.id = "google-gsi-script";
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.onload = () => setGoogleReady(true);
    script.onerror = () => setError("Failed to load Google Sign-In. Please refresh the page.");
    document.head.appendChild(script);
  }, []);

  // Initialize and render button when script is ready and auth state changes
  useEffect(() => {
    if (!googleReady) return;

    const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;
    if (!clientId) {
      setError("Google Sign-In is not configured (missing client ID).");
      return;
    }

    try {
      (window as GoogleWindow).google!.accounts.id.initialize({
        client_id: clientId,
        callback: handleGoogleSignIn,
        auto_select: false,
        itp_support: true,
      });

      if (!user && !loading) {
        const el = document.getElementById("google-signin-button");
        if (el) {
          el.innerHTML = "";
          (window as GoogleWindow).google!.accounts.id.renderButton(el, {
            theme: "outline",
            size: "large",
          });
        }
      }
    } catch (e) {
      console.error(e);
      setError("Failed to initialize Google Sign-In");
    }
  }, [googleReady, user, loading, handleGoogleSignIn]);

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="animate-spin h-12 w-12 text-slate-900 mx-auto mb-4" />
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (user) {
    return (
      <div className="min-h-screen bg-white py-12 px-4">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Your Account
              </CardTitle>
              <CardDescription>Manage your Boardella account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-slate-600">Name</p>
                <p className="font-medium">{user.name || "Not provided"}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600">Email</p>
                <p className="font-medium">{user.email || "Not provided"}</p>
              </div>
              <Button
                onClick={() => logout()}
                variant="outline"
                className="w-full"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white py-12 px-4">
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Sign In or Create Account</CardTitle>
            <CardDescription>
              Sign in with your Google account to access your orders and preferences.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
                {error}
              </div>
            )}
            <div
              id="google-signin-button"
              className="flex justify-center"
            />
            <p className="text-xs text-slate-500 text-center">
              We use Google Sign-In to keep your account secure. Your data is never shared with third parties.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
