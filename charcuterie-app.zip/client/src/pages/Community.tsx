import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Heart, MessageCircle, Share2, Instagram } from "lucide-react";

export default function Community() {
  const [, setLocation] = useLocation();
  const [posts, setPosts] = useState([
    {
      id: 1,
      author: "Sarah Mitchell",
      role: "Collector",
      content: "Just received the Opulent Board for our anniversary dinner. The presentation and quality exceeded all expectations.",
      timestamp: "2 hours ago",
      likes: 234,
      comments: 12,
    },
    {
      id: 2,
      author: "James Chen",
      role: "Connoisseur",
      content: "The bespoke studio made it so easy to create exactly what I envisioned. Highly recommend for anyone looking for a personalized experience.",
      timestamp: "4 hours ago",
      likes: 189,
      comments: 8,
    },
    {
      id: 3,
      author: "Emma Rothschild",
      role: "Curator",
      content: "The Velvet & Vine collection is absolutely exceptional. Each element is perfectly balanced. This is the gold standard for charcuterie.",
      timestamp: "6 hours ago",
      likes: 456,
      comments: 34,
    },
    {
      id: 4,
      author: "Boardella Team",
      role: "Official",
      content: "Join our community and share your Boardella moments! Tag @BoardellaOfficial for a chance to be featured on our social media.",
      timestamp: "1 day ago",
      likes: 1203,
      comments: 89,
    },
  ]);

  const [newPost, setNewPost] = useState("");
  const [likedPosts, setLikedPosts] = useState<number[]>([]);

  const handlePostSubmit = () => {
    if (newPost.trim()) {
      const post = {
        id: posts.length + 1,
        author: "You",
        role: "Member",
        content: newPost,
        likes: 0,
        comments: 0,
        timestamp: "just now",
      };
      setPosts([post, ...posts]);
      setNewPost("");
    }
  };

  const toggleLike = (postId: number) => {
    if (likedPosts.includes(postId)) {
      setLikedPosts(likedPosts.filter((id) => id !== postId));
    } else {
      setLikedPosts([...likedPosts, postId]);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded transition"
          >
            <ArrowLeft size={20} className="text-slate-900" />
          </button>
          <h1 className="text-2xl font-light tracking-wide text-slate-900">Boardella Community</h1>
        </div>
      </nav>

      {/* Header */}
      <section className="border-b border-slate-200">
        <div className="container mx-auto px-6 py-16 max-w-3xl">
          <p className="text-xs font-semibold tracking-widest text-slate-500 uppercase mb-4">
            Conversations
          </p>
          <h2 className="text-4xl font-light text-slate-900 mb-6">
            Boardella Community
          </h2>
          <p className="text-slate-600 leading-relaxed">
            Join fellow connoisseurs in sharing experiences, recommendations, and curated moments from your Boardella collection. Follow us @BoardellaOfficial on Instagram for daily inspiration.
          </p>
        </div>
      </section>

      {/* Create Post Section */}
      <section className="border-b border-slate-200">
        <div className="container mx-auto px-6 py-12 max-w-3xl">
          <div className="flex gap-6">
            <div className="flex-1">
              <textarea
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                placeholder="Share your Boardella moments with the community... Tag @BoardellaOfficial!"
                className="w-full p-4 border border-slate-200 focus:border-slate-900 focus:outline-none resize-none text-slate-900 placeholder-slate-400"
                rows={4}
              />
              <div className="flex justify-end gap-3 mt-4">
                <Button
                  onClick={() => setNewPost("")}
                  variant="outline"
                  className="border-2 border-slate-200 text-slate-900 hover:border-slate-900 px-6 py-2 rounded-none"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handlePostSubmit}
                  disabled={!newPost.trim()}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-2 rounded-none disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                >
                  Post
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feed */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-3xl space-y-8">
          {posts.map((post) => (
            <div key={post.id} className="border border-slate-200 p-8">
              {/* Post Header */}
              <div className="mb-6 pb-6 border-b border-slate-200">
                <h3 className="font-medium text-slate-900">{post.author}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <p className="text-xs text-slate-500">{post.role}</p>
                  <span className="text-slate-300">•</span>
                  <p className="text-xs text-slate-500">{post.timestamp}</p>
                </div>
              </div>

              {/* Post Content */}
              <p className="text-slate-700 leading-relaxed mb-6">{post.content}</p>

              {/* Post Stats */}
              <div className="flex gap-6 text-sm text-slate-600 mb-6 pb-6 border-b border-slate-200">
                <span>{post.likes} likes</span>
                <span>{post.comments} comments</span>
              </div>

              {/* Post Actions */}
              <div className="flex gap-6">
                <button
                  onClick={() => toggleLike(post.id)}
                  className={`flex items-center gap-2 text-sm font-medium transition ${
                    likedPosts.includes(post.id)
                      ? "text-red-600"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <Heart
                    size={18}
                    fill={likedPosts.includes(post.id) ? "currentColor" : "none"}
                  />
                  Like
                </button>
                <button className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 transition">
                  <MessageCircle size={18} />
                  Comment
                </button>
                <button className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 transition">
                  <Share2 size={18} />
                  Share
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
