import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import Navigation from "@/components/Navigation";
import { Loader2 } from "lucide-react";

export default function Menu() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <Navigation />

      {/* Collections Page */}
      <section className="py-16">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-light tracking-wide text-slate-900 mb-4">Collections</h1>
            <p className="text-slate-600 text-lg">Explore our curated selection of gourmet charcuterie boards</p>
          </div>

          {/* Empty State */}
          <div className="text-center py-24">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-slate-100 rounded-full mb-6">
              <Loader2 size={32} className="text-slate-400 animate-spin" />
            </div>
            <h2 className="text-2xl font-light text-slate-900 mb-3">Coming Soon</h2>
            <p className="text-slate-600 mb-8 max-w-md mx-auto">
              Our collection of premium charcuterie boards will be available shortly. Check back soon for our latest offerings.
            </p>
            <Button
              onClick={() => setLocation("/")}
              className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-none font-medium"
            >
              Return to Home
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
