import { useBrand } from "@/contexts/BrandContext";
import Navigation from "@/components/Navigation";

export default function UGCGallery() {
  const { currentTheme } = useBrand();

  const ugcContent = [
    {
      id: 1,
      type: "image",
      url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663240826589/uCZodpCprkaJIxFQ.png",
      title: "Luxury Charcuterie Board",
      description: "A stunning arrangement of aged cheeses, cured meats, and fresh fruits.",
      creator: "Sarah M.",
      likes: 5234,
      comments: 342,
    },
    {
      id: 2,
      type: "image",
      url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663240826589/uCZodpCprkaJIxFQ.png",
      title: "Gourmet Selection",
      description: "Premium selection featuring Spanish jamón, French brie, and Italian prosciutto.",
      creator: "Marco D.",
      likes: 4891,
      comments: 267,
    },
    {
      id: 3,
      type: "image",
      url: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663240826589/uCZodpCprkaJIxFQ.png",
      title: "Artisan Cheese Pairing",
      description: "Carefully curated cheeses paired with house-made preserves and honeycomb.",
      creator: "Emma L.",
      likes: 6123,
      comments: 445,
    },
  ];

  return (
    <div
      className="min-h-screen pb-24 md:pb-0 md:ml-64"
      style={{ backgroundColor: currentTheme.background }}
    >
      <Navigation />

      {/* Header */}
      <div
        className="border-b"
        style={{ borderColor: currentTheme.border }}
      >
        <div className="container mx-auto px-6 py-16 max-w-3xl">
          <p
            className="text-xs font-semibold tracking-widest uppercase mb-4"
            style={{ color: currentTheme.accent }}
          >
            User Generated Content
          </p>
          <h2
            className="text-4xl font-light mb-6"
            style={{ color: currentTheme.primary }}
          >
            Moments from Our Community
          </h2>
          <p
            className="text-lg"
            style={{ color: currentTheme.secondary }}
          >
            Discover how our customers create and share their charcuterie experiences.
          </p>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="container mx-auto px-6 py-16 max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ugcContent.map((item) => (
            <div
              key={item.id}
              className="group cursor-pointer overflow-hidden rounded-lg"
              style={{ backgroundColor: currentTheme.background }}
            >
              <div className="relative overflow-hidden h-64">
                <img
                  src={item.url}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3
                  className="text-xl font-semibold mb-2"
                  style={{ color: currentTheme.primary }}
                >
                  {item.title}
                </h3>
                <p
            className="text-sm mb-4"
            style={{ color: currentTheme.secondary }}
                >
                  {item.description}
                </p>
                <div className="flex items-center justify-between text-xs">
                  <span style={{ color: currentTheme.secondary }}>
                    by {item.creator}
                  </span>
                  <div className="flex gap-4">
                    <span style={{ color: currentTheme.secondary }}>
                      ❤️ {item.likes}
                    </span>
                    <span style={{ color: currentTheme.secondary }}>
                      💬 {item.comments}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
