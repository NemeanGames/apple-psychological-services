import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft, Trash2 } from "lucide-react";
import { useState } from "react";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

export default function Cart() {
  const [, setLocation] = useLocation();
  const [cartItems] = useState<CartItem[]>([]);

  // Calculate totals from cart items
  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + tax;

  const handleRemoveItem = (itemId: string) => {
    // TODO: Implement cart removal
    console.log("Remove item:", itemId);
  };

  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded transition"
          >
            <ArrowLeft size={20} className="text-slate-900" />
          </button>
          <h1 className="text-2xl font-light tracking-wide text-slate-900">Shopping Cart</h1>
        </div>
      </nav>

      {/* Cart Content */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-3xl">
          {cartItems.length > 0 ? (
            <>
              {/* Cart Items */}
              <div className="space-y-6 mb-12">
                {cartItems.map((item) => (
                  <div
                    key={item.id}
                    className="border border-slate-200 p-6 flex items-center justify-between"
                  >
                    <div className="flex-1">
                      <h3 className="font-light text-lg text-slate-900 tracking-wide">{item.name}</h3>
                      <p className="text-sm text-slate-600 mt-1">Quantity: {item.quantity}</p>
                    </div>
                    <div className="flex items-center gap-6">
                      <p className="text-xl font-light text-slate-900">${(item.price * item.quantity).toFixed(2)}</p>
                      <button
                        onClick={() => handleRemoveItem(item.id)}
                        className="p-2 hover:bg-red-50 rounded transition text-red-600"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Summary */}
              <div className="border border-slate-200 p-8 mb-12 bg-slate-50">
                <h3 className="font-light text-lg text-slate-900 mb-8 tracking-wide">Order Summary</h3>
                <div className="space-y-4 mb-6 pb-6 border-b border-slate-200">
                  <div className="flex justify-between text-slate-900">
                    <span className="text-sm">Subtotal</span>
                    <span className="font-light">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-900">
                    <span className="text-sm">Tax</span>
                    <span className="font-light">${tax.toFixed(2)}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-light text-slate-900">Total</span>
                  <span className="text-3xl font-light text-slate-900">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-4">
                <Button
                  onClick={() => setLocation("/checkout")}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-none font-medium tracking-wide"
                >
                  Proceed to Checkout
                </Button>
                <Button
                  onClick={() => setLocation("/collections")}
                  variant="outline"
                  className="w-full border-2 border-slate-900 text-slate-900 hover:bg-slate-50 py-3 rounded-none font-medium tracking-wide"
                >
                  Continue Shopping
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <h3 className="text-2xl font-light text-slate-900 mb-4">Your Cart is Empty</h3>
              <p className="text-slate-600 mb-8">Explore our collections to add items to your cart.</p>
              <Button
                onClick={() => setLocation("/collections")}
                className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-3 rounded-none font-medium"
              >
                Explore Collections
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
