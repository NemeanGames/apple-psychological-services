import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { BarChart3, Package, Users, ShoppingBag, Plus, Edit2, Trash2, LogOut, Film } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { AdminVideoList } from "../components/AdminVideoList";
import { AdminBucketManager } from "../components/AdminBucketManager";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const me = trpc.auth.me.useQuery();

  // Check authorization
  const userRole = (me.data as any)?.role;
  const isAuthorized = me.data && (userRole === "admin" || userRole === "staff");

  if (me.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-700 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!me.data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Please sign in to access the admin panel.</p>
          <Button onClick={() => setLocation("/")} className="bg-amber-700 hover:bg-amber-800">
            Go Home
          </Button>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-600 mb-4">Access denied. You do not have permission to access the admin panel.</p>
          <Button onClick={() => setLocation("/")} className="bg-amber-700 hover:bg-amber-800">
            Go Home
          </Button>
        </div>
      </div>
    );
  }

  // Mock data
  const stats = [
    { label: "Total Orders", value: "248", icon: ShoppingBag, color: "bg-blue-100 text-blue-700" },
    { label: "Active Boards", value: "24", icon: Package, color: "bg-green-100 text-green-700" },
    { label: "Community Posts", value: "1,203", icon: "📸", color: "bg-purple-100 text-purple-700" },
    { label: "Total Users", value: "892", icon: Users, color: "bg-orange-100 text-orange-700" },
  ];

  const recentOrders = [
    { id: "ORD-001", customer: "Sarah M.", total: "$85.00", status: "delivered", date: "Dec 10" },
    { id: "ORD-002", customer: "James K.", total: "$65.00", status: "shipped", date: "Dec 9" },
    { id: "ORD-003", customer: "Emma L.", total: "$150.00", status: "pending", date: "Dec 8" },
  ];

  const boards = [
    { id: 1, name: "Velvet & Vine", price: "$65", active: true },
    { id: 2, name: "Goldleaf Grazing", price: "$75", active: true },
    { id: 3, name: "The Opulent Board", price: "$85", active: true },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-50 text-green-700 border-green-200";
      case "shipped":
        return "bg-blue-50 text-blue-700 border-blue-200";
      case "pending":
        return "bg-amber-50 text-amber-700 border-amber-200";
      default:
        return "bg-gray-50 text-gray-700 border-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-2xl font-bold text-amber-900">🧀</div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Boardella Admin</h1>
                <p className="text-sm text-gray-600">Management Dashboard</p>
              </div>
            </div>
            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg font-medium transition"
            >
              <LogOut size={18} />
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8 overflow-x-auto">
            {["overview", "boards", "orders", "users", "community", "cms"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-4 font-medium border-b-2 transition capitalize ${
                  activeTab === tab
                    ? "border-amber-700 text-amber-700"
                    : "border-transparent text-gray-600 hover:text-gray-900"
                }`}
              >
                {tab === "cms" ? (
                  <span className="flex items-center gap-2">
                    <Film size={18} />
                    CMS
                  </span>
                ) : (
                  tab
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, idx) => (
                <div key={idx} className="bg-white rounded-lg border border-gray-200 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-600 text-sm font-medium">{stat.label}</p>
                      <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                    </div>
                    <div className={`p-3 rounded-lg ${stat.color}`}>
                      {typeof stat.icon === "string" ? (
                        <span className="text-2xl">{stat.icon}</span>
                      ) : (
                        <stat.icon size={24} />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-lg border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-bold text-gray-900">Recent Orders</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Order ID</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Customer</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Total</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order) => (
                      <tr key={order.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-medium text-gray-900">{order.id}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{order.customer}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{order.total}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(order.status)}`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">{order.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Boards Tab */}
        {activeTab === "boards" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Manage Boards</h2>
              <Button className="bg-amber-700 hover:bg-amber-800 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <Plus size={18} />
                Add Board
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {boards.map((board) => (
                <div key={board.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                  <div className="h-32 bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center text-4xl">
                    🧀
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-gray-900 mb-2">{board.name}</h3>
                    <p className="text-2xl font-bold text-amber-700 mb-4">{board.price}</p>
                    <div className="flex gap-2">
                      <Button className="flex-1 bg-blue-50 text-blue-700 hover:bg-blue-100 px-3 py-2 rounded-lg flex items-center justify-center gap-2">
                        <Edit2 size={16} />
                        Edit
                      </Button>
                      <Button className="flex-1 bg-red-50 text-red-700 hover:bg-red-100 px-3 py-2 rounded-lg flex items-center justify-center gap-2">
                        <Trash2 size={16} />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">All Orders</h2>
            <div className="bg-white rounded-lg border border-gray-200 overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Order ID</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Customer</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Total</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {recentOrders.map((order) => (
                    <tr key={order.id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{order.id}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{order.customer}</td>
                      <td className="px-6 py-4 text-sm font-semibold text-gray-900">{order.total}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(order.status)}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <button className="text-blue-600 hover:text-blue-800 font-medium">View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">User Management</h2>
            <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
              <Users size={48} className="mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600">User management interface coming soon</p>
            </div>
          </div>
        )}

        {/* Community Tab */}
        {activeTab === "community" && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Community Moderation</h2>
            <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
              <span className="text-4xl mb-4 block">📸</span>
              <p className="text-gray-600">Community moderation tools coming soon</p>
            </div>
          </div>
        )}

        {/* CMS Tab */}
        {activeTab === "cms" && (
          <div>
            <div className="flex items-center gap-3 mb-6">
              <Film size={28} className="text-amber-700" />
              <h2 className="text-2xl font-bold text-gray-900">Content Management</h2>
            </div>
            <Tabs defaultValue="videos" className="w-full">
              <TabsList className="bg-gray-100 p-1 rounded-lg">
                <TabsTrigger value="videos">Videos</TabsTrigger>
                <TabsTrigger value="buckets">Buckets</TabsTrigger>
              </TabsList>

              <TabsContent value="videos" className="mt-6">
                <AdminVideoList />
              </TabsContent>

              <TabsContent value="buckets" className="mt-6">
                <AdminBucketManager />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>
    </div>
  );
}
