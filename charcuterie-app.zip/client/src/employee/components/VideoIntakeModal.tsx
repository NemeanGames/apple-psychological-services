/**
 * Video Intake Modal Component
 * Minimal form for staff to register social media video URLs
 * Supports Instagram, TikTok, YouTube embeds
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

type ContentType = "bts" | "product" | "testimonial" | "event" | "other";
type VideoStatus = "draft" | "published";

interface VideoIntakeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function VideoIntakeModal({
  open,
  onOpenChange,
  onSuccess,
}: VideoIntakeModalProps) {
  const [platformUrl, setPlatformUrl] = useState("");
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState<VideoStatus>("draft");
  const [contentType, setContentType] = useState<ContentType>("other");
  const [bucketId, setBucketId] = useState<string>("");

  // Fetch buckets for selection
  const { data: bucketsData } = trpc.cmsBuckets.list.useQuery({
    page: 1,
    limit: 100,
    includeVideos: false,
  });

  // Create video mutation
  const createVideoMutation = trpc.cmsVideos.createFromUrl.useMutation({
    onSuccess: () => {
      toast.success("Video registered successfully");
      resetForm();
      onOpenChange(false);
      onSuccess?.();
    },
    onError: (error) => {
      toast.error(`Failed to register video: ${error.message}`);
    },
  });

  const resetForm = () => {
    setPlatformUrl("");
    setTitle("");
    setStatus("draft");
    setContentType("other");
    setBucketId("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!platformUrl.trim()) {
      toast.error("Platform URL is required");
      return;
    }

    // Basic URL validation
    try {
      new URL(platformUrl);
    } catch {
      toast.error("Invalid URL format");
      return;
    }

    await createVideoMutation.mutateAsync({
      platformUrl: platformUrl.trim(),
      title: title.trim() || undefined,
      status,
      contentType,
      bucketId: bucketId ? parseInt(bucketId) : undefined,
    });
  };

  const handleClose = () => {
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Register Social Media Video</DialogTitle>
          <DialogDescription>
            Paste a URL from Instagram, TikTok, or YouTube to register a new
            video
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Platform URL */}
          <div className="space-y-2">
            <Label htmlFor="platformUrl">
              Platform URL <span className="text-red-500">*</span>
            </Label>
            <Input
              id="platformUrl"
              placeholder="https://www.instagram.com/p/... or https://www.tiktok.com/@.../video/..."
              value={platformUrl}
              onChange={(e) => setPlatformUrl(e.target.value)}
              disabled={createVideoMutation.isPending}
            />
            <p className="text-xs text-gray-500">
              Supported: Instagram posts, TikTok videos, YouTube videos
            </p>
          </div>

          {/* Title (Optional) */}
          <div className="space-y-2">
            <Label htmlFor="title">Title (Optional)</Label>
            <Input
              id="title"
              placeholder="Custom title for this video"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={createVideoMutation.isPending}
            />
          </div>

          {/* Status */}
          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select
              value={status}
              onValueChange={(value) => setStatus(value as VideoStatus)}
              disabled={createVideoMutation.isPending}
            >
              <SelectTrigger id="status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="published">Published</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Content Type */}
          <div className="space-y-2">
            <Label htmlFor="contentType">Content Type</Label>
            <Select
              value={contentType}
              onValueChange={(value) => setContentType(value as ContentType)}
              disabled={createVideoMutation.isPending}
            >
              <SelectTrigger id="contentType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bts">Behind-the-Scenes</SelectItem>
                <SelectItem value="product">Product</SelectItem>
                <SelectItem value="testimonial">Testimonial</SelectItem>
                <SelectItem value="event">Event</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Bucket Selection (Optional) */}
          <div className="space-y-2">
            <Label htmlFor="bucketId">Assign to Bucket (Optional)</Label>
            <Select
              value={bucketId}
              onValueChange={setBucketId}
              disabled={createVideoMutation.isPending}
            >
              <SelectTrigger id="bucketId">
                <SelectValue placeholder="Select a bucket..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">No bucket</SelectItem>
                {bucketsData?.items.map((bucket: any) => (
                  <SelectItem key={bucket.id} value={bucket.id.toString()}>
                    {bucket.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Actions */}
          <div className="flex gap-2 justify-end pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={createVideoMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createVideoMutation.isPending}
              className="gap-2"
            >
              {createVideoMutation.isPending && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
              Register Video
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
