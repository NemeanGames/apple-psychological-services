/**
 * Admin Video List Component
 * Minimal UI for managing official videos with status filtering
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus } from "lucide-react";
import { VideoIntakeModal } from "./VideoIntakeModal";

type VideoStatus = "draft" | "review" | "scheduled" | "published" | "archived";
type ContentType = "bts" | "product" | "testimonial" | "event" | "other";

export function AdminVideoList() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<VideoStatus | "">("");
  const [contentTypeFilter, setContentTypeFilter] = useState<ContentType | "">(
    ""
  );
  const [intakeModalOpen, setIntakeModalOpen] = useState(false);

  const handleStatusChange = (value: string) => {
    setStatusFilter(value as VideoStatus | "");
  };

  const handleContentTypeChange = (value: string) => {
    setContentTypeFilter(value as ContentType | "");
  };

  // Fetch videos with filters
  const { data, isLoading, error, refetch } = trpc.cmsVideos.list.useQuery({
    page,
    limit: 20,
    status: statusFilter ? (statusFilter as VideoStatus) : undefined,
    contentType: contentTypeFilter ? (contentTypeFilter as ContentType) : undefined,
  });

  if (error) {
    return (
      <Card className="p-4 border-red-200 bg-red-50">
        <p className="text-red-800">Error loading videos: {error.message}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header with Add Video Button */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Video Library</h2>
        <Button
          onClick={() => setIntakeModalOpen(true)}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Video
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <Select value={statusFilter} onValueChange={handleStatusChange}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Statuses</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="review">Review</SelectItem>
            <SelectItem value="scheduled">Scheduled</SelectItem>
            <SelectItem value="published">Published</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>

        <Select value={contentTypeFilter} onValueChange={handleContentTypeChange}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Types</SelectItem>
            <SelectItem value="bts">Behind-the-Scenes</SelectItem>
            <SelectItem value="product">Product</SelectItem>
            <SelectItem value="testimonial">Testimonial</SelectItem>
            <SelectItem value="event">Event</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Video List */}
      {isLoading ? (
        <div className="flex items-center justify-center p-8">
          <Loader2 className="animate-spin" />
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {data?.items.map((video: any) => (
              <Card key={video.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold">{video.title}</h3>
                    <p className="text-sm text-gray-600">
                      {video.platform} • {video.contentType}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Status: <span className="font-medium">{video.status}</span>
                    </p>
                    {video.campaign && (
                      <p className="text-xs text-gray-500">
                        Campaign: {video.campaign}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      Edit
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600">
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {data && data.pages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Page {data.page} of {data.pages} ({data.total} total)
              </p>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                >
                  Previous
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page === data.pages}
                  onClick={() => setPage(page + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Video Intake Modal */}
      <VideoIntakeModal
        open={intakeModalOpen}
        onOpenChange={setIntakeModalOpen}
        onSuccess={() => refetch()}
      />
    </div>
  );
}
