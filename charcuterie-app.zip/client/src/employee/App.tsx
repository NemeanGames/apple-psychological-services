import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2 } from "lucide-react";
import { Route, Switch } from "wouter";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/sonner";
import NotFound from "@/pages/NotFound";
import AdminDashboard from "./pages/AdminDashboard";

function EmployeeRouter() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="animate-spin h-12 w-12 mx-auto mb-4 text-amber-700" />
          <p className="text-gray-600">Loading staff portal...</p>
        </div>
      </div>
    );
  }

  // Check if user is authorized (admin or staff)
  const userRole = (user as any)?.role;
  const isAuthorized = user && (userRole === "admin" || userRole === "staff");

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Please sign in to access the staff portal.</p>
          <a href="/" className="text-amber-700 hover:text-amber-800 font-medium">
            Go to main site
          </a>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-600 mb-4">Access denied. You do not have permission to access the staff portal.</p>
          <a href="/" className="text-amber-700 hover:text-amber-800 font-medium">
            Go to main site
          </a>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/" component={AdminDashboard} />
      <Route path="/*" component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <EmployeeRouter />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
