import { createContext, useContext, useEffect } from "react";

export interface Theme {
  name: string;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
  border: string;
}

export const themes: Record<string, Theme> = {
  "Boardella Signature": {
    name: "Boardella Signature",
    primary: "#8B4513",
    secondary: "#A0522D",
    accent: "#DAA520",
    background: "#FFF8DC",
    text: "#2F1B0C",
    border: "#DAA520",
  },
  "Boardella Premium": {
    name: "Boardella Premium",
    primary: "#1C1C1C",
    secondary: "#3D3D3D",
    accent: "#FFD700",
    background: "#F5F5F5",
    text: "#1C1C1C",
    border: "#FFD700",
  },
  "Velvet & Vine Boards": {
    name: "Velvet & Vine Boards",
    primary: "#6B3E2E",
    secondary: "#8B5A3C",
    accent: "#D4A574",
    background: "#FBF8F3",
    text: "#2C1810",
    border: "#D4A574",
  },
  "Goldleaf Grazing Co.": {
    name: "Goldleaf Grazing Co.",
    primary: "#1F1F1F",
    secondary: "#3D3D3D",
    accent: "#D4AF37",
    background: "#F5F5F5",
    text: "#1F1F1F",
    border: "#D4AF37",
  },
  "The Opulent Board": {
    name: "The Opulent Board",
    primary: "#2D1B4E",
    secondary: "#4A2C6B",
    accent: "#C9A961",
    background: "#F9F7F4",
    text: "#1A1A1A",
    border: "#C9A961",
  },
  "Rustic Farmstead": {
    name: "Rustic Farmstead",
    primary: "#5C4033",
    secondary: "#8D6E63",
    accent: "#A1887F",
    background: "#FEFDF9",
    text: "#3E2723",
    border: "#A1887F",
  },
  "Artisan Heritage": {
    name: "Artisan Heritage",
    primary: "#1B1B1B",
    secondary: "#4A4A4A",
    accent: "#C4A747",
    background: "#F7F6F1",
    text: "#1B1B1B",
    border: "#C4A747",
  },
  "Midnight Elegance": {
    name: "Midnight Elegance",
    primary: "#0F0F0F",
    secondary: "#2A2A2A",
    accent: "#E8D5B7",
    background: "#F8F7F5",
    text: "#0F0F0F",
    border: "#E8D5B7",
  },
  "Copper & Cream": {
    name: "Copper & Cream",
    primary: "#704214",
    secondary: "#B8860B",
    accent: "#D2691E",
    background: "#FFFAF0",
    text: "#3E2723",
    border: "#D2691E",
  },
  "Slate & Stone": {
    name: "Slate & Stone",
    primary: "#2C3E50",
    secondary: "#34495E",
    accent: "#95A5A6",
    background: "#ECF0F1",
    text: "#2C3E50",
    border: "#95A5A6",
  },
  "Burgundy Dreams": {
    name: "Burgundy Dreams",
    primary: "#4A1A1A",
    secondary: "#8B3A3A",
    accent: "#D4A574",
    background: "#FBF8F3",
    text: "#2C1810",
    border: "#D4A574",
  },
  "Sage & Walnut": {
    name: "Sage & Walnut",
    primary: "#3D5A3D",
    secondary: "#6B8E6B",
    accent: "#A89968",
    background: "#F5F7F4",
    text: "#2D3D2D",
    border: "#A89968",
  },
};

interface BrandContextType {
  currentTheme: Theme;
  brandName: string;
}

const BrandContext = createContext<BrandContextType | undefined>(undefined);

export function BrandProvider({ children }: { children: React.ReactNode }) {
  const currentTheme = themes["Boardella Signature"];
  const brandName = "BOARDELLA";

  useEffect(() => {
    applyTheme(currentTheme);
  }, []);

  return (
    <BrandContext.Provider
      value={{
        currentTheme,
        brandName,
      }}
    >
      {children}
    </BrandContext.Provider>
  );
}

export function useBrand() {
  const context = useContext(BrandContext);
  if (!context) {
    throw new Error("useBrand must be used within BrandProvider");
  }
  return context;
}

// Note: Theme switching has been removed for production. 
// The brand is locked to "Boardella Signature" theme.

function applyTheme(theme: Theme) {
  const root = document.documentElement;
  root.style.setProperty("--color-primary", theme.primary);
  root.style.setProperty("--color-secondary", theme.secondary);
  root.style.setProperty("--color-accent", theme.accent);
  root.style.setProperty("--color-background", theme.background);
  root.style.setProperty("--color-text", theme.text);
  root.style.setProperty("--color-border", theme.border);
}
