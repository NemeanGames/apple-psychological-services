import { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight, X, Heart, MessageCircle, Share2 } from "lucide-react";

interface CarouselItem {
  id: number;
  type: "video" | "image";
  url: string;
  title: string;
  description: string;
  creator: string;
  likes: number;
  comments: number;
}

interface InstagramCarouselProps {
  items: CarouselItem[];
  isOpen: boolean;
  onClose: () => void;
  initialIndex?: number;
}

export default function InstagramCarousel({
  items,
  isOpen,
  onClose,
  initialIndex = 0,
}: InstagramCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [likedItems, setLikedItems] = useState<number[]>([]);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const currentItem = items[currentIndex];

  useEffect(() => {
    setCurrentIndex(initialIndex);
  }, [initialIndex, isOpen]);

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? items.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === items.length - 1 ? 0 : prev + 1));
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    setTouchEnd(e.changedTouches[0].clientX);
    handleSwipe();
  };

  const handleSwipe = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
      handleNext();
    }
    if (isRightSwipe) {
      handlePrevious();
    }
  };

  const toggleLike = (id: number) => {
    setLikedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") handlePrevious();
      if (e.key === "ArrowRight") handleNext();
      if (e.key === "Escape") onClose();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen]);

  if (!isOpen || !currentItem) return null;

  return (
    <div
      className="fixed inset-0 bg-black z-50 flex items-center justify-center"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      ref={containerRef}
    >
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 z-50 p-2 bg-black bg-opacity-50 hover:bg-opacity-70 rounded-full transition text-white"
        >
          <X size={28} />
        </button>

        {/* Main Content */}
        <div className="flex w-full h-full max-w-6xl">
          {/* Media */}
          <div
            className="flex-1 flex items-center justify-center bg-black relative"
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            {currentItem.type === "video" ? (
              <video
                key={currentItem.id}
                src={currentItem.url}
                className="w-full h-full object-cover"
                autoPlay
                controls
                muted={false}
              />
            ) : (
              <img
                key={currentItem.id}
                src={currentItem.url}
                alt={currentItem.title}
                className="w-full h-full object-cover"
              />
            )}

            {/* Navigation Arrows */}
            <button
              onClick={handlePrevious}
              className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-white bg-opacity-30 hover:bg-opacity-50 rounded-full transition text-white z-10"
            >
              <ChevronLeft size={32} />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-white bg-opacity-30 hover:bg-opacity-50 rounded-full transition text-white z-10"
            >
              <ChevronRight size={32} />
            </button>

            {/* Progress Indicators */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {items.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-1 rounded-full transition ${
                    idx === currentIndex
                      ? "bg-white w-8"
                      : "bg-white bg-opacity-50 w-2"
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Info Sidebar */}
          <div className="w-full md:w-96 bg-black text-white flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-slate-700">
              <h3 className="text-xl font-light tracking-wide mb-2">
                {currentItem.title}
              </h3>
              <p className="text-sm text-slate-400">{currentItem.creator}</p>
            </div>

            {/* Description */}
            <div className="flex-1 overflow-y-auto p-6">
              <p className="text-sm leading-relaxed text-slate-300 mb-6">
                {currentItem.description}
              </p>

              {/* Stats */}
              <div className="flex gap-6 text-sm text-slate-400 mb-6 pb-6 border-b border-slate-700">
                <span className="flex items-center gap-2">
                  <Heart size={16} />
                  {currentItem.likes}
                </span>
                <span className="flex items-center gap-2">
                  <MessageCircle size={16} />
                  {currentItem.comments}
                </span>
              </div>

              {/* Engagement */}
              <div className="space-y-3">
                <button
                  onClick={() => toggleLike(currentItem.id)}
                  className={`w-full flex items-center justify-center gap-2 py-2 rounded transition ${
                    likedItems.includes(currentItem.id)
                      ? "bg-red-600 hover:bg-red-700 text-white"
                      : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                  }`}
                >
                  <Heart
                    size={18}
                    fill={likedItems.includes(currentItem.id) ? "currentColor" : "none"}
                  />
                  {likedItems.includes(currentItem.id) ? "Liked" : "Like"}
                </button>
                <button className="w-full flex items-center justify-center gap-2 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition">
                  <MessageCircle size={18} />
                  Comment
                </button>
                <button className="w-full flex items-center justify-center gap-2 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition">
                  <Share2 size={18} />
                  Share
                </button>
              </div>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-slate-700 text-center text-xs text-slate-500">
              {currentIndex + 1} / {items.length}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
