import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Home,
  ShoppingBag,
  Menu,
  X,
  ShoppingCart,
  Image,
  User,
} from "lucide-react";
import { useBrand } from "@/contexts/BrandContext";

interface NavigationProps {
  onNavigate?: () => void;
}

export default function Navigation({ onNavigate }: NavigationProps) {
  const [, setLocation] = useLocation();
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const { brandName } = useBrand();

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setIsMobileDrawerOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const navItems = [
    { label: "Home", icon: Home, path: "/" },
    { label: "Collections", icon: ShoppingBag, path: "/menu" },
    { label: "Discover", icon: Image, path: "/discover" },
  ];

  const handleNavClick = (path: string) => {
    setLocation(path);
    setIsMobileDrawerOpen(false);
    onNavigate?.();
  };

  // Mobile Bottom Navigation
  if (isMobile) {
    return (
      <>
        {/* Mobile Header */}
        <nav className="sticky top-0 z-40 bg-white border-b border-slate-200">
          <div className="px-4 py-4 flex items-center justify-between">
            <h1 className="text-lg font-light tracking-wide text-slate-900">{brandName}</h1>
            <div className="flex items-center gap-4">
              <button
                onClick={() => handleNavClick("/cart")}
                className="p-2 text-slate-900 hover:bg-slate-100 rounded transition"
              >
                <ShoppingCart size={20} />
              </button>
              <button
                onClick={() => setIsMobileDrawerOpen(!isMobileDrawerOpen)}
                className="p-2 text-slate-900 hover:bg-slate-100 rounded transition"
              >
                {isMobileDrawerOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>



        {/* Mobile Drawer */}
          {isMobileDrawerOpen && (
            <div className="border-t border-slate-200 bg-white">
              <div className="px-4 py-4 space-y-2">
                {navItems.map((item) => (
                  <button
                    key={item.path}
                    onClick={() => handleNavClick(item.path)}
                    className="w-full text-left px-4 py-3 flex items-center gap-3 text-slate-900 hover:bg-slate-50 rounded transition"
                  >
                    <item.icon size={20} />
                    <span className="font-medium">{item.label}</span>
                  </button>
                ))}
                {/* Account Link */}
                <button
                  onClick={() => handleNavClick("/account")}
                  className="w-full text-left px-4 py-3 flex items-center gap-3 text-slate-900 hover:bg-slate-50 rounded transition border-t border-slate-200 mt-2 pt-4"
                >
                  <User size={20} />
                  <span className="font-medium">Account</span>
                </button>
              </div>
            </div>
          )}
        </nav>

        {/* Mobile Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200">
          <div className="flex items-center justify-around">
            {navItems.slice(0, 5).map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavClick(item.path)}
                className="flex-1 flex flex-col items-center justify-center py-3 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition"
              >
                <item.icon size={24} />
                <span className="text-xs font-medium mt-1">{item.label}</span>
              </button>
            ))}
          </div>
        </nav>
      </>
    );
  }

  // Desktop Left Drawer Navigation
  return (
    <>
      <nav className="fixed left-0 top-0 h-screen w-64 bg-white border-r border-slate-200 z-50 flex flex-col">
        {/* Logo */}
        <div className="p-8 border-b border-slate-200">
          <h1 className="text-xl font-light tracking-wide text-slate-900">{brandName}</h1>
        </div>

      {/* Navigation Items */}
      <div className="flex-1 overflow-y-auto py-8 px-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.path}
            onClick={() => handleNavClick(item.path)}
            className="w-full text-left px-4 py-3 flex items-center gap-3 text-slate-700 hover:text-slate-900 hover:bg-slate-50 rounded transition"
          >
            <item.icon size={20} />
            <span className="font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </div>

      {/* Cart & Account */}
      <div className="border-t border-slate-200 p-4 space-y-2">
        <button
          onClick={() => handleNavClick("/account")}
          className="w-full text-left px-4 py-3 flex items-center gap-3 text-slate-700 hover:text-slate-900 hover:bg-slate-50 rounded transition"
        >
          <User size={20} />
          <span className="font-medium text-sm">Account</span>
        </button>
        <button
          onClick={() => handleNavClick("/cart")}
          className="w-full text-left px-4 py-3 flex items-center gap-3 text-slate-700 hover:text-slate-900 hover:bg-slate-50 rounded transition"
        >
          <ShoppingCart size={20} />
          <span className="font-medium text-sm">Cart</span>
        </button>
      </div>
    </nav>
    </>
  );
}
