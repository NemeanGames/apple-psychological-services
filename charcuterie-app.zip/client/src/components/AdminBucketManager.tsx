/**
 * Admin Bucket Manager Component
 * Minimal UI for managing video buckets and their contents
 */

import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export function AdminBucketManager() {
  const [page, setPage] = useState(1);
  const [newBucketName, setNewBucketName] = useState("");
  const [newBucketDescription, setNewBucketDescription] = useState("");

  // Fetch buckets
  const { data, isLoading, error, refetch } = trpc.cmsBuckets.list.useQuery({
    page,
    limit: 20,
    includeVideos: true,
  });

  // Create bucket mutation
  const createBucketMutation = trpc.cmsBuckets.create.useMutation({
    onSuccess: () => {
      setNewBucketName("");
      setNewBucketDescription("");
      refetch();
      toast.success("Bucket created successfully");
    },
    onError: (error) => {
      toast.error(`Failed to create bucket: ${error.message}`);
    },
  });

  // Delete bucket mutation
  const deleteBucketMutation = trpc.cmsBuckets.delete.useMutation({
    onSuccess: () => {
      refetch();
      toast.success("Bucket deleted successfully");
    },
    onError: (error) => {
      toast.error(`Failed to delete bucket: ${error.message}`);
    },
  });

  // Publish state mutation
  const setPublishMutation = trpc.cmsBuckets.setPublishState.useMutation({
    onSuccess: () => {
      refetch();
      toast.success("Bucket publish state updated");
    },
    onError: (error) => {
      toast.error(`Failed to update publish state: ${error.message}`);
    },
  });

  const handleCreateBucket = async () => {
    if (!newBucketName.trim()) {
      toast.error("Bucket name is required");
      return;
    }

    await createBucketMutation.mutateAsync({
      name: newBucketName,
      description: newBucketDescription,
      isPublished: 0,
      displayOrder: 0,
    });
  };

  if (error) {
    return (
      <Card className="p-4 border-red-200 bg-red-50">
        <p className="text-red-800">Error loading buckets: {error.message}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Create New Bucket */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <h3 className="font-semibold mb-4">Create New Bucket</h3>
        <div className="space-y-3">
          <Input
            placeholder="Bucket name"
            value={newBucketName}
            onChange={(e) => setNewBucketName(e.target.value)}
          />
          <Input
            placeholder="Description (optional)"
            value={newBucketDescription}
            onChange={(e) => setNewBucketDescription(e.target.value)}
          />
          <Button
            onClick={handleCreateBucket}
            disabled={createBucketMutation.isPending}
          >
            {createBucketMutation.isPending ? (
              <>
                <Loader2 className="animate-spin mr-2" />
                Creating...
              </>
            ) : (
              "Create Bucket"
            )}
          </Button>
        </div>
      </Card>

      {/* Buckets List */}
      {isLoading ? (
        <div className="flex items-center justify-center p-8">
          <Loader2 className="animate-spin" />
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {data?.items.map((bucket: any) => (
              <Card key={bucket.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{bucket.name}</h3>
                      <span
                        className={`text-xs px-2 py-1 rounded ${
                          bucket.isPublished
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {bucket.isPublished ? "Published" : "Draft"}
                      </span>
                    </div>
                    {bucket.description && (
                      <p className="text-sm text-gray-600 mt-1">
                        {bucket.description}
                      </p>
                    )}
                    {bucket.videos && (
                      <p className="text-xs text-gray-500 mt-2">
                        {bucket.videos.length} video(s)
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setPublishMutation.mutateAsync({
                          id: bucket.id,
                          isPublished: bucket.isPublished ? 0 : 1,
                        })
                      }
                      disabled={setPublishMutation.isPending}
                    >
                      {bucket.isPublished ? "Unpublish" : "Publish"}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        deleteBucketMutation.mutateAsync({ id: bucket.id })
                      }
                      disabled={deleteBucketMutation.isPending}
                      className="text-red-600"
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          {data && data.pages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Page {data.page} of {data.pages} ({data.total} total)
              </p>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                >
                  Previous
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={page === data.pages}
                  onClick={() => setPage(page + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
