import { useEffect } from "react";
import { Play } from "lucide-react";

interface SocialVideoPlayerProps {
  platform: "instagram" | "tiktok" | "youtube";
  platformUrl: string;
  title?: string;
  creator?: string;
  creatorHandle?: string;
  thumbnailUrl?: string;
  className?: string;
}

/**
 * SocialVideoPlayer Component
 * Embeds videos from Instagram, TikTok, and YouTube without hosting video files
 * Each platform handles its own video hosting and playback
 */
export default function SocialVideoPlayer({
  platform,
  platformUrl,
  title,
  creator,
  creatorHandle,
  thumbnailUrl,
  className = "",
}: SocialVideoPlayerProps) {
  useEffect(() => {
    // Load Instagram embed script if needed
    if (platform === "instagram" && window.instgrm) {
      window.instgrm.Embeds.process();
    }
  }, [platform, platformUrl]);

  const getEmbedCode = () => {
    switch (platform) {
      case "instagram": {
        // Instagram embed - use blockquote with Instagram embed script
        return (
          <div className={`instagram-embed-wrapper ${className}`}>
            <iframe
              src={`${platformUrl}embed/`}
              width="100%"
              height="600"
              frameBorder="0"
              scrolling="no"
              allowTransparency={true}
              allow="encrypted-media"
              title={title || "Instagram Video"}
              className="rounded-lg"
            />
          </div>
        );
      }

      case "tiktok": {
        // TikTok embed - extract video ID from URL
        const videoId = platformUrl.includes("vm.tiktok.com")
          ? platformUrl.split("/").pop()
          : platformUrl.split("/v/")[1]?.split("?")[0];

        return (
          <div className={`tiktok-embed-wrapper ${className}`}>
            <blockquote
              className="tiktok-embed"
              cite={platformUrl}
              data-unique-id={videoId}
            >
              <section>
                <a
                  target="_blank"
                  rel="noopener noreferrer"
                  href={platformUrl}
                  title={title || "TikTok Video"}
                >
                  Watch on TikTok
                </a>
              </section>
            </blockquote>
            <script async src="https://www.tiktok.com/embed.js"></script>
          </div>
        );
      }

      case "youtube": {
        // YouTube embed - extract video ID from URL
        let videoId = "";
        if (platformUrl.includes("youtu.be")) {
          videoId = platformUrl.split("/").pop()?.split("?")[0] || "";
        } else if (platformUrl.includes("youtube.com")) {
          const urlParams = new URLSearchParams(platformUrl.split("?")[1]);
          videoId = urlParams.get("v") || "";
        }

        if (!videoId) {
          return (
            <div className={`youtube-error ${className}`}>
              <p className="text-red-600">Invalid YouTube URL</p>
            </div>
          );
        }

        return (
          <div className={`youtube-embed-wrapper aspect-video ${className}`}>
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${videoId}`}
              title={title || "YouTube Video"}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="rounded-lg"
            />
          </div>
        );
      }

      default:
        return (
          <div className={`video-error ${className}`}>
            <p className="text-red-600">Unsupported platform</p>
          </div>
        );
    }
  };

  return (
    <div className={`social-video-player ${className}`}>
      {/* Video Container */}
      <div className="relative bg-black rounded-lg overflow-hidden">
        {getEmbedCode()}
      </div>

      {/* Metadata Footer */}
      {(creator || creatorHandle) && (
        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">
            {creator && <span className="font-medium">{creator}</span>}
            {creatorHandle && (
              <span className="text-gray-500"> {creatorHandle}</span>
            )}
          </p>
          {title && <p className="text-sm font-medium text-gray-900 mt-1">{title}</p>}
        </div>
      )}

      {/* Platform Badge */}
      <div className="mt-2 flex items-center gap-2">
        <span className="inline-block px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full capitalize">
          {platform}
        </span>
      </div>
    </div>
  );
}

// Type declaration for Instagram embed script
declare global {
  interface Window {
    instgrm?: {
      Embeds: {
        process: () => void;
      };
    };
  }
}
