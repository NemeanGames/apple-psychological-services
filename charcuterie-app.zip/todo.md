# Boardella Production Transformation – Sprint Roadmap

## SPRINT 1: Foundation & Security (Weeks 1-2)

### Task 1.1: Audit & Remove Demo Elements
- [x] Remove theme switcher component and all theme selection UI
- [x] Remove mock data arrays from Community, Resources, Gallery pages
- [x] Remove BrandCustomizer component and related dev-only utilities
- [x] Remove placeholder checkout page (replace with real checkout)
- [x] Remove all hardcoded sample data from components
- [x] Verify all pages fetch data from backend APIs
- [x] No theme-related UI visible to users

### Task 1.2: Input Validation Schema (Zod)
- [x] Create validation schemas for all API inputs
- [x] Schemas for user registration, login, product creation, orders
- [x] Schemas for community posts, comments, video metadata
- [x] Custom error messages for validation failures
- [x] All backend routes validate input with schemas
- [x] Centralized schema definitions in `server/_core/validation.ts`
- [x] Type inference from schemas to frontend

### Task 1.3: Output Encoding & XSS Prevention
- [x] HTML entity encoding for all user-generated content
- [x] Markdown sanitization for community posts
- [x] Image URL validation (prevent script injection)
- [x] JSON encoding for API responses
- [x] Content-Security-Policy headers configured
- [x] X-Frame-Options: DENY
- [x] X-Content-Type-Options: nosniff
- [x] X-XSS-Protection: 1; mode=block

### Task 1.4: CSRF Protection
- [ ] CSRF token generated for each session
- [ ] Token validated on POST/PUT/DELETE requests
- [ ] Token included in form submissions
- [ ] SameSite cookie attribute set to Strict
- [ ] Token rotation after successful validation
- [ ] Error handling for invalid/expired tokens

### Task 1.5: Rate Limiting
- [ ] Rate limit: 100 requests/minute per IP (general)
- [ ] Auth endpoints: 5 attempts/minute
- [ ] API endpoints: 1000/hour per user
- [ ] Rate limit headers in responses (X-RateLimit-*)
- [ ] Whitelist for trusted IPs (admin, monitoring)
- [ ] Logging for rate limit violations
- [ ] Graceful error messages for rate-limited users

### Task 1.6: Security Headers Middleware
- [ ] Content-Security-Policy (CSP) configured
- [ ] Strict-Transport-Security (HSTS) enabled
- [ ] Referrer-Policy: strict-origin-when-cross-origin
- [ ] Permissions-Policy configured
- [ ] All headers applied to all responses
- [ ] No inline scripts (CSP nonce for critical code)
- [ ] Testing with security header checkers

### Task 1.7: Environment Variable Security
- [ ] All secrets stored in environment variables
- [ ] No secrets hardcoded in source files
- [ ] `.env` file in `.gitignore`
- [ ] `.env.example` with placeholder values
- [ ] Documentation for required environment variables
- [ ] Validation that all required env vars are set on startup
- [ ] Secrets masked in logs

### Task 1.8: Testing & Documentation
- [ ] Unit tests for validation schemas
- [ ] Integration tests for security headers
- [ ] Test CSRF token validation
- [ ] Test rate limiting behavior
- [ ] Security best practices documentation
- [ ] Environment setup guide
- [ ] Security checklist for deployment

---

## SPRINT 2 Phase 6B: Admin Separation (Option B)
- [x] Create separate employee app entry point (employee.html, src/employee/main.tsx)
- [x] Move admin components to employee-only directory
- [x] Remove Admin from customer Navigation
- [x] Configure Vite dual-entry build
- [x] Configure server routing for dual-entry
- [x] Test customer app has zero admin traces (PASSED)
- [x] Test employee portal loads with RBAC (PASSED)
- [x] Test API/RBAC enforcement (PASSED)
- [x] Build production and verify output (PASSED)
- [x] Create final checkpoint

## SPRINT 2.5: Video Intake System (NEW)

### Phase 1-2: Video Intake Backend & UI
- [x] Create CMSVideoIntakeSchema validation
- [x] Create cmsVideos.createFromUrl procedure
- [x] Implement platform detection (Instagram, TikTok, YouTube)
- [x] Create VideoIntakeModal component
- [x] Integrate VideoIntakeModal with AdminVideoList
- [x] Fix createVideo to return created video with ID
- [x] Fix createBucket to return created bucket with ID

### Phase 3: End-to-End Testing
- [x] Write comprehensive vitest tests for video intake
- [x] Test URL detection and validation
- [x] Test video creation with minimal fields
- [x] Test optional title and content type support
- [x] Test bucket assignment (optional)
- [x] Test status transitions (draft → published)
- [x] Test field preservation during updates
- [x] All 79 tests passing

### Phase 4: Public Videos Endpoint
- [x] Create videos.listPublished public procedure
- [x] Implement optional bucket filtering
- [x] Add published-only filtering
- [x] Add bucket visibility check
- [x] Support fallback to all published videos

### Phase 5: Customer Gallery/Discover Page
- [x] Update Discover page to fetch published videos
- [x] Implement video transformation to DiscoverItem format
- [x] Add loading state with spinner
- [x] Add fallback to hardcoded sample video
- [x] Integrate SocialVideoPlayer for embedded videos
- [x] Maintain responsive grid layout

### Phase 6: Final Testing & Checkpoint
- [x] Verify TypeScript compilation (0 errors)
- [x] Verify all tests passing (79 tests)
- [x] Verify dev server running
- [x] Create checkpoint for deployment

## SPRINT 2.8: Whitelist Gate Implementation
- [x] Add accessTokens table to schema
- [x] Implement siteGate.ts middleware with jose library
- [x] Add token redemption endpoint (/access page + /api/access/redeem)
- [x] Add admin token minting procedures
- [x] Set trust proxy and secure cookies
- [x] Create comprehensive vitest tests
- [x] All 83 tests passing
- [x] Private mode enabled (SITE_ACCESS_MODE=private)

## SPRINT 2.9: Checkout System & Demo Cleanup
- [x] Extend orders schema with email, shipping address, PaymentIntent ID
- [x] Create Checkout page component with Stripe integration
- [x] Add checkout route to App.tsx
- [x] Create checkout API endpoint for PaymentIntent creation
- [x] Remove demo pages (Orders, Resources, Community, Builder, UGCGallery)
- [x] Remove theme switcher and BrandCustomizer
- [x] Add Account page with OAuth login
- [x] Add Account button to Navigation
- [x] Disable private mode (SITE_ACCESS_MODE=public)
- [x] Verify home page loads without gate

## SPRINT 2.10: Google OAuth & Admin Dashboard (TODO)

### Phase 1: Google OAuth Integration
- [ ] Implement Google OAuth callback handler with server-side validation
- [ ] Verify ID token signature (iss, aud, exp, sub)
- [ ] Store only Google sub + email + name (no tokens)
- [ ] Create/update users with minimal data
- [ ] Add "Sign in with Google" button to Account page
- [ ] Test Google Sign-In flow end-to-end
- [ ] Implement log redaction for sensitive data
- [ ] Verify no token leakage in URLs or logs

### Phase 2: Admin Dashboard
- [ ] Create admin dashboard at /admin
- [ ] Make adrianarvizu1994@gmail.com admin
- [ ] Make eriflores21@gmail.com admin
- [ ] Add admin controls:
  - [ ] View all orders
  - [ ] Manage site settings
  - [ ] View customer analytics
  - [ ] Manage access tokens (emergency gate)
  - [ ] View activity logs
- [ ] Implement per-request authorization checks
- [ ] Add role-based access control (admin vs user)

### Phase 3: Security & Privacy
- [ ] Implement CORS allowlist (only boardella.com, boards.manus.space)
- [ ] Set HttpOnly, Secure, SameSite cookies
- [ ] Add CSP headers
- [ ] Enable log redaction in error tracking
- [ ] Test token validation
- [ ] Verify customer data privacy
- [ ] Test unauthorized access rejection

### Phase 4: Testing & Checkpoint
- [ ] Test Google Sign-In as customer
- [ ] Test admin dashboard access
- [ ] Verify customer data privacy
- [ ] All tests passing
- [ ] Create final checkpoint for deployment

## SPRINT 2: Performance Optimization (Weeks 3-4)

### Task 2.1: Two-Document Delivery Model
- [ ] Document A (hero shell) at `/` – minimal landing page
- [ ] Document B (full app) at `/app` – complete SPA
- [ ] Hero shell: HTML + critical CSS only, no JS
- [ ] Hero shell includes CTAs: "Start Order", "View Boards"
- [ ] Prefetch `/app` on user intent (hover/touch)
- [ ] Smooth transition from hero to full app
- [ ] No layout shift between documents

### Task 2.2: Hero Shell Optimization (≤14 KB)
- [ ] Hero HTML + CSS < 14 KB (gzipped)
- [ ] No external fonts (system fonts only)
- [ ] No large images (text-only or small SVG)
- [ ] Minimal critical CSS (no animations)
- [ ] No JavaScript in hero shell
- [ ] Loader script < 2 KB
- [ ] Measure with `gzip` and report metrics

### Task 2.3: Route-Level Code Splitting
- [ ] Catalog route lazy-loaded
- [ ] Builder route lazy-loaded
- [ ] Checkout route lazy-loaded
- [ ] Account route lazy-loaded
- [ ] Admin route lazy-loaded
- [ ] Shared components in separate bundle
- [ ] No cross-route imports of heavy modules
- [ ] React.lazy() with Suspense boundaries

### Task 2.4: Third-Party Script Deferral
- [ ] Stripe loaded only on checkout route
- [ ] Analytics loaded after first interaction
- [ ] YouTube/Instagram embeds use poster cards (click-to-load)
- [ ] No global third-party scripts
- [ ] Dynamic import for route-specific scripts
- [ ] Error handling if third-party fails to load

### Task 2.5: Image Optimization
- [ ] All images optimized (WebP with JPEG fallback)
- [ ] Responsive images with srcset
- [ ] Lazy loading for below-the-fold images
- [ ] Image compression in build pipeline
- [ ] Product images: max 200 KB each
- [ ] Hero images: max 50 KB
- [ ] Thumbnails: max 20 KB
- [ ] Image optimization script in package.json

### Task 2.6: Database Query Optimization
- [ ] Indexes added to frequently queried columns (user_id, created_at, status)
- [ ] N+1 query problems identified and fixed
- [ ] Pagination implemented for large result sets
- [ ] Query execution plans reviewed
- [ ] Caching layer for frequently accessed data (boards list, user profile)
- [ ] Database monitoring enabled
- [ ] Query performance benchmarks documented

### Task 2.7: Caching Strategy
- [ ] Redis cache for boards list (TTL: 1 hour)
- [ ] Cache for user profiles (TTL: 30 minutes)
- [ ] Cache invalidation on data updates
- [ ] Cache hit rate monitoring
- [ ] Graceful fallback if cache unavailable
- [ ] Cache warming on startup
- [ ] Cache headers for static assets (1 year for versioned)

### Task 2.8: CDN Configuration
- [ ] CloudFlare or equivalent CDN configured
- [ ] Static assets (JS, CSS, images) cached
- [ ] Cache headers configured (1 year for versioned assets)
- [ ] Gzip compression enabled
- [ ] Brotli compression for modern browsers
- [ ] Origin shield enabled for cost optimization
- [ ] HTTP/2 and HTTP/3 enabled

### Task 2.9: Performance Testing & Monitoring
- [ ] Hero shell loads in <1 second on 4G
- [ ] Full app loads in 2-4 seconds on 4G
- [ ] First Contentful Paint (FCP) < 1 second
- [ ] Largest Contentful Paint (LCP) < 2.5 seconds
- [ ] Cumulative Layout Shift (CLS) < 0.1
- [ ] Performance monitoring dashboard created
- [ ] Alerts for performance degradation

---

## SPRINT 3: Admin Dashboard & Tools (Weeks 5-6)

### Task 3.1: Admin Dashboard Analytics
- [ ] Total orders and revenue (current month/year)
- [ ] Average order value
- [ ] New users (current month)
- [ ] Top-selling products
- [ ] Orders by status breakdown
- [ ] Charts using Recharts or similar
- [ ] Data refreshes every 5 minutes
- [ ] Export data to CSV

### Task 3.2: Analytics API Endpoints
- [ ] `GET /api/admin/analytics/overview` – summary stats
- [ ] `GET /api/admin/analytics/orders` – order trends
- [ ] `GET /api/admin/analytics/products` – product performance
- [ ] `GET /api/admin/analytics/users` – user growth
- [ ] All endpoints require ADMIN role
- [ ] Efficient queries with proper indexing
- [ ] Caching for frequently accessed data

### Task 3.3: Product Management CRUD
- [ ] Form to create new board/product
- [ ] Fields: name, description, price, image, tags, size, contents
- [ ] Image upload to S3
- [ ] Edit existing products
- [ ] Soft delete (mark inactive)
- [ ] Bulk actions (activate/deactivate multiple)
- [ ] Search and filter by name/category
- [ ] Only STAFF/ADMIN can access

### Task 3.4: Product Management API
- [ ] `POST /api/admin/boards` – create product
- [ ] `PUT /api/admin/boards/:id` – update product
- [ ] `DELETE /api/admin/boards/:id` – soft delete
- [ ] `GET /api/admin/boards` – list all (including inactive)
- [ ] Input validation for all fields
- [ ] Image upload handling
- [ ] Audit logging for changes

### Task 3.5: Order Fulfillment Interface
- [ ] List of pending orders sorted by date
- [ ] Order details: items, customer, address
- [ ] Dropdown to change order status
- [ ] Print shipping label button
- [ ] Mark as shipped with tracking number
- [ ] Search/filter by order ID or customer
- [ ] Bulk actions (mark multiple as shipped)
- [ ] Only accessible to STAFF/ADMIN

### Task 3.6: Order Fulfillment API
- [ ] `GET /api/admin/orders` – list pending orders
- [ ] `PUT /api/admin/orders/:id/status` – update order status
- [ ] Status flow: pending_payment → paid → preparing → shipped → delivered
- [ ] Only STAFF/ADMIN can access
- [ ] Timestamp recorded for each status change
- [ ] Notification sent to customer on status change
- [ ] Audit logging for all changes

### Task 3.7: Content Moderation Tools
- [ ] List of community posts with moderation status
- [ ] Flag/unflag posts as inappropriate
- [ ] Delete posts (soft delete)
- [ ] View reported comments
- [ ] Ban user from community (if needed)
- [ ] Moderation log with timestamps
- [ ] Only STAFF/ADMIN can access

### Task 3.8: User Management Interface
- [ ] List all users with roles and status
- [ ] Change user role (USER → STAFF → ADMIN)
- [ ] Deactivate/reactivate users
- [ ] View user details (email, signup date, orders)
- [ ] Search and filter users
- [ ] Bulk actions (change role for multiple users)
- [ ] Audit logging for role changes
- [ ] Only ADMIN can access

### Task 3.9: System Settings Interface
- [ ] Business settings: name, email, phone
- [ ] Payment settings: Stripe keys (masked)
- [ ] Email settings: sender, template customization
- [ ] Shipping settings: rates, carriers
- [ ] Tax settings: rates by region
- [ ] Form validation and error handling
- [ ] Confirmation dialog for critical changes
- [ ] Only ADMIN can modify

### Task 3.10: Testing & Documentation
- [ ] Test all admin features with different roles
- [ ] Test product CRUD operations
- [ ] Test order fulfillment workflow
- [ ] Test content moderation
- [ ] Admin user guide documented
- [ ] API documentation for admin endpoints

---

## SPRINT 4: Content & Features (Weeks 7-8)

### Task 4.1: Product Data Population
- [ ] Create 10-15 sample charcuterie boards with images
- [ ] Include pricing, descriptions, ingredients
- [ ] Add product categories and tags
- [ ] Create seasonal/featured boards
- [ ] Upload product images to S3
- [ ] Verify all products visible in catalog
- [ ] Test filtering and sorting

### Task 4.2: Community Content Migration
- [ ] Migrate sample posts to database
- [ ] Create sample comments for posts
- [ ] Implement real-time post creation from API
- [ ] Implement real-time comment creation
- [ ] Add pagination for community feed
- [ ] Implement sorting (newest, most liked)
- [ ] Test community features end-to-end

### Task 4.3: Video Library Optimization
- [ ] Add 5-10 sample videos (Instagram, TikTok, YouTube)
- [ ] Implement poster cards for click-to-load
- [ ] Add video metadata (title, creator, platform)
- [ ] Implement video filtering by platform
- [ ] Add video search functionality
- [ ] Test video player across platforms
- [ ] Verify no performance impact

### Task 4.4: Resources Page Implementation
- [ ] Create resource content (guides, recipes, tips)
- [ ] Implement resource categories
- [ ] Add search and filtering
- [ ] Link to social media (@BoardellaOfficial)
- [ ] Add newsletter signup form
- [ ] Test all resources load correctly

### Task 4.5: Cart & Checkout Flow Verification
- [ ] Test add to cart functionality
- [ ] Test cart updates and removal
- [ ] Test checkout flow end-to-end
- [ ] Test payment processing (test mode)
- [ ] Test order confirmation
- [ ] Test email notifications
- [ ] Test order history

### Task 4.6: Email Templates & Notifications
- [ ] Order confirmation email template
- [ ] Shipping notification email
- [ ] Delivery confirmation email
- [ ] Community post notification (optional)
- [ ] Email customization in admin panel
- [ ] Test email delivery
- [ ] Verify email branding

### Task 4.7: Mobile Responsiveness Testing
- [ ] Test all pages on mobile (iOS and Android)
- [ ] Verify touch interactions work correctly
- [ ] Test form inputs on mobile
- [ ] Test navigation on mobile
- [ ] Verify images scale correctly
- [ ] Test video player on mobile
- [ ] No horizontal scrolling

### Task 4.8: Feature Documentation
- [ ] User guide for all features
- [ ] Admin guide for content management
- [ ] API documentation for new endpoints
- [ ] Troubleshooting guide
- [ ] FAQ document

---

## SPRINT 5: Testing & Hardening (Weeks 9-10)

### Task 5.1: Functional Testing
- [ ] User registration and login flow
- [ ] Product browsing and search
- [ ] Cart management and checkout
- [ ] Payment processing (test mode)
- [ ] Order tracking and history
- [ ] Community features (posts, comments)
- [ ] Admin panel functionality
- [ ] All test cases documented and passed

### Task 5.2: Security Audit
- [ ] OWASP Top 10 vulnerability scan
- [ ] SQL injection testing
- [ ] XSS vulnerability testing
- [ ] CSRF protection verification
- [ ] Authentication bypass attempts
- [ ] Authorization bypass testing
- [ ] API security review
- [ ] Dependency vulnerability scan
- [ ] Security report with findings and remediation

### Task 5.3: Load Testing
- [ ] Load test with 1000+ concurrent users
- [ ] Stress test with 5000+ concurrent users
- [ ] Response time benchmarks
- [ ] Database performance under load
- [ ] API rate limiting verification
- [ ] Cache hit rate analysis
- [ ] Performance report with metrics

### Task 5.4: Accessibility Testing
- [ ] Keyboard navigation testing
- [ ] Screen reader testing
- [ ] Color contrast verification
- [ ] Form label and error messaging
- [ ] Mobile accessibility
- [ ] WCAG 2.1 AA compliance
- [ ] Accessibility report with issues

### Task 5.5: Cross-Browser Testing
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- [ ] Mobile Safari (iOS)
- [ ] Chrome Mobile (Android)
- [ ] Bug report for any issues found

### Task 5.6: Performance Validation
- [ ] Hero shell < 14 KB ✓
- [ ] FCP < 1 second ✓
- [ ] LCP < 2.5 seconds ✓
- [ ] CLS < 0.1 ✓
- [ ] Full app load 2-4 seconds ✓
- [ ] Lighthouse score > 90 ✓
- [ ] Performance report generated

### Task 5.7: Documentation & Runbooks
- [ ] Deployment runbook
- [ ] Rollback procedures
- [ ] Monitoring and alerting setup
- [ ] Incident response procedures
- [ ] Database backup and recovery
- [ ] Staff training guide
- [ ] User documentation
- [ ] API documentation

---

## SPRINT 6: Deployment & Go-Live (Weeks 11-12)

### Task 6.1: Production Environment Setup
- [ ] Production database configured with backups
- [ ] CDN configured for production domain
- [ ] SSL/TLS certificates installed
- [ ] Email service configured for production
- [ ] Stripe production account configured
- [ ] OAuth production credentials configured
- [ ] Monitoring and alerting enabled
- [ ] Log aggregation configured

### Task 6.2: CI/CD Pipeline Configuration
- [ ] GitHub Actions or similar configured
- [ ] Automated tests run on every push
- [ ] Build artifacts created
- [ ] Automated deployment to staging
- [ ] Manual approval for production deployment
- [ ] Rollback automation
- [ ] Deployment logs and history

### Task 6.3: Data Migration & Validation
- [ ] Database backup created
- [ ] Data validation scripts run
- [ ] Admin user created
- [ ] Sample products loaded
- [ ] Email templates configured
- [ ] Settings configured for production
- [ ] Data integrity verified

### Task 6.4: Go-Live Preparation
- [ ] Launch checklist completed
- [ ] Monitoring dashboards created
- [ ] On-call rotation established
- [ ] Communication plan for launch
- [ ] Rollback plan documented
- [ ] Staff training completed
- [ ] Customer communication ready

### Task 6.5: Launch & Monitoring
- [ ] Application deployed to production
- [ ] Health checks passing
- [ ] All endpoints responding
- [ ] Database connectivity verified
- [ ] Payment processing working
- [ ] Email notifications sending
- [ ] Monitoring alerts active
- [ ] No critical errors in logs

### Task 6.6: Post-Launch Support (1 Week)
- [ ] Daily monitoring of error rates
- [ ] User feedback collection
- [ ] Performance metrics reviewed
- [ ] Critical issues addressed immediately
- [ ] Non-critical issues logged for future sprints
- [ ] Post-launch retrospective
- [ ] Handoff to operations team

---

## Summary

**Total Duration**: 12 weeks (6 sprints of 2 weeks each)

**Key Milestones**:
- Week 2: Security foundations complete
- Week 4: Performance targets met
- Week 6: Admin tools fully functional
- Week 8: All features populated and tested
- Week 10: Security and load testing passed
- Week 12: Production launch

**Success Metrics**:
- Hero shell ≤14 KB ✓
- FCP <1 second ✓
- LCP <2.5 seconds ✓
- CLS <0.1 ✓
- 99.9% uptime ✓
- 0 OWASP Top 10 vulnerabilities ✓
- 1000+ concurrent users supported ✓


## Sprint 2 Phase 6B: Admin Separation (Option B - Separate Employee Entry Point)
- [ ] Create separate employee.html entry point
- [ ] Create src/employee/main.tsx with dedicated React app
- [ ] Create src/employee/App.tsx with employee-only router
- [ ] Move AdminDashboard to employee app
- [ ] Move admin components to employee-only directory
- [ ] Remove Admin from customer Navigation component
- [ ] Verify customer bundle has zero admin imports
- [ ] Configure Vite for dual-entry build
- [ ] Configure server routing (/employee/* → employee app, / → customer app)
- [ ] Test customer app (no admin visible)
- [ ] Test employee app (full admin access with RBAC)
- [ ] Create checkpoint for admin separation


## Sprint 2 Phase 7: Video Intake Workflow (Final Scope)
- [ ] Add CMSVideoIntakeSchema to validation.ts
- [ ] Implement cmsVideos.createFromUrl tRPC procedure
- [ ] Write 4 contract tests for intake path
- [ ] Build AdminVideoIntakeModal component
- [ ] Wire modal into /employee admin dashboard
- [ ] Implement public videos.listPublished endpoint
- [ ] Test end-to-end intake workflow
- [ ] Create final checkpoint


## SPRINT 3: Production Cleanup (NEW)

### Phase 1: Remove Testing Elements
- [x] Remove sample cart items from Cart page (show empty state)
- [x] Remove sample data from Collections page (Menu.tsx)
- [x] Remove fallback sample video from Discover page
- [ ] Remove test/demo data from database seed
- [ ] Remove placeholder content from all pages
- [x] Verify all pages show empty states when no data
- [ ] Remove any console.log debug statements
- [ ] Remove any commented-out code blocks

### Phase 2: Implement Google OAuth
- [x] Wire Google OAuth callback handler to server
- [x] Replace "Sign in with Manus" button with "Sign in with Google"
- [x] Add Google Sign-In SDK to Account page
- [ ] Test Google Sign-In flow end-to-end
- [x] Verify session cookie creation (HttpOnly, Secure, SameSite)
- [x] Test logout functionality
- [x] Verify no token leakage in logs

### Phase 3: Build Admin Dashboard
- [x] Create /admin route with role-based access control
- [x] Add admin check for adrianarvizu1994@gmail.com and eriflores21@gmail.com
- [ ] Build order management interface
- [ ] Add site settings panel
- [ ] Add emergency gate controls
- [ ] Add activity logs view
- [ ] Test admin access restrictions

### Phase 4: Complete Stripe Integration
- [ ] Implement Stripe webhook handler (/api/stripe/webhook)
- [ ] Handle payment_intent.succeeded events
- [ ] Update order status to paid
- [ ] Send order confirmation email
- [ ] Test webhook signature validation
- [ ] Test payment flow end-to-end

### Phase 5: Final Testing & Deployment
- [ ] All tests passing
- [ ] TypeScript 0 errors
- [ ] Manual testing on live site
- [ ] Verify Google OAuth works
- [ ] Verify admin dashboard access
- [ ] Verify Stripe payments
- [ ] Create final checkpoint
- [ ] Ready for production


### Phase 4: Fix Google OAuth Callback Redirect Loop
- [x] Debug Google OAuth callback URL configuration
- [x] Fix redirect loop issue (redirects back to sign-in instead of home)
- [x] Verify callback URL matches Google Console configuration
- [x] Test complete Google Sign-In flow end-to-end
- [x] Fixed cookie name mismatch (was "session", now uses COOKIE_NAME)
- [x] Fixed session payload format to use openId instead of userId


### Bug Fixes
- [x] Account/Login link not visible on mobile navigation
- [x] Test responsive design on mobile devices

- [x] Fix Google Sign-In SDK JSON parsing error on Account page
- [x] Debug callback response returning HTML instead of JSON
- [x] Improved error handling with better JSON parsing and error messages

- [x] Google OAuth app already configured with boardella.com domain
- [x] Authorized redirect URIs include https://boardella.com/auth/google/callback
- [ ] Clear browser cache and test Google Sign-In again
- [ ] Verify consent screen shows boardella.com (may take time to propagate)


### ChatGPT Suggested Fixes (Critical)
- [x] Fix backend callback to use sdk.createSessionToken() instead of base64 blob
- [x] Update SiteGate to allow POST /auth/google/callback in private mode
- [x] Ensure user upsert uses openId = `google:${payload.sub}` format
- [x] Verify VITE_GOOGLE_CLIENT_ID and GOOGLE_CLIENT_ID match
- [x] Test complete Google Sign-In flow with session persistence
- [x] Verify app_session_id cookie is set and persists on reload
- [x] Confirm protected routes don't redirect to /access after login
- [x] Fixed Google Sign-In button rendering (now appears after loading completes)
