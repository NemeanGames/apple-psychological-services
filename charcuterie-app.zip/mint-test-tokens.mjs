#!/usr/bin/env node

/**
 * Mint test tokens for ChatGPT Agent testing
 * Usage: node mint-test-tokens.mjs
 */

import crypto from "crypto";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("❌ DATABASE_URL not set");
  process.exit(1);
}

async function mintTokens() {
  let connection;
  try {
    // Parse connection string
    const url = new URL(DATABASE_URL);
    const config = {
      host: url.hostname,
      user: url.username,
      password: url.password,
      database: url.pathname.slice(1),
      port: parseInt(url.port || "3306"),
      ssl: {},
    };

    console.log("🔗 Connecting to database...");
    connection = await mysql.createConnection(config);

    // Generate tokens
    const tokens = [
      {
        label: "ChatGPT Anonymous Visitor",
        maxUses: -1, // Unlimited
        purpose: "site_beta",
      },
      {
        label: "ChatGPT Customer Account",
        maxUses: -1, // Unlimited
        purpose: "site_beta",
      },
    ];

    console.log("\n🎫 Minting test tokens...\n");

    for (const tokenConfig of tokens) {
      const plainToken = "site_beta_" + crypto.randomBytes(32).toString("hex");
      const tokenHash = crypto
        .createHash("sha256")
        .update(plainToken)
        .digest("hex");

      const query = `
        INSERT INTO accessTokens (tokenHash, purpose, label, maxUses, usesRemaining, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW())
      `;

      const [result] = await connection.execute(query, [
        tokenHash,
        tokenConfig.purpose,
        tokenConfig.label,
        tokenConfig.maxUses,
        tokenConfig.maxUses,
      ]);

      console.log(`✅ ${tokenConfig.label}`);
      console.log(`   Token: ${plainToken}`);
      console.log(`   Hash:  ${tokenHash}`);
      console.log(`   Uses:  ${tokenConfig.maxUses === -1 ? "Unlimited" : tokenConfig.maxUses}`);
      console.log();
    }

    console.log("🎉 Test tokens created successfully!");
    console.log("\n📋 Next steps for ChatGPT Agent:");
    console.log("1. Visit https://boardella.com/access");
    console.log("2. Paste the token from above");
    console.log("3. Submit to gain access");
    console.log("\n");

  } catch (error) {
    console.error("❌ Error:", error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

mintTokens();
